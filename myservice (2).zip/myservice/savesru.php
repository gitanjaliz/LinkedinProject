<?php require_once("lock.php");
if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
{
			$pdate=$_POST['pdate'];						  
			$sru_desc=$_POST['sru_desc'];	
			$sru_addr=$_POST['sru_addr'];
			$sb_flag="1";
			$sb_time=time();
			$s_id=$_POST['s_id'];
			$u_id=$user['u_id'];	
				if($auth_main->savesru($s_id, $sru_desc, $u_id, $pdate, $sb_time, $sb_flag, $sru_addr))
				{	
				echo "Success" ;
				}
				else
				{
				echo "Registration Fails";
				}
	}

?>