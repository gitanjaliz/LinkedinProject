<div id="ccnt" class="header-fixed">
    <a href="home" class="header-icon-1 open-left-sidebar"><i class="fa fa-navicon"></i></a>
    <a href="home" style="background-color: rgba(41, 128, 185, 0);" class="header-logo"><img src="images/pictures/lg.png" style="width:111px;" alt="img"></a>
    <a href="cart"  class="header-icon-3"><i class="fa fa-shopping-bag"></i>
	<?php
					$uid=$user['u_id'];
							$ord=$auth_main->fetchorder($uid);
										if($ord == 0){
											$incod=$ord + 1;
											$ode=date("Y")."ord"."-".$incod;
											//$auth=md5($o_code);
										}else{
										$icode=$ord['o_code'];
										$part = explode('-', "$icode");
										$icn = $part[1];
										$incod=$icn + 1;
										$ode=date("Y")."ord"."-".$incod;
											//$auth=md5($o_code);
										}
	$cntcart=$auth_main->cntcart($uid,$ode);
	$ccount=count($cntcart);
if($ccount > 0){ 
?>
	<strong style="background: red;
    border-radius: 20px;
    padding: 3px;
font-size: 10px;"><?php echo $ccount ; ?></strong><?php } ?></a>
    <a class="header-icon-2 open-search-bar"><i class="fa fa-search"></i></a>
</div>
<div id="srh" class="header-search">
    <input type="text" placeholder="Search For Service Proider" id="searchbox"  onkeyup="ser()">
    <a class="close-search-bar"><i class="fa fa-times"></i></a>
</div>
<div class="sidebar-left">
    <div class="sidebar-scroll">
        <div class="sidebar-header left-sidebar-header">
            <a class="close-sidebar" href="#"><i class="fa fa-times"></i></a>
            <a href="index" style="background-color: rgba(41, 128, 185, 0);" class="header-logo"><img src="images/pictures/lg.png" style="width:111px; float: right; margin-right: 100px;" alt="img"></a>
            <div class="clear"></div>
        </div>
        <div class="sidebar-divider">
        Welcome , <?php echo $user['u_name'];  ?> 
        </div>
        <div class="sidebar-menu">
            <a class="menu-item active-item" rel="tab" href="home">
                <i class="fa fa-home"></i> Home
                <i class="fa fa-circle"></i>
            </a>
            <a class="menu-item" href="history" rel="tab">
                <i class="fa fa-archive"></i>Your Order`s
                <i class="fa fa-circle"></i>
            </a>
			<a class="menu-item" href="cart" rel="tab">
                <i class="fa fa-shopping-cart"></i>Your Cart
                <i class="fa fa-circle"></i>
            </a>
            <a class="menu-item" href="technician.php" rel="tab">
            <i class="fa fa-user"></i>Technician
                <i class="fa fa-circle"></i>
            </a>
            <a class="close-sidebar menu-item" href="#" >
                <i class="fa fa-times"></i> Close
                <i class="fa fa-circle"></i>
            </a>
            <div class="sidebar-divider">
                Use antother account
            </div>
            <a class="menu-item" href="logout.php?logout=true">
                <i class="fa fa-sign-out"></i>Logout
                <i class="fa fa-circle"></i>
            </a>
        </div>
        <em class="sidebar-copyright">Copyright . All Rights Reserved</em>
    </div>
</div>
<script type="text/javascript">
function ser() 
{
var searchbox = $("#searchbox").val();
var dataString = 'searchword='+ searchbox;
	//alert(searchbox);
if(searchbox=='')
{
}
else
{

$.ajax({
type: "POST",
url: "search.php",
data: dataString,
cache: false,
success: function(result)
{
	//alert(result);
$("#page-content").html(result);
	}
});
}return false; 
}
</script>