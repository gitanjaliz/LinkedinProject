<?php
error_reporting(0);
include('lock.php');
if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
{
	$v_name	=$_POST['v_name'];
	$v_contact=$_POST['v_contact'];
	$v_pass = password_hash($v_contact, PASSWORD_DEFAULT);
	$s_id =$_POST['s_id'];
	$v_email=$_POST['v_email'];
	$v_amount=$_POST['v_amount'];
	$v_uname=$_POST['v_name'];
	$v_addr=$_POST['v_addr'];
	$v_date=time();
	$v_flag=1;
				if($auth_user->addvender($user_id, $v_name, $v_contact, $s_id, $v_email, $v_date, $v_amount, $v_addr, $v_flag, $v_uname, $v_pass))
				{	
				echo "Success" ;
				}
				else
				{
				echo "Fails upload";
				}
}
?>