<?php 
require_once('config/dbconfig.php');
require_once("lock.php");

// Initialize database connection
$database = new Database();
$conn = $database->dbConnection();

// Initialize variables
$category = $fullname = $contact = $email = $address = $request_type = $status = '';
$vehicle_name = $vehicle_registration_number = $vehicle_model = '';
$service_id = null;

// Validate `id` parameter
if (isset($_GET['id']) && filter_var($_GET['id'], FILTER_VALIDATE_INT)) {
    $id = (int)$_GET['id'];

    try {
        // Fetch main details
        $stmt = $conn->prepare("
            SELECT s.*, 
                   cc.s_head, 
                   c.u_name AS fullname, 
                   c.u_email, 
                   c.u_cont, 
                   c.u_addr 
            FROM sbook s 
            INNER JOIN services cc ON s.s_id = cc.s_id 
            INNER JOIN user c ON s.u_id = c.u_id 
            WHERE s.sb_id = :id
        ");
        $stmt->bindParam(":id", $id, PDO::PARAM_INT);
        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            // Assign fetched values to variables
            $category = $row['s_head'] ?? 'Accessories';
            $fullname = $row['fullname'] ?? 'N/A';
            $contact = $row['u_cont'] ?? 'N/A';
            $email = $row['u_email'] ?? 'N/A';
            $address = $row['u_addr'] ?? 'N/A';
            $request_type = $row['request_type'] ?? 'Pick Up';
            $status = $row['status'] ?? 0;
            $vehicle_name = $row['vehicle_name'] ?? 'N/A';
            $vehicle_registration_number = $row['vehicle_registration_number'] ?? 'N/A';
            $vehicle_model = $row['vehicle_model'] ?? 'N/A';
            $service_id = $row['s_id'] ?? null;
        } else {
            echo "No data found for the provided ID.";
            exit;
        }
    } catch (PDOException $e) {
        error_log($e->getMessage(), 3, "error_log.txt");
        echo "An error occurred while fetching details.";
        exit;
    }
} else {
    echo "Invalid or missing ID parameter.";
    exit;
}

// Fetch related services
$services = [];
if ($service_id) {
    try {
        $services_stmt = $conn->prepare("SELECT s_head FROM services WHERE s_id = :s_id");
        $services_stmt->bindParam(":s_id", $service_id, PDO::PARAM_INT);
        $services_stmt->execute();
        $services = $services_stmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (PDOException $e) {
        error_log($e->getMessage(), 3, "error_log.txt");
        echo "Error fetching related services.";
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service Request Details</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome for icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <!-- Custom Styles -->
    <link href="views/css/bootstrap-reset.css" rel="stylesheet">
    <link href="views/assets/font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="views/css/table-responsive.css" rel="stylesheet">
    <link href="views/css/style.css" rel="stylesheet">
    <link href="views/css/style-responsive.css" rel="stylesheet">

    <style>
        body {
            background-color: #f8f9fa;
            color: #333;
        }
        .container-fluid {
            margin-top: 20px;
        }
        .card {
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        .card-header {
            background-color: #007bff;
            color: #fff;
            border-radius: 8px 8px 0 0;
        }
        .card-header h3 {
            margin: 0;
        }
        .page-title {
            margin: 20px 0;
            text-align: center;
            font-size: 24px;
            font-weight: bold;
            color: #333;
        }
        dl dt {
            font-weight: 600;
            color: #555;
        }
        dl dd {
            margin-left: 20px;
            color: #666;
        }
        .badge {
            font-size: 0.9rem;
        }
        .btn-secondary {
            background-color: #6c757d;
            border: none;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>
    <!-- Container Section -->
    <section id="container">
        <?php include "header.php"; ?>
        <div class="container-fluid">
            <!-- Page Title -->
            <div class="page-title">
                <h1>Service Request Details</h1>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-header text-center">
                            <h3><i class="fa fa-wrench"></i> Service Request Details</h3>
                        </div>
                        <div class="card-body">
                            <dl class="row">
                                <dt class="col-sm-4"><i class="fa fa-cogs"></i> Service Name:</dt>
                                <dd class="col-sm-8"><?php echo htmlspecialchars($category); ?></dd>

                                <dt class="col-sm-4"><i class="fa fa-user"></i> Client Name:</dt>
                                <dd class="col-sm-8"><?php echo htmlspecialchars($fullname); ?></dd>

                                <dt class="col-sm-4"><i class="fa fa-phone"></i> Mobile Number:</dt>
                                <dd class="col-sm-8"><?php echo htmlspecialchars($contact); ?></dd>

                                <dt class="col-sm-4"><i class="fa fa-envelope"></i> Email:</dt>
                                <dd class="col-sm-8"><?php echo htmlspecialchars($email); ?></dd>

                                <dt class="col-sm-4"><i class="fa fa-map-marker"></i> Address:</dt>
                                <dd class="col-sm-8"><?php echo htmlspecialchars($address); ?></dd>

                                <dt class="col-sm-4"><i class="fa fa-info-circle"></i> Status:</dt>
                                <dd class="col-sm-8">
                                    <?php if ($status == 1): ?>
                                        <span class="badge badge-success">Confirmed</span>
                                    <?php elseif ($status == 2): ?>
                                        <span class="badge badge-warning">On-progress</span>
                                    <?php elseif ($status == 3): ?>
                                        <span class="badge badge-success">Done</span>
                                    <?php elseif ($status == 4): ?>
                                        <span class="badge badge-danger">Cancelled</span>
                                    <?php else: ?>
                                        <span class="badge badge-secondary">Pending</span>
                                    <?php endif; ?>
                                </dd>
                            </dl>
                        </div>
                        <div class="card-footer text-right">
                            <button type="button" class="btn btn-secondary" onclick="window.history.back()">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Bootstrap JS and Dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js"></script>
</body>
</html>
