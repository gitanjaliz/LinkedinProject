<?php require_once("lock.php"); 
require_once("config/dbconfig.php"); 

$database = new Database();
$conn = $database->dbConnection();

// Check connection
if (!$conn) {
    echo "Database connection failed!";
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta and title -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Mosaddek">
    <meta name="keyword" content="FlatLab, Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
    <link rel="shortcut icon" href="views/img/favicon.html">

    <title><?php echo TITLE; ?></title>

    <!-- Stylesheets -->
    <link href="views/css/bootstrap-reset.css" rel="stylesheet">
    <link href="views/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="views/css/table-responsive.css" rel="stylesheet" />
    <link href="views/css/style.css" rel="stylesheet">
    <link href="views/css/style-responsive.css" rel="stylesheet">  
</head>
<style>
    .panel-heading {
        font-size: 24px; /* Increase the font size */
        font-weight: bold; /* Make the title bold */
        text-align: center; /* Center align the title */
        padding: 15px; /* Add some padding for spacing */
        background-color: #007bff; /* Optional: Add a background color */
        color: #fff; /* Optional: Change text color to white */
        border-radius: 5px; /* Optional: Add rounded corners */
    }
</style>

<body>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap JS and Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js"></script>

    <section id="container" class="">
        <!-- Header -->
        <?php include "header.php"; ?>
        
        <!-- Main content -->
        <section id="main-content">
            <section class="wrapper">
                <div class="row">
                    <div class="col-lg-12" id="edit_view">
                        <section class="panel">
                            <header class="panel-heading">
                                Service Request
                            </header>
                            <div class="panel-body">
                                <section id="no-more-tables">
                                    <table class="table table-bordered table-striped table-condensed cf">
                                        <thead class="cf">
                                            <tr>
                                                <th>Sr.No</th>
                                                <th>Name</th>
                                                <th>Address</th>
                                                <th>Contact</th>
                                                <th>Email</th>
                                                <th>Service Details</th>
                                                <th>Service Type</th>
                                                <th>Schedule Date</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
<?php
$fetchvender = $auth_user->fetchservreq();
foreach ($fetchvender as $fetchvenderdiv) {
    $u_name = $fetchvenderdiv['u_name'];
    $u_cont = $fetchvenderdiv['u_cont'];
    $u_email = $fetchvenderdiv['u_email'];
    $sb_for = $fetchvenderdiv['sb_for'];
    $sb_addr = $fetchvenderdiv['sb_addr'];
    $s_head = $fetchvenderdiv['s_head'];
    $sb_id = $fetchvenderdiv['sb_id'];
    $sb_dt = $fetchvenderdiv['sb_dt'];
    $status = $fetchvenderdiv['status'];
    ?>
                               <tr>
    <td data-title="Sr.No"><?php echo $sb_id; ?></td>
    <td data-title="Name"><?php echo $u_name; ?></td>
    <td data-title="Address">
        <?php
        $string = strip_tags($sb_addr);
        if (strlen($string) > 500) {
            $stringCut = substr($string, 0, 500);
            $string = substr($stringCut, 0, strrpos($stringCut, ' ')) . '...';
        }
        echo $string;
        ?>
    </td>
    <td data-title="Contact"><?php echo $u_cont; ?></td>
    <td data-title="Email"><?php echo $u_email; ?></td>
    <td data-title="Service Details"><?php echo $sb_for; ?></td>
    <td data-title="Service Type"><?php echo $s_head; ?></td>
    <td data-title="Schedule Date"><?php echo $sb_dt; ?></td> 
    <td class="text-center">
    <?php
    switch ($status) {
        case 1:
            echo '<span class="badge badge-success rounded-pill px-3">Confirmed</span>';
            break;
        case 2:
            echo '<span class="badge badge-warning rounded-pill px-3">On-progress</span>';
            break;
        case 3:
            echo '<span class="badge badge-success rounded-pill px-3">Done</span>';
            break;
        case 4:
            echo '<span class="badge badge-danger rounded-pill px-3">Cancelled</span>';
            break;
        default:
            echo '<span class="badge badge-danger rounded-pill px-3">Pending</span>';
            break;
    }
    ?>
    </td>

    <td align="center">
        <div class="btn-group">
            <button type="button" class="btn btn-flat btn-white btn-sm dropdown-toggle dropdown-icon" data-toggle="dropdown" style="background-color: white; color: black; border: 1px solid #ccc;">
                Action <span class="sr-only">Toggle Dropdown</span>
            </button>
            <div class="dropdown-menu" role="menu">
                <a class="dropdown-item view_data" href="javascript:void(0)" data-id="<?php echo $sb_id; ?>">
                    <span class="fa fa-eye text-primary"></span> View
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item edit_data" href="javascript:void(0)" data-id="<?php echo $sb_id; ?>">
                    <span class="fa fa-edit text-primary"></span> Edit
                </a>
                <div class="dropdown-divider"></div>
                <!-- Delete Action -->
                <form action="" method="POST" class="d-inline">
                    <input type="hidden" name="delete_id" value="<?php echo htmlspecialchars($sb_id); ?>">
                    <button type="submit" class="dropdown-item text-danger" name="delete" value="Delete">
                        <i class="far fa-trash-alt"></i> Delete
                    </button>
                </form>
            </div>
        </div>
    </td>
</tr>
<?php
}
?>
                                        </tbody>
                                    </table>
                                </section>
                            </div>
                        </section>
                    </div>
                </div>
            </section>
        </section>
    </section>

    <!-- JavaScript -->
    <script src="views/js/jquery.js"></script>
    <script src="views/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function(){
            console.log("Document loaded and ready for action!");

            $('.delete_data').click(function(){
                const id = $(this).attr('data-id');
                console.log("Delete ID: " + id);
                if (confirm("Are you sure you want to delete this request?")) {
                    delete_service_request(id);
                }
            });

            $('.view_data').click(function(){
                const id = $(this).attr('data-id');
                console.log("View ID: " + id);
                window.location.href = "view_request.php?id=" + id;
            });

            $('.edit_data').click(function(){
                const id = $(this).attr('data-id');
                console.log("Edit ID: " + id);
                window.location.href = "manage_request.php?id=" + id;
            });

            function delete_service_request(id){
                $.ajax({
                    url: "classes/Master.php?f=delete_request",
                    type: "POST",
                    data: { id: id },
                    dataType: "json",
                    success: function(response){
                        console.log(response);
                        if (response.status === 'success') {
                            alert("Request deleted successfully!");
                            location.reload();
                        } else {
                            alert("Error deleting request!");
                        }
                    },
                    error: function(xhr, status, error){
                        console.error("AJAX Error: ", error);
                        alert("An error occurred while deleting.");
                    }
                });
            }
        });
    </script>

    <?php

 // Deletion Logic
 if (isset($_POST['delete'])) {
    $delete_id = intval($_POST['delete_id']); // Sanitize input

    if ($delete_id > 0) {
        // Check if connection is established
        if ($conn) {
            $sql = "DELETE FROM sbook WHERE sb_id = :delete_id";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':delete_id', $delete_id, PDO::PARAM_INT);

            if ($stmt->execute()) {
                echo '<script>
                        alert("Record Deleted Successfully");
                        window.location.href = "servicereq.php";
                      </script>';
            } else {
                echo '<p class="text-danger">Unable to Delete Data: ' . implode(', ', $conn->errorInfo()) . '</p>';
            }
        } else {
            echo '<p class="text-danger">Database connection failed.</p>';
        }
    } else {
        echo '<p class="text-danger">Invalid Technician ID.</p>';
    }
}
    ?>

</body>
</html>
