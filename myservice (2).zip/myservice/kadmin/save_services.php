<?php
error_reporting(0);
include('lock.php');
$session_id=$cust_id;
$path = "../services/";
$actual_image_name="";
$valid_formats = array("jpg", "png", "gif", "bmp","jpeg","PNG","JPG","JPEG","GIF","BMP");
if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
{
	include_once 'includes/getExtension.php';
	 $imagename = $_FILES['profileimg']['name'];
	$size = $_FILES['profileimg']['size'];
	$s_head	= $_POST['s_head'];
	$s_desc	= $_POST['s_desc'];
	$s_icon	= $_POST['s_icon'];
	$s_type= $_POST['s_type'];
	$s_fees= $_POST['s_fees'];
	$price_desc= $_POST['price_desc'];
	$s_flag=1;
	if(strlen($imagename))
	{
		$douext=explode(".",$imagename);
		$cnt=count($douext);
		if($cnt == 2){
		$ext = strtolower(getExtension($imagename));
		if(in_array($ext,$valid_formats))
		{
			if($size<(1024*1024))
			{
				$actual_image_name = time().substr(str_replace(" ", "_", $txt), 5).".".$ext;
				$uploadedfile = $_FILES['profileimg']['tmp_name'];
				include 'includes/compressImagewidth.php';	
											 
				//$widthArray = array(200,100,50);
				
				$s_img=compressImage($ext,$uploadedfile,$path,$actual_image_name,200);
												
				if(move_uploaded_file($uploadedfile, $path.$actual_image_name))
				{	
				$ntime=time();
				if($auth_user->addservices($user_id, $s_head, $s_desc, $s_flag, $s_img, $s_icon,$s_type, $s_fees, $price_desc))
				{	
				echo "Success" ;
				}else
					echo "Fails upload ";
				}
				else
				echo "Fail upload folder with read access.";
			}
			else
			echo "Image file size max 1 MB";					
		}
		else
		echo "Invalid file format..";	
	}
		else
		echo "Invalid Double extention file format..";
	}
	else
	echo "Please select image..!";
	exit;
}
?>