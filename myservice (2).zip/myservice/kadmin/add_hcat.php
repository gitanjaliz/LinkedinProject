<?php
error_reporting(0);
include('lock.php');
//$session_id=$cust_id;
$path = "../icons/";
$actual_image_name="";
$valid_formats = array("jpg", "png", "gif", "bmp","jpeg","PNG","JPG","JPEG","GIF","BMP");
if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
{
	include_once 'includes/getExtension.php';
	  $imagename = $_FILES['iconimg']['name'];
	$size = $_FILES['iconimg']['size'];
	$hc_name =$_POST['hc_name'];
	$hc_flag=1;
	if(strlen($imagename))
	{
		$douext=explode(".",$imagename);
		$cnt=count($douext);
		if($cnt == 2){
		$ext = strtolower(getExtension($imagename));
		if(in_array($ext,$valid_formats))
		{
			if($size<(1024*1024))
			{
				$actual_image_name = time().substr(str_replace(" ", "_", $txt), 5).".".$ext;
				$uploadedfile = $_FILES['iconimg']['tmp_name'];
				require_once 'includes/compressImageicon.php';	
				$hc_icons=compressImage($ext,$uploadedfile,$path,$actual_image_name,100);
				if(move_uploaded_file($uploadedfile, $path.$actual_image_name))
				{	
				$h_date=time();
				if($auth_user->addhc($user_id, $hc_name, $hc_icons, $hc_flag)){	
				echo "Success" ;
				}else
					echo "Fails upload ";
				}
				else
				echo "Fail upload folder with read access.";
			}
			else
			echo "Image file size max 1 MB";					
		}
		else
		echo "Invalid file format..";	
	}
		else
		echo "Invalid Double extention file format..";
	}
	else
	echo "Please select image..!";
	exit;
}
?>