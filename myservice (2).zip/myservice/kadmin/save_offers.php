<?php
error_reporting(0);
include('lock.php');
$session_id=$cust_id;
$path = "../offers/";
$actual_image_name="";
$valid_formats = array("jpg", "png", "gif", "bmp","jpeg","PNG","JPG","JPEG","GIF","BMP");
if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
{
	include_once 'includes/getExtension.php';
	 $imagename = $_FILES['profileimg']['name'];
	$size = $_FILES['profileimg']['size'];
	$o_head	= $_POST['o_head'];
	$o_desc	= $_POST['o_desc'];
	$o_flag=1;
	if(strlen($imagename))
	{
		$douext=explode(".",$imagename);
		$cnt=count($douext);
		if($cnt == 2){
		$ext = strtolower(getExtension($imagename));
		if(in_array($ext,$valid_formats))
		{
			if($size<(1024*1024))
			{
				$actual_image_name = time().substr(str_replace(" ", "_", $txt), 5).".".$ext;
				$uploadedfile = $_FILES['profileimg']['tmp_name'];
				include 'includes/compressImagemedia.php';	
											 
				//$widthArray = array(200,100,50);
				
				$o_img=compressImage($ext,$uploadedfile,$path,$actual_image_name,200);
												
				if(move_uploaded_file($uploadedfile, $path.$actual_image_name))
				{	
				$o_time=time();
				if($auth_user->addoffers($o_head, $o_desc, $o_flag, $o_img, $o_time, $user_id))
				{	
				echo "Success" ;
				}else
					echo "Fails upload ";
				}
				else
				echo "Fail upload folder with read access.";
			}
			else
			echo "Image file size max 1 MB";					
		}
		else
		echo "Invalid file format..";	
	}
		else
		echo "Invalid Double extention file format..";
	}
	else
	echo "Please select image..!";
	exit;
}
?>