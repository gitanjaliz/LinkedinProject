<?php
include('lock.php');
if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
{
	$ic_name = $_POST['ici_name'];
	$ici_price = $_POST['ici_price'];
	$h_id = $_POST['hi_id'];
	$ic_parent = $_POST['catpar'];
	$ic_date = time();
	$ic_flag = 1;
				if($auth_user->addcatitem($user_id, $h_id, $ic_name, $ic_parent, $ic_flag, $ic_date, $ici_price))
				{	
				echo "Success" ;
				}
				else
				{
				echo "Fails upload";
				}
}
?>