<?php
error_reporting(0);
include('lock.php');
$session_id=$cust_id;
$path = "../hotels/";
$actual_image_name="";
$valid_formats = array("jpg", "png", "gif", "bmp","jpeg","PNG","JPG","JPEG","GIF","BMP");
if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
{
	include_once 'includes/getExtension.php';
	  $imagename = $_FILES['profileimg']['name'];
	$size = $_FILES['profileimg']['size'];
	$h_name	=$_POST['h_name'];
	$hc_id=$_POST['hc_id'];
	$h_own_name=$_POST['h_own_name'];
	$h_addr = $_POST['h_addr'];
	$h_pincode =$_POST['h_pincode'];
	$flno=$_POST['flno'];
	$paytmn=$_POST['paytmn'];
	$discnt=$_POST['discnt'];
	$h_amt=$_POST['h_amt'];
	$h_flag=1;
	if(strlen($imagename))
	{
		$douext=explode(".",$imagename);
		$cnt=count($douext);
		if($cnt == 2){
		$ext = strtolower(getExtension($imagename));
		if(in_array($ext,$valid_formats))
		{
			if($size<(1024*1024))
			{
				$actual_image_name = time().substr(str_replace(" ", "_", $txt), 5).".".$ext;
				$uploadedfile = $_FILES['profileimg']['tmp_name'];
				include 'includes/compressImagehotel.php';	
				$h_img=compressImage($ext,$uploadedfile,$path,$actual_image_name,200);
				if(move_uploaded_file($uploadedfile, $path.$actual_image_name))
				{	
				$h_date=time();
				if($auth_user->addhotels($hc_id, $h_name, $h_own_name, $h_addr, $h_pincode, $flno, $paytmn, $discnt, $h_img, $h_date, $h_amt, $user_id, $h_flag)){	
				echo "Success" ;
				}else
					echo "Fails upload ";
				}
				else
				echo "Fail upload folder with read access.";
			}
			else
			echo "Image file size max 1 MB";					
		}
		else
		echo "Invalid file format..";	
	}
		else
		echo "Invalid Double extention file format..";
	}
	else
	echo "Please select image..!";
	exit;
}
?>