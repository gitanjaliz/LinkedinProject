<?php 
require_once("lock.php");
require_once("config/dbconfig.php");

$database = new Database();
$conn = $database->dbConnection();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the service ID and updated values from the form
    $sid = $_POST['sid'];
    $s_head = $_POST['s_head'];
    $s_desc = $_POST['s_desc'];
    $s_img = $_POST['s_img']; // Assuming you allow image change, you can handle file upload here
    $s_icon = $_POST['s_icon'];

    // Update query
    $query = "UPDATE services SET s_head = :s_head, s_desc = :s_desc, s_img = :s_img, s_icon = :s_icon WHERE s_id = :sid";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':s_head', $s_head);
    $stmt->bindParam(':s_desc', $s_desc);
    $stmt->bindParam(':s_img', $s_img);
    $stmt->bindParam(':s_icon', $s_icon);
    $stmt->bindParam(':sid', $sid);
    
    if ($stmt->execute()) {
        // Redirect to service list page after successful update
        header('Location: serviceList.php');
        exit();
    } else {
        echo "Error updating service details.";
    }
}

// Fetch the current service details for pre-filling the form
$sid = $_GET['sid'];
$query = "SELECT * FROM services WHERE s_id = :sid";
$stmt = $conn->prepare($query);
$stmt->bindParam(':sid', $sid, PDO::PARAM_INT);
$stmt->execute();
$service = $stmt->fetch(PDO::FETCH_ASSOC);

// If service not found, show error
if (!$service) {
    echo "Service not found.";
    exit;
}

$s_head = $service['s_head'];
$s_desc = $service['s_desc'];
$s_img = $service['s_img'];
$s_icon = $service['s_icon'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Mosaddek">
    <meta name="keyword" content="FlatLab, Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
    <link rel="shortcut icon" href="views/img/favicon.html">
    <title>Edit Service</title>
    <link href="views/css/bootstrap.min.css" rel="stylesheet">
    <link href="views/css/style.css" rel="stylesheet">
</head>

<body>

<section id="container">
    <!--header start-->
    <?php include "header.php"; ?>
    <!--main content start-->
    <section id="main-content">
        <section class="wrapper">
            <div class="row">
                <div class="col-lg-12" id="edit_view">
                    <section class="panel">
                        <header class="panel-heading">
                            Edit Service Details
                        </header>
                        <div class="panel-body">
                            <form method="POST" action="editService.php" enctype="multipart/form-data">
                                <input type="hidden" name="sid" value="<?php echo $sid; ?>" />

                                <div class="form-group">
                                    <label for="s_head">Service Head</label>
                                    <input type="text" class="form-control" id="s_head" name="s_head" value="<?php echo $s_head; ?>" required />
                                </div>

                                <div class="form-group">
                                    <label for="s_desc">Service Description</label>
                                    <textarea class="form-control" id="s_desc" name="s_desc"><?php echo $s_desc; ?></textarea>
                                </div>

                                <div class="form-group">
                                    <label for="s_img">Service Image (URL or upload)</label>
                                    <input type="text" class="form-control" id="s_img" name="s_img" value="<?php echo $s_img; ?>" />
                                    <!-- Or, you can handle image upload by using a file input instead -->
                                </div>

                                <div class="form-group">
                                    <label for="s_icon">Service Icon (CSS Class)</label>
                                    <input type="text" class="form-control" id="s_icon" name="s_icon" value="<?php echo $s_icon; ?>" required />
                                </div>

                                <button type="submit" class="btn btn-primary">Save Changes</button>
                            </form>
                        </div>
                    </section>
                </div>
            </div>
        </section>
    </section>
</section>

<script src="views/js/jquery.js"></script>
<script src="views/js/bootstrap.min.js"></script>

</body>
</html>
