      <header class="header white-bg">
              <div class="sidebar-toggle-box">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <!--logo start-->
            <a href="home.php" class="logo">K<span>Admin</span></a>
            <!--logo end-->
            <div class="top-nav ">
                <!--search & user info start-->
                <ul class="nav pull-right top-menu">
                    <!-- user login dropdown start-->
                    <li class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <img style="width:25px;" alt="" src="../images/klogo.png">
                            <span class="username"><?php echo $userRow['user_name']; ?></span>
                            <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu extended logout">
                            <div class="log-arrow-up"></div>
                            <li><a href="#"><i class=" fa fa-suitcase"></i>Profile</a></li>
                            <li><a href="#"><i class="fa fa-cog"></i> Settings</a></li>
                            <li><a href="#"><i class="fa fa-bell-o"></i> Notification</a></li>
                            <li><a href="logout.php?logout=true"><i class="fa fa-key"></i> Log Out</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </header>
      <!--header end-->
      <!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu" id="nav-accordion">
                  <li>
                      <a class="active" href="home.php">
                          <i class="fa fa-dashboard"></i>
                          <span>Dashboard</span>
                      </a>
                  </li>
				  <li>
                      <a class="active" href="fafonts.php">
                          <i class="fa fa-dashboard"></i>
                          <span>Service Icons</span>
                      </a>
                  </li>
				  <!--<li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-laptop"></i>
                          <span>Venders</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="vender.php">Add Venders</a></li>
                          <li><a  href="venderlist.php">View Venders</a></li>
                      </ul>
                  </li>-->
				 <!-- <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-user"></i>
                          <span>Food Hotels</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="hotels.php">Add Hotels</a></li>
                           <li><a  href="hotelslist.php">View Hotels</a></li>
                      </ul>
                  </li>-->
				  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-user"></i>
                          <span>Services</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="services.php">Add Services</a></li>
                          <li><a  href="servicelist.php">View Services</a></li>
                          
                      </ul>
					  
                  </li>
				 <!--  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-user"></i>
                          <span>Offers</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="offers.php">Add Offers</a></li>
                          <li><a  href="offerlist.php">View Offers</a></li>
                          
                      </ul>
					  
                  </li>-->
				  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-user"></i>
                          <span>Completed Reports </span>
                      </a>
                      <ul class="sub">
                         <!-- <li><a  href="comporder.php">Completed Food Order</a></li>-->
                          <li><a  href="compserv.php">Completed Service Order</a></li>
                          
                      </ul>
					  
                  </li>
                  <!--multi level menu end-->
              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>