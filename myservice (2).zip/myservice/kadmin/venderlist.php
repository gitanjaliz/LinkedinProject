<?php require_once("lock.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Mosaddek">
    <meta name="keyword" content="FlatLab, Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
    <link rel="shortcut icon" href="views/img/favicon.html">

    <title><?php echo TITLE; ?></title>

    <!-- Bootstrap core CSS -->
    <link href="views/css/bootstrap.min.css" rel="stylesheet">
    <link href="views/css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="views/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="views/css/table-responsive.css" rel="stylesheet" />
      <!--right slidebar-->
      <link href="views/css/slidebars.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="views/css/style.css" rel="stylesheet">
    <link href="views/css/style-responsive.css" rel="stylesheet" />  
     <link rel="stylesheet" type="text/css" href="views/assets/bootstrap-datepicker/css/datepicker.css" />
    <link rel="stylesheet" type="text/css" href="views/assets/bootstrap-timepicker/compiled/timepicker.css" />
    <link rel="stylesheet" type="text/css" href="views/assets/bootstrap-colorpicker/css/colorpicker.css" />
    <link rel="stylesheet" type="text/css" href="views/assets/bootstrap-daterangepicker/daterangepicker-bs3.css" />
    <link rel="stylesheet" type="text/css" href="views/assets/bootstrap-datetimepicker/css/datetimepicker.css" />
  </head>

  <body>

  <section id="container" class="">
      <!--header start-->
       <?php include"header.php"; ?>
      <!--sidebar end-->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
              <!-- page start-->
              <div class="row">
                  <div class="col-lg-12" id="edit_view">
                      <section class="panel">
                          <header class="panel-heading">
                              Venders List
                          </header>
                          <div class="panel-body">
                              <section id="no-more-tables">
                                  <table class="table table-bordered table-striped table-condensed cf">
                                      <thead class="cf">
                                      <tr>
                                         
                                           <th>Venders Sr.No</th>
				  						   <th>Venders Name </th>
                                           <th>Venders Address</th>
                                           <th>Venders Contact</th>
										   <th>Venders Email</th>
										   <th> Venders Amount</th>
										   <th> Service Type</th>
										   <th> Join Date</th>
										    <th> Venders Block</th>
										   </tr>
                                      </thead>
                                      <tbody>
<?php
	$fetchvender = $auth_user->fetchvender($user_id);
	foreach($fetchvender as $fetchvenderdiv){
	$v_name=$fetchvenderdiv['v_name'];
	$v_contact=$fetchvenderdiv['v_contact'];
	$v_email=$fetchvenderdiv['v_email'];
	$v_amount=$fetchvenderdiv['v_amount'];
	$v_addr=$fetchvenderdiv['v_addr'];
	$s_head=$fetchvenderdiv['s_head'];
	$v_id=$fetchvenderdiv['v_id'];
	$v_date=date('d-m-y',$fetchvenderdiv['v_date']);
			?>
                                      <tr>
                                          <td data-title="Venders Sr.No"><?php echo $v_id ;?></td>
										   <td data-title="Venders name"><?php echo $v_name ;?></td>
										  <td  data-title="Venders Address"><?php $string = strip_tags($v_addr);

if (strlen($string) > 500) {

    // truncate string
    $stringCut = substr($string, 0, 500);

    // make sure it ends in a word so assassinate doesn't become ass...
    $string = substr($stringCut, 0, strrpos($stringCut, ' ')).'...'; 
}
echo $string ; ?></td>
										  
										    <td data-title="Venders Contact"><?php echo $v_contact ;?></td>
											 <td data-title="Venders Email"><?php echo $v_email ;?></td>
											  <td data-title="Venders Amount"><?php echo $v_amount ;?></td>
											   <td data-title="Service Type"><?php echo $s_head ;?></td>
											    <td data-title="Join Date"><?php echo $v_date ;?></td>
										   <td class="Action" data-title="Venders Block"><a onclick="removejob('<?php echo $v_id ;?>')" class="btn btn-primary">Block</a>
                                      </tr>
									   <?php } ?>
                                     
                                      </tbody>
                                  </table>
                              </section>
                          </div>
                      </section>
                  </div>
              </div>
              <!-- page end-->
          </section>
      </section>
      <!--main content end-->
	 <div id="toast-container" style="display:none; " class="toast-top-right" aria-live="polite" role="alert"><div class="toast toast-success"><div class="toast-progress" style="width: 99.9218%;"></div><button type="button" class="toast-close-button" role="button">×</button><div class="toast-title">Toastr Notification</div><div id="sucess" class="toast-message"> </div></div></div>
	  <div  id="toast-container"style="display:none; " class="toast-top-center" aria-live="polite" role="alert"><div class="toast toast-error"><button type="button" class="toast-close-button" role="button">×</button><div class="toast-title">Error Notification</div><div id="error" class="toast-message"></div></div></div>
      <!--footer start-->
 
      <!--footer end-->
  </section>

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="views/js/jquery.js"></script>
    <script src="views/js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="views/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="views/js/jquery.scrollTo.min.js"></script>
    <script src="views/js/respond.min.js" ></script>
    <script src="views/js/jquery.nicescroll.js" type="text/javascript"></script>
	<script type="text/javascript" src="views/assets/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
  <script type="text/javascript" src="views/assets/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js"></script>
  <script type="text/javascript" src="views/assets/bootstrap-daterangepicker/moment.min.js"></script>
  <script type="text/javascript" src="views/assets/bootstrap-daterangepicker/daterangepicker.js"></script>
  <link href="views/assets/toastr-master/toastr.css" rel="stylesheet" type="text/css" />
  <!--right slidebar-->
  <script src="views/js/slidebars.min.js"></script>

    <!--common script for all pages-->
    <script src="views/js/common-scripts.js"></script>
    <script src="views/js/advanced-form-components.js"></script>
	<script type="text/javascript">
function removejob(jid){ 
		if (confirm("Remove Job Form List") == true) {
	$.ajax({
            type: 'POST',
            url: 'removejob.php',
            data: {jid:jid},
            success: function(data){ 
			if(data == "Success")
		{ 
			$('#sucess').text("Job Removed successfully");
			$('.toast-top-right').show();
			$('.toast-top-right').focus();
			$('.toast-top-right').fadeOut(5000); 
			location.reload();
		}
		else
		{ 
		//alert(data);
		 $('#error').text("Please Fill All Mandatory Fields");
			$('.toast-top-center').show();
			$('.toast-top-center').focus();
			$('.toast-top-center').fadeOut(5000);
			//$('#fform')[0].reset();
		}
		}                                    	  
         });  
	}else{
			$('#error').text("Remove Failed");
			$('.toast-top-center').show();
			$('.toast-top-center').focus();
			$('.toast-top-center').fadeOut(5000);
			//$('#fform')[0].reset();
	}	 
	}
</script>
  </body>
</html>
