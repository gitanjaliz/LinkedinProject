<?php
include('lock.php');
if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
{
	$ic_name = $_POST['ic_name'];
	$h_id = $_POST['h_id'];
	$ic_parent = "0";
	$ic_date = time();
	$ic_flag = 1;
				if($auth_user->addcathead($user_id, $h_id, $ic_name, $ic_parent, $ic_flag, $ic_date))
				{	
				echo "Success" ;
				}
				else
				{
				echo "Fails upload";
				}
}
?>