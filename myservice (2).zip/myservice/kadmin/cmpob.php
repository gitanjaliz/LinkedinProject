<?php
error_reporting(0);
include('lock.php');
if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
{
	$on_id = strip_tags($_POST['on_id']);
		try
		{
				if($auth_user->approbo($on_id))
				{	
				echo "Success" ;
				}
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}
		
}

?>