<?php
error_reporting(0);
include('lock.php');
if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
{
	$sbid = strip_tags($_POST['sbid']);
		try
		{
				if($auth_user->apprsb($sbid))
				{	
				echo "Success" ;
				}
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}
		
}

?>