<?php
require_once('config/dbconfig.php'); // Include your database configuration file

$database = new Database();
$conn = $database->dbConnection();

$response = array();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Sanitize and validate input data
        $sb_id = isset($_POST['sb_id']) ? intval($_POST['sb_id']) : null;
        $status = isset($_POST['status']) ? intval($_POST['status']) : null;

        if ($sb_id === null || $status === null) {
            throw new Exception("Invalid input data");
        }

        // Update the service request in the database
        $stmt = $conn->prepare("UPDATE `sbook` SET `status` = :status WHERE `sb_id` = :sb_id");
        $stmt->bindParam(':status', $status, PDO::PARAM_INT);
        $stmt->bindParam(':sb_id', $sb_id, PDO::PARAM_INT);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $response['status'] = 'success';
            $response['id'] = $sb_id;
        } else {
            throw new Exception("Failed to update request or no changes made");
        }
    } catch (Exception $e) {
        $response['status'] = 'error';
        $response['message'] = $e->getMessage();
    }
} else {
    $response['status'] = 'error';
    $response['message'] = 'Invalid request method';
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
