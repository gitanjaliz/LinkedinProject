<?php require_once("lock.php");?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Katare">
    <meta name="keyword" content="Mipltools, Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
    <link rel="shortcut icon" href="views/img/favicon.html">
    <title><?php echo TITLE; ?></title>
    <!-- Bootstrap core CSS -->
    <link href="views/css/bootstrap.min.css" rel="stylesheet">
    <link href="views/css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="views/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="views/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" media="screen"/>
    <link rel="stylesheet" href="views/css/owl.carousel.css" type="text/css">
      <!--right slidebar-->
      <link href="css/slidebars.css" rel="stylesheet">
	  	  	<!--Datepicker table-->
	<link rel="stylesheet" type="text/css" href="views/assets/bootstrap-wysihtml5/bootstrap-wysihtml5.css" />
    <link rel="stylesheet" type="text/css" href="views/assets/bootstrap-datepicker/css/datepicker.css" />
    <link rel="stylesheet" type="text/css" href="views/assets/bootstrap-timepicker/compiled/timepicker.css" />
    <link rel="stylesheet" type="text/css" href="views/assets/bootstrap-colorpicker/css/colorpicker.css" />
    <link rel="stylesheet" type="text/css" href="views/assets/bootstrap-daterangepicker/daterangepicker-bs3.css" />
    <link rel="stylesheet" type="text/css" href="views/assets/bootstrap-datetimepicker/css/datetimepicker.css" />
	<link href="views/assets/toastr-master/toastr.css" rel="stylesheet" type="text/css" />
    <!-- Custom styles for this template -->
    <link href="views/css/style.css" rel="stylesheet">
    <link href="views/css/style-responsive.css" rel="stylesheet" />
			 <script type="text/javascript" >
  function adchotel(){
	  $('#hcform').attr('onsubmit', 'aaaa');
	 var hc_name=$("#hc_name").val();
	if(hc_name!=""){
		//alert(head+"xxxx"+desc);
	var formData = new FormData($('#hcform')[0]);
    $.ajax({
        url: 'add_hcat.php',
        type: 'POST',
        data: formData,
        async: false,
        success: function (data) {
		if(data == "Success")
		{ 
		$('#hcform').attr('onsubmit', 'adchotel()');
		  $('#hcform')[0].reset();
			$('#sucess').text(" Offers Added successfully");
			$('.toast-top-right').show();
			$('.toast-top-right').focus();
			$('.toast-top-right').fadeOut(5000);
		}
		else
		{ 
		$('#hcform').attr('onsubmit', 'adchotel()');
		 $('#error').html(data);
			$('.toast-top-center').show();
			$('.toast-top-center').focus();
			$('.toast-top-center').fadeOut(5000);
			$('#hcform')[0].reset();
		}
        },
        cache: false,
        contentType: false,
        processData: false
    });
	}else{
		$('#hcform').attr('onsubmit', 'adchotel()');
			$('#error').text("Please Fill All Mandatory Fields");
			$('.toast-top-center').show();
			$('.toast-top-center').focus();
			$('.toast-top-center').fadeOut(5000);
			$('#hcform')[0].reset();
	}
}
   </script>
		 <script type="text/javascript" >
  function adhotel(){
	  $('#hform').attr('onsubmit', 'aaaa');
	  var hc_id=$("#hc_id").val();
	 var h_name=$("#h_name").val();
	 var h_own_name=$("#h_own_name").val();
	 var h_addr=$("#h_addr").val();
	 var h_pincode=$("#h_pincode").val();
	 var flno=$("#flno").val();
     var paytmn=$("#paytmn").val();
	 var discnt=$("#discnt").val();
	 var h_amt=$("#h_amt").val();
	if(hc_id!="" && h_name!="" && h_own_name!="" && h_addr!="" && h_pincode!="" && flno!="" && paytmn!="" && discnt!="" && h_amt!="" ){
		//alert(head+"xxxx"+desc);
	var formData = new FormData($('#hform')[0]);
    $.ajax({
        url: 'save_hotels.php',
        type: 'POST',
        data: formData,
        async: false,
        success: function (data) {
		if(data == "Success")
		{ 
		$('#hform').attr('onsubmit', 'adhotel()');
		  $('#hform')[0].reset();
			$('#sucess').text(" Offers Added successfully");
			$('.toast-top-right').show();
			$('.toast-top-right').focus();
			$('.toast-top-right').fadeOut(5000);
		}
		else
		{ 
		$('#hform').attr('onsubmit', 'adhotel()');
		 $('#error').html(data);
			$('.toast-top-center').show();
			$('.toast-top-center').focus();
			$('.toast-top-center').fadeOut(5000);
			$('#hform')[0].reset();
		}
        },
        cache: false,
        contentType: false,
        processData: false
    });
	}else{
		$('#hform').attr('onsubmit', 'adhotel()');
			$('#error').text("Please Fill All Mandatory Fields");
			$('.toast-top-center').show();
			$('.toast-top-center').focus();
			$('.toast-top-center').fadeOut(5000);
			$('#hform')[0].reset();
	}
}
   </script>
   		 <script type="text/javascript" >
  function adcatitem(){
	  $('#icform').attr('onsubmit', 'aaaa');
	 var ic_name=$("#ic_name").val();
	 var h_id=$("#h_id").val();
	if(ic_name!="" && h_id!=""){
		//alert(head+"xxxx"+desc);
	var form = $("#icform");
	$.ajax({
            type: 'POST',
            url: 'save_icdata.php',
            data: form.serialize(),
            success: function(data){  
			//alert(data);
		if(data == "Success")
		{ 
		$('#icform').attr('onsubmit', 'adcatitem()');
		  $('#icform')[0].reset();
			$('#sucess').text(" Categories Added successfully");
			$('.toast-top-right').show();
			$('.toast-top-right').focus();
			$('.toast-top-right').fadeOut(5000);
		}
		else
		{ 
		$('#icform').attr('onsubmit', 'adcatitem()');
		 $('#error').html(data);
			$('.toast-top-center').show();
			$('.toast-top-center').focus();
			$('.toast-top-center').fadeOut(5000);
			$('#icform')[0].reset();
		}
        }
    });
	}else{
		$('#icform').attr('onsubmit', 'adcatitem()');
			$('#error').text("Please Fill All Mandatory Fields");
			$('.toast-top-center').show();
			$('.toast-top-center').focus();
			$('.toast-top-center').fadeOut(5000);
			$('#icform')[0].reset();
	}
}
   </script>
      <script>
function catfch(hid)
	{
		//alert(hid);
		$.ajax({
		 type	: "POST",
		 url	: "setcat.php",
		 data   : {hid:hid},
		 success: function(result){
			// alert(result);
                $('#subtab1').html(result);	
	        }	
        });
	}
</script>
<script type="text/javascript" >
  function aditem(){
	  $('#iform').attr('onsubmit', 'aaaa');
	 var ici_name=$("#ici_name").val();
	 var ici_price=$("#ici_price").val();
	 var hi_id=$("#hi_id").val();
	 var catpar=$("#catpar").val();
	 //alert(ici_name+"xxxx"+catpar+"xxxxx"+hi_id+"xxx"+ici_price);
	if(ici_name!="" && hi_id!="" && catpar!=""){
		
	var form = $("#iform");
	$.ajax({
            type: 'POST',
            url: 'save_idata.php',
            data: form.serialize(),
            success: function(data){  
			//alert(data);
		if(data == "Success")
		{ 
		$('#iform').attr('onsubmit', 'aditem()');
		  $('#iform')[0].reset();
			$('#sucess').text(" Item Added successfully");
			$('.toast-top-right').show();
			$('.toast-top-right').focus();
			$('.toast-top-right').fadeOut(5000);
		}
		else
		{ 
		$('#iform').attr('onsubmit', 'aditem()');
		 $('#error').html(data);
			$('.toast-top-center').show();
			$('.toast-top-center').focus();
			$('.toast-top-center').fadeOut(5000);
			$('#iform')[0].reset();
		}
        }
    });
	}else{
		$('#iform').attr('onsubmit', 'aditem()');
			$('#error').text("Please Fill All Mandatory Fields");
			$('.toast-top-center').show();
			$('.toast-top-center').focus();
			$('.toast-top-center').fadeOut(5000);
			$('#iform')[0].reset();
	}
}
   </script>
  </head>
  <body>
  <section id="container" class="">
      <!--header start-->
      <?php require_once("header.php"); ?>
      <!--sidebar end-->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
              <!-- page start-->
              <div class="row">
                  <div class="col-lg-6">
				  <section class="panel">
                          <header class="panel-heading">
                              Hotel Categories
                          </header>
                          <div class="panel-body">
                              <form id="hcform" action='javascript:;' name="hcform" onsubmit="adchotel()" Method="POST" enctype="multipart/form-data">
                                  <div class="form-group">
                                      <input type="text" class="form-control" id="hc_name" name="hc_name" placeholder="Hotel Category Heading">
                                  </div>
                                  <div class="form-group">
                                      <input class="form-control" type="file" name="iconimg" id="iconimg">
                                  </div>
                                  <input type="submit" id="hcsubmit" name="hcsubmit" value="Submit" class="btn btn-info">
                              </form>

                          </div>
                      </section>
                      <section class="panel">
                          <header class="panel-heading">
                              Hotel Forms
                          </header>
                          <div class="panel-body">
                              <form id="hform" action='javascript:;' name="hform" onsubmit="adhotel()" Method="POST" enctype="multipart/form-data">
							  <div class="form-group">
                                   <select class="form-control" id="hc_id" name="hc_id" >
									<option value="">Select Hotel</option>
								                                    <?php
	$shwhc = $auth_user->shwhc($user_id);
	foreach ($shwhc as $shwhcli){
	$hc_name=$shwhcli['hc_name'];
	$hc_id=$shwhcli['hc_id'];
			?>
								<option value="<?php echo $hc_id ; ?>"><?php echo $hc_name ; ?></option>
	<?php } ?>				
									  </select>
                                  </div>
                                  <div class="form-group">
                                      <input type="text" class="form-control" id="h_name" name="h_name" placeholder="Hotel Name">
                                  </div>
                                  <div class="form-group">
                                      <input type="text" class="form-control" id="h_own_name" name="h_own_name" placeholder="Hotel Owner Name">
                                  </div>
								  <div class="form-group">
                                      <input type="text" class="form-control" id="h_addr" name="h_addr"  placeholder="Hotel Address">
                                  </div>
								  <div class="form-group">
                                      <input type="text" class="form-control" id="h_pincode" name="h_pincode" placeholder="Hotel Pincode">
                                  </div>
								  <div class="form-group">
                                      <input type="text" class="form-control" id="flno"  name="flno"  placeholder="Food license No">
                                  </div>
								  <div class="form-group">
                                      <input type="text" class="form-control" id="paytmn" name="paytmn" placeholder="Hotel paytm no">
                                  </div>
                                      <input type="text" class="form-control" id="discnt" name="discnt" placeholder="Discount">
								  <div class="form-group">
                                  </div>
								  <div class="form-group">
                                      <input type="text" class="form-control" id="h_amt" name="h_amt" placeholder="Hotel Amount">
                                  </div>
                                  <div class="form-group">
                                      <input class="form-control" type="file" name="profileimg" id="profileimg">
                                  </div>
                                  <input type="submit" id="hsubmit" name="hsubmit" value="Submit" class="btn btn-info">
                              </form>

                          </div>
                      </section>
                  </div>
				<div class="col-lg-6">
                      <section class="panel">
                          <header class="panel-heading">
                              Categories Form
                          </header>
                          <div class="panel-body">
                               <form id="icform" action='javascript:;' name="icform" onsubmit="adcatitem()" Method="POST">
                                  <div class="form-group">
                                      <input type="text" class="form-control" id="ic_name"     name="ic_name" placeholder="Category Heading">
                                  </div>
                                  <div class="form-group">
                                   <select class="form-control" id="h_id" name="h_id" >
									<option value="">Select Hotel</option>
								                                    <?php
	$shwhotels = $auth_user->shwhotels($user_id);
	foreach ($shwhotels as $shwhotelsli){
	$h_name	=$shwhotelsli['h_name'];
	$h_id=$shwhotelsli['h_id'];
			?>
								<option value="<?php echo $h_id ; ?>"><?php echo $h_name ; ?></option>
	<?php } ?>				
									  </select>
                                  </div>
                                 <input type="submit" id="isubmit" name="isubmit" value="Submit" class="btn btn-info">
                              </form>
                          </div>
                      </section>
                  </div>
				  		<div class="col-lg-6">
                      <section class="panel">
                          <header class="panel-heading">
                              Items Form
                          </header>
                          <div class="panel-body">
                               <form id="iform" action='javascript:;' name="iform" onsubmit="aditem()" Method="POST">
								<div class="form-group">
                                    <select class="form-control" id="hi_id" name="hi_id" onchange='catfch(this.value)'>
									<option value="">Select Hotel</option>
								        <?php
											$shwhotels = $auth_user->shwhotels($user_id);
											foreach ($shwhotels as $shwhotelsli){
											$h_name	=$shwhotelsli['h_name'];
											$h_id=$shwhotelsli['h_id'];
										?>
								<option value="<?php echo $h_id ; ?>"><?php echo $h_name ; ?></option>
								<?php } ?>				
									</select>
                                </div>
								  <div id="subtab1" class="form-group">
								  
                                  </div>
								  
                                  <div class="form-group">
                                      <input type="text" class="form-control" id="ici_name" name="ici_name" placeholder="Item Heading">
                                  </div>
								  <div class="form-group">
                                      <input type="text" class="form-control" id="ici_price" name="ici_price" placeholder="Item Price">
                                  </div>
                                 <input type="submit" id="isubmit" name="isubmit" value="Submit" class="btn btn-info">
                              </form>
                          </div>
                      </section>
                  </div>
              </div>
              
              <!-- page end-->
          </section>
      </section>
      <!--main content end-->
      <!-- Right Slidebar start -->
      <!-- Right Slidebar end -->
      <!--footer start-->
      <!--footer end-->
  </section>
	   <div id="toast-container" style="display:none; " class="toast-top-right" aria-live="polite" role="alert"><div class="toast toast-success"><div class="toast-progress" style="width: 99.9218%;"></div><button type="button" class="toast-close-button" role="button">×</button><div class="toast-title">Toastr Notification</div><div id="sucess" class="toast-message"> </div></div></div>
	  <div  id="toast-container"style="display:none; " class="toast-top-center" aria-live="polite" role="alert"><div class="toast toast-error"><button type="button" class="toast-close-button" role="button">×</button><div class="toast-title">Error Notification</div><div id="error" class="toast-message"></div></div></div>
  </section>
    <!-- js placed at the end of the document so the pages load faster -->
    <script src="views/js/jquery.js"></script>
    <script src="views/js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="views/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="views/js/jquery.scrollTo.min.js"></script>
    <script src="views/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script type="text/javascript" src="views/js/jquery.validate.min.js"></script>
    <script src="views/js/respond.min.js" ></script>
  <!--right slidebar-->
  <script src="views/js/slidebars.min.js"></script>
    <!--common script for all pages-->
    <script src="views/js/common-scripts.js"></script>
  <script type="text/javascript" src="views/assets/fuelux/js/spinner.min.js"></script>
  <script type="text/javascript" src="views/assets/bootstrap-fileupload/bootstrap-fileupload.js"></script>
  <script type="text/javascript" src="views/assets/bootstrap-wysihtml5/wysihtml5-0.3.0.js"></script>
  <script type="text/javascript" src="views/assets/bootstrap-wysihtml5/bootstrap-wysihtml5.js"></script>
  <script type="text/javascript" src="views/assets/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
  <script type="text/javascript" src="views/assets/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js"></script>
  <script type="text/javascript" src="views/assets/bootstrap-daterangepicker/moment.min.js"></script>
  <script type="text/javascript" src="views/assets/bootstrap-daterangepicker/daterangepicker.js"></script>
  <script type="text/javascript" src="views/assets/bootstrap-colorpicker/js/bootstrap-colorpicker.js"></script>
  <script type="text/javascript" src="views/assets/bootstrap-timepicker/js/bootstrap-timepicker.js"></script>
  <script type="text/javascript" src="views/assets/jquery-multi-select/js/jquery.multi-select.js"></script>
  <script type="text/javascript" src="views/assets/jquery-multi-select/js/jquery.quicksearch.js"></script>
  <script src="views/js/advanced-form-components.js"></script>
    <!--script for this page-->
    <script src="views/js/form-validation-script.js"></script>

  </body>

<!-- Mirrored from thevectorlab.net/flatlab/form_component.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 12 Feb 2015 10:27:19 GMT -->
</html>
