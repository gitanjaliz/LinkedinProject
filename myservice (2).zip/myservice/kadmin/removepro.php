<?php
// Include necessary files
require_once("config/dbconfig.php");  // Ensure this contains the PDO connection setup
//require_once("lock.php");  // Ensure you have proper authorization

// Check if the service ID is passed via POST request
if (isset($_POST['sid'])) {
    $sid = $_POST['sid'];

    // Validate the service ID (check if it's a valid integer)
    if (filter_var($sid, FILTER_VALIDATE_INT)) {
        
        // Prepare the query to delete the service
        $query = "DELETE FROM services WHERE s_id = :sid";
        $stmt = $conn->prepare($query);

        // Bind the service ID to the query
        $stmt->bindParam(':sid', $sid, PDO::PARAM_INT);
        
        // Execute the query and check if it was successful
        if ($stmt->execute()) {
            echo "Success";  // Return success message if deletion is successful
        } else {
            echo "Failed to remove the service.";  // Return error message
        }
    } else {
        echo "Invalid service ID.";  // Handle invalid service ID
    }
} else {
    echo "Invalid request.";  // Handle missing service ID in the request
}
?>
