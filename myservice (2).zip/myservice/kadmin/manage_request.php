<?php 
require_once('config/dbconfig.php'); // Include your database class
require_once('lock.php');

// Check if 'id' is passed in the URL (instead of 'sb_id')
if (isset($_GET['id'])) {
    $sb_id = $_GET['id'];  // Use 'id' instead of 'sb_id' to match URL parameter
    echo "Service Booking ID: " . $sb_id; // Debugging line to show sb_id value

    // Fetch service request details based on sb_id
    $database = new Database();
    $conn = $database->dbConnection();

    // Query to fetch service booking data
    $stmt = $conn->prepare("SELECT s.*, cc.s_head, c.u_name as fullname, c.u_email, c.u_cont, c.u_addr, s.status
    FROM `sbook` s
    INNER JOIN `services` cc ON s.s_id = cc.s_id 
    INNER JOIN `user` c ON s.u_id = c.u_id 
    WHERE s.sb_id = :id");
    
    $stmt->bindParam(":id", $sb_id, PDO::PARAM_INT);
    $stmt->execute();

    // Fetch the service booking data
    $service_data = $stmt->fetch(PDO::FETCH_ASSOC);

    // If no data found, show an error message
    if (!$service_data) {
        echo "Service request not found!";
        exit;
    }

    // Assign variables from the fetched data
    $fullname = $service_data['fullname'];
    $u_email = $service_data['u_email'];
    $u_cont = $service_data['u_cont'];
    $u_addr = $service_data['u_addr'];
    $s_head = $service_data['s_head'];
    $status = $service_data['status'];  // Add status field from the database
} else {
    echo "Error: Service Booking ID (id) is required.";
    exit;
}



// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['m_id'], $_POST['status'], $_POST['sb_id']) && !empty($_POST['sb_id'])) {
        // Retrieve form data
        $m_id = $_POST['m_id'];
        $status = $_POST['status'];
        $sb_id = $_POST['sb_id'];

        // Update the service request status and assigned mechanic
        $updateStmt = $conn->prepare("UPDATE `sbook` SET m_id = :m_id, assigned_to = :m_id, status = :status WHERE sb_id = :sb_id");
        $updateStmt->bindParam(':m_id', $m_id);
        $updateStmt->bindParam(':status', $status);
        $updateStmt->bindParam(':sb_id', $sb_id);

        if ($updateStmt->execute()) {
            echo "<script>alert('Service request updated successfully!');</script>";
        } else {
            echo "<script>alert('Error updating service request.');</script>";
        }
    } else {
        echo "<script>alert('Error: Missing required fields.');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta and title -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Service Request</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            max-width: 800px;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .status-badge {
            font-size: 0.9rem;
            font-weight: bold;
        }
        .btn-primary {
            background-color: #007bff;
        }
    </style>
</head>
<body>
<div class="container mt-4">
    <h3 class="mb-4 text-center">Manage Service Request</h3>
    <?php if (isset($service_data)): ?>
        <form action="" method="POST">
            <input type="hidden" name="sb_id" value="<?php echo $sb_id; ?>">

            <!-- Owner Details -->
            <div class="form-group">
                <label>Owner Full Name</label>
                <input type="text" class="form-control" value="<?php echo $fullname; ?>" disabled>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" class="form-control" value="<?php echo $u_email; ?>" disabled>
            </div>
            <div class="form-group">
                <label>Contact</label>
                <input type="text" class="form-control" value="<?php echo $u_cont; ?>" disabled>
            </div>
            <div class="form-group">
                <label>Address</label>
                <textarea class="form-control" rows="2" disabled><?php echo $u_addr; ?></textarea>
            </div>
            <div class="form-group">
                <label>Service</label>
                <textarea class="form-control" rows="2" disabled><?php echo $s_head; ?></textarea>
            </div>

            <!-- Current Status -->
            <div class="form-group">
                <label>Current Status</label>
                <span class="badge badge-<?php echo $status == 0 ? 'warning' : ($status == 1 ? 'success' : 'secondary'); ?> status-badge">
                    <?php
                    switch ($status) {
                        case 0: echo "Pending"; break;
                        case 1: echo "Confirmed"; break;
                        case 2: echo "On-Progress"; break;
                        case 3: echo "Done"; break;
                        case 4: echo "Cancelled"; break;
                    }
                    ?>
                </span>
            </div>

            <!-- Assign Mechanic -->
            <div class="form-group">
                <label>Assign to Mechanic</label>
               
                <select name="m_id" id="m_id" class="form-control" required>
                    <option value="" disabled>Select Mechanic</option>
                    <?php 
                    $stmt = $conn->prepare("SELECT * FROM `service_man` ORDER BY `username` ASC");
                    $stmt->execute();
                    while ($mechanic = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
                        <option value="<?php echo $mechanic['m_id']; ?>">
                            <?php echo $mechanic['username']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>

            <!-- Update Status -->
            <div class="form-group">
                <label>Status</label>
                <select name="status" class="form-control" required>
                    <option value="0" <?php echo $status == 0 ? "selected" : ''; ?>>Pending</option>
                    <option value="1" <?php echo $status == 1 ? "selected" : ''; ?>>Confirmed</option>
                    <option value="2" <?php echo $status == 2 ? "selected" : ''; ?>>On-Progress</option>
                    <option value="3" <?php echo $status == 3 ? "selected" : ''; ?>>Done</option>
                    <option value="4" <?php echo $status == 4 ? "selected" : ''; ?>>Cancelled</option>
                </select>
            </div>

            <!-- Submit -->
            <button type="submit" class="btn btn-primary btn-block">Save Changes</button>
            <button type="button" class="btn btn-secondary btn-danger" onclick="window.history.back()">Cancel</button>
        </form>
    <?php else: ?>
        <div class="alert alert-danger">No data found for the given Service Booking ID.</div>
    <?php endif; ?>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js"></script>
<script>
    // Search Mechanic
    document.getElementById('searchMechanic').addEventListener('input', function () {
        const filter = this.value.toLowerCase();
        const options = document.querySelectorAll('#m_id option');
        options.forEach(option => {
            option.style.display = option.text.toLowerCase().includes(filter) ? 'block' : 'none';
        });
    });
</script>
</body>
</html>
