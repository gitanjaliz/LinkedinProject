<?php 
//error_reporting(0);
require_once("lock.php");
$outh_url=$_GET['source_ref'];
if(empty($_GET['source_ref'])) {
  header("location: 404");
}
else{
	$grandtotal="0"; $hoid = array();
	$getobil=$auth_user->getobil($outh_url);
	if($getobil<=0){
	 header("location: 404");
	}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Katareinfo">
    <meta name="keyword" content="Katareinfo, Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
    <link rel="shortcut icon" href="img/favicon.html">

    <title>Invoice</title>

    <!-- Bootstrap core CSS -->
    <link href="views/css/bootstrap.min.css" rel="stylesheet">
    <link href="views/css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="views/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
      <!--right slidebar-->
      <link href="views/css/slidebars.css" rel="stylesheet">
      <!-- Custom styles for this template -->
    <link href="views/css/style.css" rel="stylesheet">
    <link href="views/css/style-responsive.css" rel="stylesheet" />
    <link href="views/css/invoice-print.css" rel="stylesheet" media="print">
  </head>

  <body>

  <section id="container" class="">
      <!--header start-->
<?php require_once("header.php"); ?>
      <!--sidebar end-->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
              <!-- invoice start-->
              <section>
                  <div class="panel panel-primary">
                      <!--<div class="panel-heading navyblue"> INVOICE</div>-->
                      <div class="panel-body">
                          <div class="row invoice-list">
                              <div class="text-center corporate-id">
                                  <img style="width:20%;" src="views/img/lg.png" alt="">
                              </div>
                          </div>
                          <table class="table table-striped table-hover">
                              <thead>
							  
                              <tr>
                                  <th>#</th>
                                  <th>Item</th>
                                  <th class="hidden-phone">Description</th>
                                  <th class="">Unit Cost</th>
                                  <th class="">Quantity</th>
                              </tr>
                              </thead>
                              <tbody>
							 <?php  foreach($getobil as $getobill){
						$i_id=$getobill['i_id'];
						$cr_id=$getobill['cr_id'];
						$ocode=$getobill['o_code'];
						$o_auth=md5($ocode);
						$price=$getobill['price'];
						$cr_tot=$getobill['cr_tot'];
						$cr_qty=$getobill['cr_qty'];
						$grandtotal += $cr_tot;
						$hoid[]=$getobill['h_id'];
						$o_addr=$getobill['o_addr'];
						$sts_flag=$getobill['sts_flag'];	
						$on_id=$getobill['on_id'];						
						?>
                              <tr>
							  <div class="store-history-item">
                                  <td>#</td>
                                  <td><?php echo $getobill['ic_name']; ?></td>
                                  <td ><?php echo $getobill['h_name']; ?></td>
                                  <td class=""><?php echo $cr_tot; ?></td>
                                  <td class=""><?php echo $cr_qty; ?></td>
                              </tr>
							 <?php } ?>
                              </tbody>
                          </table>
                          <div class="row">
						  <div class="col-lg-6 invoice-block pull-left">
						  <ul class="unstyled amounts">
					<li><strong>Delivery Address :</strong><?php echo $o_addr; ?></li>
                </ul>
                              </div>
                              <div class="col-lg-4 invoice-block pull-right">
                <ul class="unstyled amounts">
					<li><strong>Order ID :</strong><?php echo $on_id; ?></li>
                    <li><strong>Total amount :</strong><?php echo $grandtotal; ?></li>
					<li><strong>Delivery :</strong> Rs. 40.00/-</li>
					<li><strong>Grand Total amount :</strong><?php echo $grandtotal+40; ?></li>
                </ul>
                              </div>
                          </div>
                          <div class="text-center invoice-btn">
						  <?php if($sts_flag==0){ ?>
                              <a onclick="done('<?php echo $on_id ;?>')" class="btn btn-danger btn-lg"><i class="fa fa-check"></i> Done Order </a>
							<?php  } ?>
                              <a class="btn btn-info btn-lg" onclick="javascript:window.print();"><i class="fa fa-print"></i> Print </a>
                          </div>
                      </div>
                  </div>
              </section>
              <!-- invoice end-->
          </section>
      </section>
      <!--main content end-->
      <!-- Right Slidebar end -->
      <!--footer start-->
      <footer class="site-footer">
          <div class="text-center">
              2017 &copy; Katareinfo by Katareinfo.
              <a href="#" class="go-top">
                  <i class="fa fa-angle-up"></i>
              </a>
          </div>
      </footer>
      <!--footer end-->
  </section>
  
    <!-- js placed at the end of the document so the pages load faster -->
    <script src="views/js/jquery.js"></script>
    <script src="views/js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="views/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="views/js/jquery.scrollTo.min.js"></script>
    <script src="views/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="views/js/respond.min.js" ></script>
  <!--right slidebar-->
  <script src="views/js/slidebars.min.js"></script>
    <!--common script for all pages-->
    <script src="views/js/common-scripts.js"></script>
		<script type="text/javascript">
function done(on_id){ 
		if (confirm("Complete This Order") == true) {
	$.ajax({
            type: 'POST',
            url: 'cmpob.php',
            data: {on_id:on_id},
            success: function(data){ 
			if(data == "Success")
		{ 
			$('#sucess').text("Order successfully Completed");
			$('.toast-top-right').show();
			$('.toast-top-right').focus();
			$('.toast-top-right').fadeOut(5000); 
			location.reload();
		}
		else
		{ 
		//alert(data);
		 $('#error').text("Please Fill All Mandatory Fields");
			$('.toast-top-center').show();
			$('.toast-top-center').focus();
			$('.toast-top-center').fadeOut(5000);
			//$('#fform')[0].reset();
		}
		}                                    	  
         });  
	}else{
			$('#error').text("Completion Failed");
			$('.toast-top-center').show();
			$('.toast-top-center').focus();
			$('.toast-top-center').fadeOut(5000);
			//$('#fform')[0].reset();
	}	 
	}
</script>
  </body>
</html>
