<?php
// Include database connection
require_once('config/dbconfig.php');

if (isset($_POST['mechanic_id'])) {
    $mechanicId = $_POST['mechanic_id'];

    // Update the sbook table with the assigned mechanic
    $stmt = $conn->prepare("UPDATE `sbook` SET `assigned_to` = :mechanic_id WHERE `status` = 'Pending'"); // You can modify the WHERE condition based on your needs
    $stmt->bindParam(':mechanic_id', $mechanicId, PDO::PARAM_INT);
    
    if ($stmt->execute()) {
        echo 'success'; // Return success response
    } else {
        echo 'error'; // Return error if the query fails
    }
} else {
    echo 'error'; // Return error if mechanic_id is not passed
}
?>
