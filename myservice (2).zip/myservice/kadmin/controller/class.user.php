<?php
require_once('config/dbconfig.php');

class USER
{	

	private $conn;
	
	public function __construct()
	{
		$database = new Database();
		$db = $database->dbConnection();
		$this->conn = $db;
    }
	
	public function runQuery($sql)
	{
		$stmt = $this->conn->prepare($sql);
		return $stmt;
	}
	
	public function userfetch($csalt)
	{
		try
		{
			$stmt = $this->conn->prepare("SELECT * FROM users WHERE salt=:csalt");
			$stmt->execute(array(':csalt'=>$csalt));
			$userfetch=$stmt->fetch(PDO::FETCH_ASSOC);
			return $userfetch;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}
	}
	
	public function userchk($uname,$umail)
	{
		try
		{
			$stmt = $this->conn->prepare("SELECT user_id, user_name, user_email, user_pass FROM users WHERE user_name=:uname OR user_email=:umail ");
			$stmt->execute(array(':uname'=>$uname, ':umail'=>$umail));
			$userchk=$stmt->fetch(PDO::FETCH_ASSOC);
			return $userchk;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}
	}
	
	public function register($uname,$umail,$upass)
	{
		try
		{
			$new_password = password_hash($upass, PASSWORD_DEFAULT);
			
			$stmt = $this->conn->prepare("INSERT INTO users(user_name,user_email,user_pass) 
		                                               VALUES(:uname, :umail, :upass)");
												  
			$stmt->bindparam(":uname", $uname);
			$stmt->bindparam(":umail", $umail);
			$stmt->bindparam(":upass", $new_password);										  
				
			$stmt->execute();	
			
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}
	
	
	public function doLogin($uname,$umail,$upass)
	{
		try
		{
			$stmt = $this->conn->prepare("SELECT user_id, user_name, user_email, user_pass FROM users WHERE user_name=:uname OR user_email=:umail ");
			$stmt->execute(array(':uname'=>$uname, ':umail'=>$umail));
			$userRow=$stmt->fetch(PDO::FETCH_ASSOC);
			if($stmt->rowCount() == 1)
			{
				if(password_verify($upass, $userRow['user_pass']))
				{
				$myusername=$userRow['user_name'];
				$myuser_id=$userRow['user_id'];
				$salt=hash("sha512", rand() . rand() . rand());
				setcookie("c_user", hash("sha512", $myusername), time() + 24 * 60 * 60, "/");
				setcookie("c_salt", $salt,  time() + 24 * 60 * 60, "/");
				//return $salt;
				return array('salt'=>$salt, 'user_id'=>$myuser_id);
				}
				else
				{
					return false;
				}
			}
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}
	}
	
	public function updsalt($slt,$sluid)
	{
		try
		{
			$stmt = $this->conn->prepare("UPDATE users SET  salt =:slt WHERE user_id =:sluid");
			$stmt->bindparam(":slt", $slt);
			$stmt->bindparam(":sluid", $sluid);	
			$stmt->execute();
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}
	
	public function is_loggedin()
	{
		if(isset($_COOKIE["c_user"])  && isset($_COOKIE["c_salt"]))
		{
			return true;
		}
	}
	
	public function redirect($url)
	{
		header("Location: $url");
	}
	
	public function doLogout()
	{
		$cuser=$_COOKIE["c_user"]; 
		$csalt=$_COOKIE["c_salt"];
		setcookie("c_user", $cuser, time() - 24 * 60 * 60, "/");
		setcookie("c_salt", $csalt,  time() - 24 * 60 * 60, "/");
		return true;
	}
	
	//add history
	public function addvender($user_id, $v_name, $v_contact, $s_id, $v_email, $v_date, $v_amount, $v_addr, $v_flag, $v_uname, $v_pass)
	{
		try
		{
			$stmt = $this->conn->prepare("INSERT INTO vender (user_id, v_name, v_contact, s_id, v_email, v_date, v_amount, v_addr, v_flag, v_uname, v_pass) VALUES (:user_id, :v_name, :v_contact, :s_id, :v_email, :v_date, :v_amount, :v_addr, :v_flag, :v_uname, :v_pass)");					  
			$stmt->bindparam(":user_id", $user_id);
			$stmt->bindparam(":v_name", $v_name);
			$stmt->bindparam(":v_contact", $v_contact);
			$stmt->bindparam(":s_id", $s_id);
			$stmt->bindparam(":v_email", $v_email);
			$stmt->bindparam(":v_date", $v_date);
			$stmt->bindparam(":v_amount", $v_amount);
			$stmt->bindparam(":v_addr", $v_addr);
			$stmt->bindparam(":v_flag", $v_flag);
			$stmt->bindparam(":v_uname", $v_uname);
			$stmt->bindparam(":v_pass", $v_pass);
			$stmt->execute();
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}
	
	// fetch  service type
	public function shwser($user_id)
	{
		try
		{
	        $stmt = $this->conn->prepare("SELECT * FROM services where user_id= :user_id");
			$stmt->execute(array(':user_id'=>$user_id));
			$shwser=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $shwser;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
	}
	
	public function fetchvender($user_id)
	{
		try
		{
	        $stmt = $this->conn->prepare("SELECT v.*, s_head FROM vender v, services s where s.s_id=v.s_id AND v.user_id=:user_id");
			$stmt->execute(array('user_id'=>$user_id));
			$fetchvenders=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $fetchvenders;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
	}
	
	//add Services
	public function addservices($user_id, $s_head, $s_desc, $s_flag, $s_img, $s_icon, $s_type, $s_fees,$price_desc)
	{
		try
		{
			$stmt = $this->conn->prepare("INSERT INTO services (user_id, s_head, s_desc, s_flag, s_img, s_icon, s_type, s_fees, price_desc) VALUES (:user_id, :s_head, :s_desc, :s_flag, :s_img, :s_icon, :s_type, :s_fees, :price_desc)");
												  
			$stmt->bindparam(":user_id", $user_id);
			$stmt->bindparam(":s_head", $s_head);
			$stmt->bindparam(":s_desc", $s_desc);	
			$stmt->bindparam(":s_flag", $s_flag);
			$stmt->bindparam(":s_img", $s_img);
			$stmt->bindparam(":s_icon", $s_icon);
			$stmt->bindparam(":s_type", $s_type);
			$stmt->bindparam(":s_fees", $s_fees);
			$stmt->bindparam(":price_desc", $price_desc);
			$stmt->execute();
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}
	
	//add offers
	public function addoffers($o_head, $o_desc, $o_flag, $o_img, $o_time, $user_id)
	{
		try
		{
			$stmt = $this->conn->prepare("INSERT INTO offers (o_head, o_desc, o_flag, o_img, o_time, user_id) VALUES (:o_head, :o_desc, :o_flag, :o_img, :o_time, :user_id)");
			$stmt->bindparam(":o_head", $o_head);
			$stmt->bindparam(":o_desc", $o_desc);	
			$stmt->bindparam(":o_flag", $o_flag);
			$stmt->bindparam(":o_img", $o_img);
			$stmt->bindparam(":o_time", $o_time);
			$stmt->bindparam(":user_id", $user_id);
			$stmt->execute();
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}
	
		// fetch  Offers
	public function shwoffers($user_id)
	{
		try
		{
	        $stmt = $this->conn->prepare("SELECT * FROM offers where user_id= :user_id");
			$stmt->execute(array(':user_id'=>$user_id));
			$shwoffers=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $shwoffers;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
	}
	
		public function addhotels($hc_id, $h_name, $h_own_name, $h_addr, $h_pincode, $flno, $paytmn, $discnt, $h_img, $h_date, $h_amt, $user_id, $h_flag)
	{
		try
		{
			$stmt = $this->conn->prepare("INSERT INTO hotels (hc_id, h_name, h_own_name, h_addr, h_pincode, flno, paytmn, discnt, h_img, h_date, h_amt, user_id, h_flag) VALUES (:hc_id, :h_name, :h_own_name, :h_addr, :h_pincode, :flno, :paytmn, :discnt, :h_img, :h_date, :h_amt, :user_id, :h_flag)");
			$stmt->bindparam(":hc_id", $hc_id);					  
			$stmt->bindparam(":h_name", $h_name);
			$stmt->bindparam(":h_own_name", $h_own_name);
			$stmt->bindparam(":h_addr", $h_addr);
			$stmt->bindparam(":h_pincode", $h_pincode);
			$stmt->bindparam(":flno", $flno);
			$stmt->bindparam(":paytmn", $paytmn);
			$stmt->bindparam(":discnt", $discnt);
			$stmt->bindparam(":h_img", $h_img);
			$stmt->bindparam(":h_date", $h_date);
			$stmt->bindparam(":h_amt", $h_amt);
			$stmt->bindparam(":user_id", $user_id);
			$stmt->bindparam(":h_flag", $h_flag);
			$stmt->execute();
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}
	
	public function shwhotels()
	{
		try
		{
	        $stmt = $this->conn->prepare("SELECT * FROM hotels WHERE h_flag=1");
			$stmt->execute();
			$shwhotels=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $shwhotels;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
	}
	
	
	public function addcathead($user_id, $h_id, $ic_name, $ic_parent, $ic_flag, $ic_date)
	{
		try
		{
			$stmt = $this->conn->prepare("INSERT INTO itemcat (user_id, h_id, ic_name, ic_parent, ic_flag, ic_date) VALUES (:user_id, :h_id, :ic_name, :ic_parent, :ic_flag, :ic_date)");
												  
			$stmt->bindparam(":user_id", $user_id);
			$stmt->bindparam(":h_id", $h_id);
			$stmt->bindparam(":ic_name", $ic_name);
			$stmt->bindparam(":ic_parent", $ic_parent);
			$stmt->bindparam(":ic_flag", $ic_flag);
			$stmt->bindparam(":ic_date", $ic_date);
			$stmt->execute();
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}
			//add  addcatitem
	public function addcatitem($user_id, $h_id, $ic_name, $ic_parent, $ic_flag, $ic_date, $ici_price)
	{
		try
		{
			$stmt = $this->conn->prepare("INSERT INTO itemcat (user_id, h_id, ic_name, ic_parent, ic_flag, ic_date, price) VALUES (:user_id, :h_id, :ic_name, :ic_parent, :ic_flag, :ic_date, :ici_price)");
												  
			$stmt->bindparam(":user_id", $user_id);
			$stmt->bindparam(":h_id", $h_id);
			$stmt->bindparam(":ic_name", $ic_name);
			$stmt->bindparam(":ic_parent", $ic_parent);
			$stmt->bindparam(":ic_flag", $ic_flag);
			$stmt->bindparam(":ic_date", $ic_date);
			$stmt->bindparam(":ici_price", $ici_price);
			$stmt->execute();
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}
	
	public function shwcat($hid,$user_id)
	{
		try
		{
	        $stmt = $this->conn->prepare("SELECT * FROM itemcat WHERE h_id=:hid AND user_id=:user_id
			AND ic_parent=0");
			$stmt->execute(array(':hid'=>$hid,':user_id'=>$user_id));
			$shwcat=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $shwcat;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
	}
	
			//add  addcatitem
	public function addhc($user_id, $hc_name, $hc_icons, $hc_flag)
	{
		try
		{
			$stmt = $this->conn->prepare("INSERT INTO h_cat (user_id, hc_name, hc_icons, hc_flag) VALUES (:user_id, :hc_name, :hc_icons, :hc_flag)");
												  
			$stmt->bindparam(":user_id", $user_id);
			$stmt->bindparam(":hc_name", $hc_name);
			$stmt->bindparam(":hc_icons", $hc_icons);
			$stmt->bindparam(":hc_flag", $hc_flag);
			$stmt->execute();
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}
	
	public function shwhc($user_id)
	{
		try
		{
	        $stmt = $this->conn->prepare("SELECT * FROM h_cat WHERE hc_flag=1 AND user_id=:user_id");
			$stmt->execute(array(':user_id'=>$user_id));
			$shwhc=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $shwhc;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
	}
	
	public function fetchservreq()
{
    try
    {
        // Modify query to explicitly select the status from the sbook table
        $stmt = $this->conn->prepare("SELECT sb.*, u.*, s.*, sb.status FROM sbook sb 
                                      JOIN services s ON sb.s_id = s.s_id 
                                      JOIN user u ON sb.u_id = u.u_id 
                                      WHERE sb.sb_flag = 1 
                                      ORDER BY sb.sb_id DESC");
        $stmt->execute();
        $shwhc = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $shwhc;
    }
    catch(PDOException $e)
    {
        echo $e->getMessage();
    }   
}

	

	public function updateServiceRequest($id, $status, $assigned_to) {
		$stmt = $this->conn->prepare("UPDATE sbook SET status = ?, assigned_to = ? WHERE id = ?");
		$stmt->bindparam("isi", $status, $assigned_to, $id);
		return $stmt->execute();
	}
	
	public function fetchur()
	{
		try
		{
	        $stmt = $this->conn->prepare("SELECT * FROM user");
			$stmt->execute();
			$shwhc=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $shwhc;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
	}
	
		public function apprsb($sbid)
	{
		try
		{
			$stmt = $this->conn->prepare("UPDATE sbook SET  sb_flag = 2 WHERE sb_id =:sbid");
			$stmt->bindparam(":sbid", $sbid);
			$stmt->execute();
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}
	
	public function cntcart()
	{
		try
		{
	        $stmt = $this->conn->prepare("SELECT o.*,u.* 
			FROM obill o, user u WHERE o.u_id=u.u_id AND sts_flag=0  ORDER BY o_id DESC");
			$stmt->execute();
			$cntcart=$stmt->fetchAll(PDO::FETCH_ASSOC);
			//$cntcart=$stmt->rowCount();
			return $cntcart;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
	}
	
		public function getobil($ode)
	{
		try
		{
	        $stmt = $this->conn->prepare("SELECT c.*,h.h_name,h.h_id,ic.ic_name,ic.price,ob.o_addr ,ob.sts_flag
FROM cart c, hotels h, itemcat ic, obill ob
WHERE h.h_id=ic.h_id
AND c.i_id=ic.ic_id
AND c.on_id=ob.o_id
AND c.on_id = :ode");
			$stmt->execute(array(':ode'=>$ode));
			$cntcart=$stmt->fetchAll(PDO::FETCH_ASSOC);
			//$cntcart=$stmt->rowCount();
			return $cntcart;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
	}
	
		public function approbo($on_id)
	{
		try
		{
			$stmt = $this->conn->prepare("UPDATE  obill SET sts_flag = 2 WHERE  o_id =:on_id");
			$stmt->bindparam(":on_id", $on_id);
			$stmt->execute();
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}
	
	public function cmpcart()
	{
		try
		{
	        $stmt = $this->conn->prepare("SELECT o.*,u.* 
			FROM obill o, user u WHERE o.u_id=u.u_id AND sts_flag=2  ORDER BY o_id DESC");
			$stmt->execute();
			$cntcart=$stmt->fetchAll(PDO::FETCH_ASSOC);
			//$cntcart=$stmt->rowCount();
			return $cntcart;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
	}
	
	public function fetchcmpserv()
	{
		try
		{
	        $stmt = $this->conn->prepare("SELECT sb.*,u.*,s.* created_at FROM sbook sb, services s, user u WHERE sb.s_id= s.s_id AND sb.u_id=u.u_id AND sb_flag=2 ORDER BY sb.sb_id DESC");
			$stmt->execute();
			$shwhc=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $shwhc;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
	}
	public function fetchServiceMen() {
		try {
			$stmt = $this->conn->prepare("SELECT m_id, username FROM service_man");
			$stmt->execute();
			return $stmt->fetch(PDO::FETCH_ASSOC);
		} catch (PDOException $e) {
			echo "Error: " . $e->getMessage();
			return [];
		}
	}
	

	public function fetchAllServiceRequests() {
		$stmt = $this->conn->prepare("SELECT id, date_created, client_name, service, status FROM service_requests");
		$stmt->execute();
		//return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
	}
	
	
	
}
?>