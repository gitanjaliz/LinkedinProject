<?php
include('lock.php');
if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
{
	$hid=$_POST["hid"]; 
echo"<select id='catpar' name='catpar' class='form-control'  style='margin-bottom:10px;' >";
						echo"<option value=''>Please Select Caregory</option>";
					$shwcat = $auth_user->shwcat($hid,$user_id);
	foreach ($shwcat as $shwcatli){
						 echo "<option value='".$shwcatli['ic_id']."'>".$shwcatli['ic_name']."</option>";
	    } 								
						echo"</select>";
    } 
?>