<?php
require_once("lock.php");

if (isset($_POST['sbid']) && isset($_POST['serviceManId'])) {
    $sbid = $_POST['sbid'];
    $serviceManId = $_POST['serviceManId'];

    // Insert into services table (update this query to match your database structure)
    $stmt = $auth_user->runQuery("INSERT INTO services (s_id, service_man_id, status) VALUES (:sbid, :serviceManId, 'Confirmed')");
    $stmt->bindParam(':sbid', $sbid);
    $stmt->bindParam(':serviceManId', $serviceManId);

    if ($stmt->execute()) {
        echo "Success";
    } else {
        echo "Error";
    }
} else {
    echo "Invalid data";
}
?>
