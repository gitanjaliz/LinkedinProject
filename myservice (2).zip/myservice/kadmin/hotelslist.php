<?php require_once("lock.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Mosaddek">
    <meta name="keyword" content="FlatLab, Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
    <link rel="shortcut icon" href="views/img/favicon.html">

    <title><?php echo TITLE; ?></title>

    <!-- Bootstrap core CSS -->
    <link href="views/css/bootstrap.min.css" rel="stylesheet">
    <link href="views/css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="views/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="views/css/table-responsive.css" rel="stylesheet" />
      <!--right slidebar-->
      <link href="views/css/slidebars.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="views/css/style.css" rel="stylesheet">
    <link href="views/css/style-responsive.css" rel="stylesheet" />  
     <link rel="stylesheet" type="text/css" href="views/assets/bootstrap-datepicker/css/datepicker.css" />
    <link rel="stylesheet" type="text/css" href="views/assets/bootstrap-timepicker/compiled/timepicker.css" />
    <link rel="stylesheet" type="text/css" href="views/assets/bootstrap-colorpicker/css/colorpicker.css" />
    <link rel="stylesheet" type="text/css" href="views/assets/bootstrap-daterangepicker/daterangepicker-bs3.css" />
    <link rel="stylesheet" type="text/css" href="views/assets/bootstrap-datetimepicker/css/datetimepicker.css" />
  </head>

  <body>

  <section id="container" class="">
      <!--header start-->
       <?php include "header.php"; ?>
      <!--sidebar end-->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
              <!-- page start-->
              <div class="row">
                  <div class="col-lg-12" id="edit_view">
                      <section class="panel">
                          <header class="panel-heading">
                              Hotel List
                          </header>
                          <div class="panel-body">
                              <section id="no-more-tables">
                                  <table class="table table-bordered table-striped table-condensed cf">
                                      <thead class="cf">
										<tr>
                                           <th>Sr.No</th>
				  						   <th>Hotel Name </th>
										   <th>Hotel Owner Name</th>
                                           <th>Hotel Address</th>
										   <th>pincode</th>
										    <th>Food License No</th>
										   <th>Paytm No</th>
										   <th>Discount </th>
										   <th>Charges</th>
										    <th>Images</th>
											<th>Block</th>
										</tr>
                                      </thead>
                                      <tbody>
                                     <?php
	$shwhotels = $auth_user->shwhotels($user_id);
	foreach ($shwhotels as $shwhotelsli){
	$h_name	=$shwhotelsli['h_name'];
	$h_own_name=$shwhotelsli['h_own_name'];
	$h_addr = $shwhotelsli['h_addr'];
	$h_pincode =$shwhotelsli['h_pincode'];
	$flno=$shwhotelsli['flno'];
	$h_img=$shwhotelsli['h_img'];
	$paytmn=$shwhotelsli['paytmn'];
	$discnt=$shwhotelsli['discnt'];
	$h_amt=$shwhotelsli['h_amt'];
	$h_id=$shwhotelsli['h_id'];
	//$pr_imge = str_replace("../","",$pr_img);
			?>
                                      <tr>
                                          <td data-title=" Sr.No"><?php echo $h_id ;?></td>
                                          <td data-title=" Heading"><?php echo $h_name ;?></td>
										  <td data-title=" Description"><?php echo $h_own_name ;?></td>
                                         <td data-title=" Description"><?php echo $h_addr ;?></td>
										    <td data-title=" Description"><?php echo $h_pincode ;?></td>
											  <td data-title=" Description"><?php echo $flno ;?></td>
<td data-title=" Description"><?php echo $paytmn ;?></td>
												  <td data-title=" Description"><?php echo $discnt ;?></td>
												   <td data-title=" Description"><?php echo $h_amt ;?></td>
												  <td  data-title="img"><img style="width:50%;" src="<?php echo $h_img ;?>" /></td>
										   <td class="Action" data-title="Edit/ Action"><a href="#" onclick="removepro(<?php echo $pr_id ;?>)"  class="btn btn-primary">Block</a>
                                      </tr>
									   <?php } ?>
                                     
                                      </tbody>
                                  </table>
                              </section>
                          </div>
                      </section>
                  </div>
              </div>
              <!-- page end-->
          </section>
      </section>
      <!--main content end-->
	 <div id="toast-container" style="display:none; " class="toast-top-right" aria-live="polite" role="alert"><div class="toast toast-success"><div class="toast-progress" style="width: 99.9218%;"></div><button type="button" class="toast-close-button" role="button">×</button><div class="toast-title">Toastr Notification</div><div id="sucess" class="toast-message"> </div></div></div>
	  <div  id="toast-container"style="display:none; " class="toast-top-center" aria-live="polite" role="alert"><div class="toast toast-error"><button type="button" class="toast-close-button" role="button">×</button><div class="toast-title">Error Notification</div><div id="error" class="toast-message"></div></div></div>
      <!--footer start-->
 
      <!--footer end-->
  </section>

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="views/js/jquery.js"></script>
    <script src="views/js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="views/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="views/js/jquery.scrollTo.min.js"></script>
    <script src="views/js/respond.min.js" ></script>
    <script src="views/js/jquery.nicescroll.js" type="text/javascript"></script>
	<script type="text/javascript" src="views/assets/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
  <script type="text/javascript" src="views/assets/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js"></script>
  <script type="text/javascript" src="views/assets/bootstrap-daterangepicker/moment.min.js"></script>
  <script type="text/javascript" src="views/assets/bootstrap-daterangepicker/daterangepicker.js"></script>
  <link href="views/assets/toastr-master/toastr.css" rel="stylesheet" type="text/css" />
  <!--right slidebar-->
  <script src="views/js/slidebars.min.js"></script>

    <!--common script for all pages-->
    <script src="views/js/common-scripts.js"></script>
    <script src="views/js/advanced-form-components.js"></script>
	<script type="text/javascript">
function removepro(prid){ 
		if (confirm("Remove Selected Product ") == true) {
	$.ajax({
            type: 'POST',
            url: 'removepro.php',
            data: {prid:prid},
            success: function(data){ 
			if(data == "Success")
		{ 
			$('#sucess').text("Product Removed successfully");
			$('.toast-top-right').show();
			$('.toast-top-right').focus();
			$('.toast-top-right').fadeOut(5000); 
			location.reload();
		}
		else
		{ 
		//alert(data);
		 $('#error').text("Please Fill All Mandatory Fields");
			$('.toast-top-center').show();
			$('.toast-top-center').focus();
			$('.toast-top-center').fadeOut(5000);
			//$('#fform')[0].reset();
		}
		}                                    	  
         });  
	}else{
			$('#error').text("Remove Failed");
			$('.toast-top-center').show();
			$('.toast-top-center').focus();
			$('.toast-top-center').fadeOut(5000);
	}	 
	}
</script>
  </body>
</html>
