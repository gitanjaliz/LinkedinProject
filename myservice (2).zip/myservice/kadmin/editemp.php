<?php    
require_once("lock.php"); 
require_once("config/dbconfig.php");

// Database connection
$database = new Database();
$conn = $database->dbConnection();

if (!$conn) {
    echo "Database connection failed!";
    exit;
}

// Handle form submission for update
if (isset($_POST['empupdate'])) {
    // Check for empty fields
    if (empty($_POST['username']) || empty($_POST['address']) || empty($_POST['contact']) || empty($_POST['email'])) {
        $msg = '<div class="alert alert-warning" role="alert">Please fill all fields</div>';
    } else {
        // Assign values to variables
        $m_id = $_POST['m_id'];
        $username = $_POST['username'];
        $address = $_POST['address'];
        $contact = $_POST['contact'];
        $email = $_POST['email'];
        
        // Update query with prepared statements
        try {
            $sql = "UPDATE service_man SET username = :username, address = :address, contact = :contact, email = :email WHERE m_id = :m_id";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':username', $username);
            $stmt->bindParam(':address', $address);
            $stmt->bindParam(':contact', $contact);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':m_id', $m_id);
            
            if ($stmt->execute()) {
                $msg = '<div class="alert alert-success" role="alert">Updated Successfully</div>';
            } else {
                $msg = '<div class="alert alert-danger" role="alert">Unable to update</div>';
            }
        } catch (PDOException $e) {
            $msg = '<div class="alert alert-danger" role="alert">Error: ' . $e->getMessage() . '</div>';
        }
    }
}

// Fetch technician data
if (isset($_REQUEST['view'])) {
    try {
        $m_id = $_REQUEST['id'];
        $sql = "SELECT * FROM service_man WHERE m_id = :m_id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':m_id', $m_id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$row) {
            die('<div class="alert alert-danger">No technician found with the given ID.</div>');
        }
    } catch (PDOException $e) {
        die('<div class="alert alert-danger">Error: ' . $e->getMessage() . '</div>');
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta and title -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Mosaddek">
    <meta name="keyword" content="FlatLab, Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
    <link rel="shortcut icon" href="views/img/favicon.html">

    <title><?php echo defined('TITLE') ? TITLE : 'Technician List'; ?></title>

    <!-- Stylesheets -->
    <link href="views/css/bootstrap.min.css" rel="stylesheet">
    <link href="views/css/bootstrap-reset.css" rel="stylesheet">
    <link href="views/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="views/css/table-responsive.css" rel="stylesheet" />
    <link href="views/css/style.css" rel="stylesheet">
    <link href="views/css/style-responsive.css" rel="stylesheet">  
</head>
<body>
<section id="container" class="">
    <!-- Header -->
    <?php include "header.php"; ?>
    
    <!-- Main content -->
    <section id="main-content">
        <section class="wrapper">
            <div class="row">
                <div class="col-lg-12" id="edit_view">
                    <section class="panel">
                        <header class="panel-heading">
                            Servicer Details
                        </header>
<!-- HTML Form -->
<div class="col-sm-6 mt-5 mx-3 jumbotron">
    <h3 class="text-center">Update Technician Details</h3>
    <form action="" method="POST">
        <div class="form-group">
            <label for="m_id">Emp ID</label>
            <input type="text" class="form-control" id="m_id" name="m_id" value="<?php echo isset($row['m_id']) ? $row['m_id'] : ''; ?>" readonly>
        </div>
        <div class="form-group">
            <label for="username">Name</label>
            <input type="text" class="form-control" id="username" name="username" value="<?php echo isset($row['username']) ? $row['username'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="address">City</label>
            <input type="text" class="form-control" id="address" name="address" value="<?php echo isset($row['address']) ? $row['address'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="contact">Mobile</label>
            <input type="text" class="form-control" id="contact" name="contact" value="<?php echo isset($row['contact']) ? $row['contact'] : ''; ?>" onkeypress="isInputNumber(event)">
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control" id="email" name="email" value="<?php echo isset($row['email']) ? $row['email'] : ''; ?>">
        </div>
        <div class="text-center">
            <button type="submit" class="btn btn-danger" name="empupdate">Update</button>
            <a href="technician.php" class="btn btn-secondary">Close</a>
        </div>
        <?php if (isset($msg)) { echo $msg; } ?>
    </form>
</div>

<!-- Only Number for input fields -->
<script>
function isInputNumber(evt) {
    var ch = String.fromCharCode(evt.which);
    if (!(/[0-9]/.test(ch))) {
        evt.preventDefault();
    }
}
</script>
