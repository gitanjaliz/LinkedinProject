<?php require_once("lock.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Mosaddek">
    <meta name="keyword" content="FlatLab, Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
    <link rel="shortcut icon" href="views/img/favicon.html">
    <title><?php echo TITLE; ?></title>

    <!-- Bootstrap core CSS -->
    <link href="views/css/bootstrap.min.css" rel="stylesheet">
    <link href="views/css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="views/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="views/css/table-responsive.css" rel="stylesheet" />
    <!--right slidebar-->
    <link href="views/css/slidebars.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="views/css/style.css" rel="stylesheet">
    <link href="views/css/style-responsive.css" rel="stylesheet" />  
    <link rel="stylesheet" type="text/css" href="views/assets/bootstrap-datepicker/css/datepicker.css" />
    <link rel="stylesheet" type="text/css" href="views/assets/bootstrap-timepicker/compiled/timepicker.css" />
    <link rel="stylesheet" type="text/css" href="views/assets/bootstrap-colorpicker/css/colorpicker.css" />
    <link rel="stylesheet" type="text/css" href="views/assets/bootstrap-daterangepicker/daterangepicker-bs3.css" />
    <link rel="stylesheet" type="text/css" href="views/assets/bootstrap-datetimepicker/css/datetimepicker.css" />
</head>

<body>

<section id="container">
    <!--header start-->
    <?php include "header.php"; ?>
    <!--main content start-->
    <section id="main-content">
        <section class="wrapper">
            <div class="row">
                <div class="col-lg-12" id="edit_view">
                    <section class="panel">
                        <header class="panel-heading">
                            Services List
                        </header>
                        <div class="panel-body">
                            <section id="no-more-tables">
                                <table class="table table-bordered table-striped table-condensed cf">
                                    <thead class="cf">
                                        <tr>
                                            <th>Sr.No</th>
                                            <th>Service Head</th>
                                            <th>Service Description</th>
                                            <th>Service Image</th>
                                            <th>Service Icon</th>
                                            <th>Edit</th> <!-- Changed this from "Remove" to "Edit" -->
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    $shwser = $auth_user->shwser($user_id);
                                    foreach ($shwser as $shwserli) {
                                        $s_id = $shwserli['s_id'];
                                        $s_head = $shwserli['s_head'];
                                        $s_desc = $shwserli['s_desc'];
                                        $s_img = $shwserli['s_img'];
                                        $s_icon = $shwserli['s_icon'];
                                    ?>
                                        <tr>
                                            <td data-title="Sr.No"><?php echo $s_id; ?></td>
                                            <td data-title="Heading"><?php echo $s_head; ?></td>
                                            <td data-title="Description"><?php echo $s_desc; ?></td>
                                            <td data-title="img"><img src="<?php echo $s_img; ?>" /></td>
                                            <td data-title="Icon"><i style="font-size: 10em;" class="<?php echo $s_icon; ?>"></i></td>
                                            <td class="Action" data-title="Edit">
                                                <a href="javascript:void(0);" onclick="editService(<?php echo $s_id; ?>)" class="btn btn-warning">Edit</a>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                    </tbody>
                                </table>
                            </section>
                        </div>
                    </section>
                </div>
            </div>
        </section>
    </section>
</section>

<!-- Add Edit Modal Here or Redirect to Edit Page -->

<!-- js placed at the end of the document so the pages load faster -->
<script src="views/js/jquery.js"></script>
<script src="views/js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="views/js/jquery.dcjqaccordion.2.7.js"></script>
<script src="views/js/jquery.scrollTo.min.js"></script>
<script src="views/js/respond.min.js"></script>
<script src="views/js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" src="views/assets/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="views/assets/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js"></script>
<script type="text/javascript" src="views/assets/bootstrap-daterangepicker/moment.min.js"></script>
<script type="text/javascript" src="views/assets/bootstrap-daterangepicker/daterangepicker.js"></script>
<link href="views/assets/toastr-master/toastr.css" rel="stylesheet" type="text/css" />
<script src="views/js/slidebars.min.js"></script>

<!-- Common script for all pages -->
<script src="views/js/common-scripts.js"></script>
<script src="views/js/advanced-form-components.js"></script>

<!-- Edit Service Script -->
<script type="text/javascript">
function editService(sid) {
    // You can either show a modal or redirect to another page to edit the service
    window.location.href = 'editService.php?sid=' + sid; // Redirect to edit page (passing service id)
    // OR if you are using a modal:
    // $('#editModal').modal('show'); // Show the modal for editing
    // Populate modal fields with service data (you can use AJAX to get the data)
}
</script>

</body>
</html>
