<?php 
require_once("controller/class.user.php");
	$auth_main = new USER();
date_default_timezone_set('Asia/Kolkata');
$date= date('d-m-Y H:i:s');
	$logged= false ;
	if(isset($_COOKIE["g_user"])  && isset($_COOKIE["g_salt"]))
	{
        $cuser=$_COOKIE["g_user"]; 
	$csalt=$_COOKIE["g_salt"];
		if($user=$auth_main->userfetch($csalt))
		{
		 $logged = true ;
        }
	}
	
if($logged != true )
{
	header("location:index");
}
?>