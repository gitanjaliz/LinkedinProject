<?php
include('lock.php');
if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
{
	$cuid = $_POST['uid'];
	$cocode = $_POST['ocode'];
	$o_auth=md5($cocode.$cuid);
	$h_id=$_POST['hid'];
	$gtot = $_POST['gtot'];
	$addr= $_POST['addr'];
	$ob_dt = time();
	$ob_flag = 1;
									
				if($last=$auth_main->addobill($cocode, $h_id, $cuid, $ob_flag, $gtot, $o_auth, $addr, $ob_dt))
				{		
				if($edit_cart=$auth_main->editocart($cocode,$cuid,$last)){
						echo "Success" ;
					
				}
				else
				{
				echo "Fails upload";
				}
				}
				else
				{
				echo "Fails upload";
				}
}
?>