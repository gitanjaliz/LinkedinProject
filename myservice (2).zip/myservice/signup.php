<?php 
include("keylock.php");
if ($logged == true) {
    header("location:home");
    exit;
}
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="user-scalable=no, initial-scale=1.0, maximum-scale=1.0 minimal-ui"/>
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <link rel="icon" type="image/png" href="images/splash/android-chrome-192x192.png" sizes="192x192">
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,500,700" rel="stylesheet">
    <title>Genie</title>
    <link href="styles/style.css" rel="stylesheet" type="text/css">
    <link href="styles/framework.css" rel="stylesheet" type="text/css">
    <link href="styles/font-awesome.css" rel="stylesheet" type="text/css">
    <script type="text/javascript" src="scripts/jquery.js"></script>
    <script type="text/javascript" src="scripts/plugins.js"></script>
    <script type="text/javascript" src="scripts/custom.js"></script>
    
    <script type="text/javascript">
        function saveuser() { 
            var u_name = $("#u_name").val();
            var u_cont = $("#u_cont").val();
            var u_email = $("#u_email").val();
            var pincode = $("#pincode").val();
            var password = $("#password").val();
            var u_addr = $("#u_addr").val();

            if (u_name != "" && u_cont != "" && u_email != "" && pincode != "" && password != "" && u_addr != "") {
                var form = $("#fform");
                $.ajax({
                    type: 'POST',
                    url: 'userdata.php',
                    data: form.serialize(),
                    success: function(data){  
                        if (data == "Success") { 
                            $('#fform')[0].reset();
                            location.replace('index.php'); 
                        } else { 
                            $('#error').html(data);
                            $('#error').show();  
                            $('#error').fadeOut(5000);
                        }
                    }
                }); 
            } else {
                $('#error').html("All fields are required.");
                $('#error').show();  
                $('#error').fadeOut(5000);
            }
        }
    </script>

    <script>
        function isNumberKey(evt) {
            var charCode = (evt.which) ? evt.which : event.keyCode;
            if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                return false;
            }
            return true;
        }
    </script>

    <style>
      /* General body styles */
body {
    font-family: 'Roboto', sans-serif;
    background-color: #f5f5f5;
    margin: 0;
    padding: 0;
    color: #333;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

/* Cover section */
.cover-page {
    background: url('images/pictures/logimg3.jpg') no-repeat center center;
    background-size: cover;
    position: relative;
    width: 100%;
    height: 100%;
}

/* Login container */
.pageapp-login {
    background: rgba(255, 255, 255, 0.9);
    padding: 40px 50px;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
    width: 100%;
    max-width: 500px; /* Adjusted for better width */
    box-sizing: border-box;
}

/* Logo styling */
.pageapp-login-logo img {
    width: 120px;
    margin-bottom: 20px;
}

/* Error message */
#error {
    color: red;
    margin-bottom: 15px;
    text-align: center;
}

/* Input field styling */
.cover-field {
    margin-bottom: 20px;
    position: relative;
}

.cover-field input {
    width: 100%;
    padding: 15px;
    border-radius: 5px;
    border: 1px solid #ccc;
    font-size: 16px;
    box-sizing: border-box;
    transition: all 0.3s;
}

.cover-field input:focus {
    border-color: #2980b9;
    outline: none;
}

/* Field icon styling */
.cover-field i {
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    font-size: 18px;
    color: #888;
}

/* Submit button styling */
.pageapp-login-button {
    background-color: #2980b9;
    color: white;
    padding: 10px;
    border-radius: 5px;
    width: 100%;
    font-size: 16px;
    cursor: pointer;
    border: none;
    transition: background-color 0.3s ease;
    height: 50px;
    
}

.pageapp-login-button:hover {
    background-color: #3498db;
}

/* "Already Registered?" link */
.cover-buttons a {
    display: block;
    text-align: center;
    font-size: 14px;
    color: #2980b9;
    margin-top: 15px;
}

.cover-buttons a:hover {
    text-decoration: underline;
}

/* Back to top button */
.back-to-top-badge {
    display: inline-block;
    background-color: #3498db;
    color: white;
    padding: 10px 20px;
    border-radius: 50px;
    text-align: center;
    position: fixed;
    bottom: 30px;
    right: 30px;
    cursor: pointer;
}

.back-to-top-badge:hover {
    background-color: #2980b9;
}

/* Input placeholder text styling */
.cover-field input::placeholder {
    color: #888;
}

/* Adjust form layout for better spacing */
.pageapp-login .cover-field {
    margin-bottom: 25px;
}

.pageapp-login input[type="submit"] {
    margin-top: 15px;
}

/* Responsive design for smaller screens */
@media (max-width: 600px) {
    .pageapp-login {
        padding: 30px 25px;
        max-width: 90%;
    }

    .cover-field input {
        font-size: 14px;
    }

    .pageapp-login-button {
        padding: 12px;
        font-size: 14px;
        
    }
}

    </style>
</head>
<body class="has-cover">
    <div class="gallery-fix"></div>
    <div class="sidebar-tap-close"></div>
    <div id="page-content">
        <div id="page-content-scroll">
            <div class="cover-page">
                <div class="cover-page-content">
                    <div class="pageapp-login">
                        <a href="index.php" class="pageapp-login-logo">
                            <img src="images/pictures/lg.png" alt="img">
                        </a>

                        <div id="error"></div>

                        <form id="fform" action="javascript:;" name="fform" onsubmit="saveuser()" method="POST" enctype="multipart/form-data">
						<div class="cover-field">
                            <i class="fa fa-user"></i>
                            <input type="text" id="u_name" name="u_name" placeholder="Name" value="">
                        </div>
                        <div class="cover-field">
                            <i class="fa fa-envelope-o"></i>
                            <input type="text" id="u_email" name="u_email" placeholder="Email" value="">
                        </div>
						<div class="cover-field">
                            <i class="fa fa-phone"></i>
                            <input type="text" id="u_cont" maxlength="10" minlength="10" name="u_cont" placeholder="Contact" value="" onKeyPress="return isNumberKey(event);">
                        </div>
						<div class="cover-field">
                            <i class="fa fa-lock"></i>
                            <input type="password" id="password" name="password" placeholder="password" value="">
                        </div>
						<div class="cover-field">
                            <i class="fa fa-map-marker"></i>
                            <input type="text" id="pincode" name="pincode" onKeyPress="return isNumberKey(event);" placeholder="pincode" minlength="6" maxlength="6" value="">
                        </div>
						<div class="cover-field">
                            <i class="fa fa-map-marker"></i>
                            <input type="text" id="u_addr" name="u_addr" placeholder="Address" value="">
                        </div>
						<input type="submit" id="login" class="pageapp-login-button button button-green" value="Register">
						</form>
<div class="decoration half-bottom"></div>
                        
                    </div>
                </div>
            </div>
        </div>

        <a href="#" class="back-to-top-badge"><i class="fa fa-caret-up"></i> Back to top</a>
    </div>


    <div class="share-bottom">
        <h3>Share Page</h3>
        <div class="share-socials-bottom">
            <a href="#"><i class="fa fa-facebook facebook-color"></i>Facebook</a>
            <a href="#"><i class="fa fa-twitter twitter-color"></i>Twitter</a>
            <a href="#"><i class="fa fa-google-plus google-color"></i>Google</a>
            <a href="#"><i class="fa fa-pinterest-p pinterest-color"></i>Pinterest</a>
            <a href="#"><i class="fa fa-comment-o sms-color"></i>Text</a>
            <a href="#"><i class="fa fa-envelope-o mail-color"></i>Email</a>
            <div class="clear"></div>
        </div>
    </div>
</body>
</html>
