<?php
session_start();
require_once 'config.php';

// Check if the user is logged in
if (!isset($_SESSION['m_id'])) {
    header("Location: login.php");
    exit;
}

$service_man_id = $_SESSION['service_man_id'];

// Fetch user details
$qry = $conn->prepare("SELECT * FROM service_man WHERE id = ?");
$qry->bind_param("i", $service_man_id);
$qry->execute();
$result = $qry->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    echo "No user found.";
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $address = $_POST['address'];
    
    $updateQry = $conn->prepare("
        UPDATE service_man 
        SET username = ?, email = ?, contact = ?, address = ? 
        WHERE id = ?
    ");
    $updateQry->bind_param("sssii", $username, $email, $contact, $address, $service_man_id);

    if ($updateQry->execute()) {
        $_SESSION['username'] = $username; // Update session username
        $success = "Profile updated successfully.";
    } else {
        $error = "Failed to update profile. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <style>
        .container {
            max-width: 600px;
            margin-top: 50px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center text-primary">Edit Profile</h1>
        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <form method="POST" action="">
            <div class="mb-3">
                <label for="username" class="form-label">Name</label>
                <input type="text" class="form-control" id="username" name="username" value="<?= htmlspecialchars($user['username']) ?>" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
            </div>
            <div class="mb-3">
                <label for="contact" class="form-label">Mobile</label>
                <input type="text" class="form-control" id="contact" name="contact" value="<?= htmlspecialchars($user['contact']) ?>" required>
            </div>
            <div class="mb-3">
                <label for="address" class="form-label">Address</label>
                <textarea class="form-control" id="address" name="address" rows="3" required><?= htmlspecialchars($user['address']) ?></textarea>
            </div>
            <div class="d-flex justify-content-between">
                <a href="profile.php" class="btn btn-secondary">Cancel</a>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </form>
    </div>
</body>
</html>
