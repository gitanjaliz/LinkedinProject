<?php
session_start();
require_once 'config.php';

// Debugging session start
if (!isset($_SESSION)) {
    die("Session failed to start!");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if (!empty($username) && !empty($password)) {
        $qry = $conn->prepare("SELECT * FROM service_man WHERE username = ?");
        if (!$qry) {
            die("Database error: " . $conn->error); // Debugging query error
        }
        $qry->bind_param("s", $username);
        $qry->execute();
        $result = $qry->get_result();
        
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            
            // Debugging password check
            if (password_verify($password, $user['password'])) {
                $_SESSION['m_id'] = $user['m_id'];
                $_SESSION['username'] = $user['username'];

                // Debugging session variables
                echo "Session set: m_id=" . $_SESSION['m_id'] . ", username=" . $_SESSION['username'] . "<br>";
                
                // Debugging redirection
                echo "Redirecting to dashboard...";
                header("Location: dashboard.php");
                exit;
            } else {
                $error = "Invalid password!";
            }
        } else {
            $error = "User not found!";
        }
    } else {
        $error = "Username and password are required!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service Man Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body, html {
            height: 100%;
            margin: 0;
            font-family: Arial, sans-serif;
        }
        .bg-image {
            background-image: url('service images/4.jpeg'); /* Add your image URL here */
            background-size: cover;
            background-position: center;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-container {
            background-color: rgba(255, 255, 255, 0.9);
            padding: 30px;
            border-radius: 10px;
            width: 400px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        .login-container h1 {
            font-size: 2rem;
            margin-bottom: 20px;
            text-align: center;
            color: #333;
        }
        .form-label {
            font-size: 1.1rem;
            margin-bottom: 10px;
        }
        .form-control {
            border-radius: 5px;
            border: 1px solid #ccc;
            margin-bottom: 20px;
            padding: 10px;
        }
        .btn-login {
            width: 100%;
            background-color: #6a11cb;
            color: white;
            padding: 10px;
            border-radius: 5px;
            border: none;
            font-size: 1.1rem;
        }
        .btn-login:hover {
            background-color: #2575fc;
        }
        .btn-signup, .btn-home {
            display: block;
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: none;
            font-size: 1.1rem;
            text-align: center;
            margin-top: 10px;
            text-decoration: none;
        }
        .btn-signup {
            background-color: #f1c40f;
            color: white;
        }
        .btn-signup:hover {
            background-color: #f39c12;
        }
        .btn-home {
            background-color: #27ae60;
            color: white;
        }
        .btn-home:hover {
            background-color: #2ecc71;
        }
        .error-message {
            color: red;
            text-align: center;
            margin-top: 10px;
        }
        
    </style>
</head>
<body>

<div class="bg-image">
    <div class="login-container">
        <h1>Service Man Login</h1>
        <form method="POST">
            <div class="mb-3">
                <label for="username" class="form-label">Username:</label>
                <input type="text" name="username" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password:</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            
            <!-- Login Button -->
            <button type="submit" class="btn btn-login">Login</button>

            <!-- Error Message -->
            <?php if (isset($error)) echo "<p class='error-message'>$error</p>"; ?>
        </form>

        <!-- Links: Back to Shop and Sign Up -->
               <!-- Links: Back to Shop and Sign Up -->
               <div class="row">
            <div class="col-12 text-center">
             <a href="../index.php">Back to Home</a>
            </div>
        </div>
        <div class="row">
            <div class="col-12 text-center">
             <a href="servicerregistration.php">Create an Account</a>
            </div>
        </div>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
