<?php
session_start();
require_once 'config.php';

// Check if the user is logged in
if (!isset($_SESSION['m_id'])) {
    header("Location: login.php");
    exit;
}

$service_man_id = $_SESSION['m_id'];

// Fetch user details
$qry = $conn->prepare("SELECT * FROM service_man WHERE m_id = ?");
$qry->bind_param("i", $service_man_id);
$qry->execute();
$result = $qry->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    echo "No user found.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <style>
        h1 {
            color: red;
            font-style: italic;
            text-align: center;
        }
        h2 {
            color: red;
            font-style: italic;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h1>My Profile</h1>
        <table class="table table-bordered">
            <tr>
                <th>Name:</th>
                <td><?= htmlspecialchars($user['username']) ?></td>
            </tr>
            <tr>
                <th>Email:</th>
                <td><?= htmlspecialchars($user['email']) ?></td>
            </tr>
            <tr>
                <th>Mobile:</th>
                <td><?= htmlspecialchars($user['contact']) ?></td>
            </tr>
            <tr>
                <th>Address:</th>
                <td><?= htmlspecialchars($user['address']) ?></td>
            </tr>
        </table>
        
        <h2 class="mt-5">Service Details</h2>
        <table class="table table-bordered">
            <tr>
                <th>Date of Birth:</th>
                <td><?= htmlspecialchars($user['date_of_birth']) ?></td>
            </tr>
            <tr>
                <th>Occupation</th>
                <td><?= htmlspecialchars($user['service_type']) ?></td>
            </tr>
            <tr>
                <th>Experience</th>
                <td><?= htmlspecialchars($user['work_experience']) ?></td>
            </tr>
            <tr>
                <th>Id Type:</th>
                <td><?= htmlspecialchars($user['type_of_id']) ?></td>
            </tr>
            <tr>
                <th>Id Card:</th>
                <td><?= htmlspecialchars($user['id_proof_image']) ?></td>
            </tr>
        </table>
        <div class="d-flex justify-content-between mt-4">
            <a href="dashboard.php" class="btn btn-danger">Back to Dashboard</a>
            <a href="edit_profile.php" class="btn btn-primary">Edit Profile</a>
        </div>
    </div>
</body>
</html>
