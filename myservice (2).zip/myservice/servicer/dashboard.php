<?php
session_start();
require_once 'config.php';

// Check if the user is logged in
if (!isset($_SESSION['m_id'])) {
    header("Location: login.php");
    exit;
}

// Check if the 'username' session variable is set
if (!isset($_SESSION['username'])) {
    // You can either redirect to login or display an error message
    echo "Username not found in session. Please log in again.";
    exit;
}

$service_man_id = $_SESSION['m_id']; // Get service man ID from session
$username = $_SESSION['username']; // Get username from session

// Fetch all orders or services linked to the logged-in service man
$qry = $conn->prepare("
    SELECT s.s_head, o.s_id as sb_id, o.status, o.created_at 
    FROM services s
    LEFT JOIN sbook o ON s.s_id = o.s_id
    WHERE s.service_man_id = ?
");
$qry->bind_param("i", $service_man_id);
$qry->execute();
$orders = $qry->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service User Home Page</title>
    <link rel="stylesheet" href="styles.css"> <!-- Add your CSS file -->
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        header {
            background-color: #333;
            color: #fff;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        header a {
            color: white;
            text-decoration: none;
            margin-left: 15px;
        }
        .dropdown {
            position: relative;
            display: inline-block;
        }
        .dropdown button {
            background-color: red;
            color: white;
            border: 2px solid red;
            cursor: pointer;
            padding: 5px 10px;
            font-size: 16px;
            border-radius: 5px;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 160px;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
            z-index: 1;
        }
        .dropdown-content a {
            color: black;
            padding: 10px 15px;
            text-decoration: none;
            display: block;
        }
        .dropdown-content a:hover {
            background-color: #ddd;
        }
        .dropdown:hover .dropdown-content {
            display: block;
        }
        .dropdown:hover button {
            background-color: #555;
        }
        main {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f4f4f4;
            text-align: center;
        }
        .content {
            width: 100%; /* Take full width of the page */
        }
        .content img {
            width: 100%; /* Full width image */
            height: auto; /* Maintain aspect ratio */
            display: block;
        }
        .content h2 {
            margin-top: 20px;
            font-size: 24px;
            color: #333;
        }
        footer {
            text-align: center;
            padding: 10px;
            background-color: #333;
            color: #fff;
        }


    </style>
</head>
<body>
    <header>
        <div>
            <h1>Home Service Management System</h1>
        </div>
        <div>
            <a href="dashboard.php">Home</a>
            <a href="my_orders.php">My Orders</a>
            <div class="dropdown">
                <button>Hello, <?php echo htmlspecialchars($username); ?></button>
                <div class="dropdown-content">
                    <a href="profile.php">My Profile</a>
                    <a href="update_password.php">Update Password</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </header>

    <main>
        <div class="content">
            <h2>Service User Home Page</h2>
            <img src="service images/banner.jpg" alt="Service Home">
           
        </div>
    </main>

    <footer>
        <p>&copy; 2024 Home Service Management System. All Rights Reserved.</p>
    </footer>
</body>
</html>