<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['m_id'])) {
    header("Location: login.php");
    exit;
}

$service_man_id = $_SESSION['m_id'];

// Fetch orders for the service man
$qry = $conn->prepare("
    SELECT 
        o.sb_for AS service_name, 
        o.sb_id AS order_id, 
        o.status, 
        o.created_at 
    FROM 
        services s
    INNER JOIN 
        sbook o 
    ON 
        s.s_id = o.s_id
    WHERE 
        o.m_id = ?
");
$qry->bind_param("i", $service_man_id);
$qry->execute();
$orders = $qry->get_result();

// Handle status update action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $order_id = $_POST['order_id'];
    $new_status = $_POST['status'];

    // Update the status in the sbook table
    $update_stmt = $conn->prepare("UPDATE sbook SET status = ? WHERE sb_id = ?");
    $update_stmt->bind_param("ii", $new_status, $order_id);
    if ($update_stmt->execute()) {
        // Redirect to avoid re-posting the form
        header("Location: my_orders.php");
        exit;
    } else {
        echo "Error updating status!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">
    <style>
        /* Background image */
        body {
            background-image: url('service images/5.jpeg'); /* Update with your image path */
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            color: white;
        }
        .container {
    background-color: rgba(255, 255, 255, 0.8); /* Light semi-transparent white background */
    padding: 20px;
    border-radius: 8px;
}

    </style>
</head>
<body>
    <div class="container mt-4">
        <h1>My Orders</h1>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Service Name</th>
                    <th>Status</th>
                    <th>Order Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($orders->num_rows > 0): ?>
                    <?php while ($order = $orders->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($order['order_id']) ?></td>
                            <td><?= htmlspecialchars($order['service_name']) ?></td>
                            <td>
                                <?php
                                switch ($order['status']) {
                                    case 0: echo '<span class="badge bg-danger">Pending</span>'; break;
                                    case 1: echo '<span class="badge bg-success">Confirmed</span>'; break;
                                    case 2: echo '<span class="badge bg-warning">On-progress</span>'; break;
                                    case 3: echo '<span class="badge bg-success">Done</span>'; break;
                                    case 4: echo '<span class="badge bg-danger">Cancelled</span>'; break;
                                    default: echo '<span class="badge bg-dark">Unknown</span>'; break;
                                }
                                ?>
                            </td>
                            <td><?= date('Y-m-d H:i', strtotime($order['created_at'])) ?></td>
                            <td>
                                <!-- Form to update the status -->
                                <form action="my_orders.php" method="POST" style="display:inline;">
                                    <input type="hidden" name="order_id" value="<?= $order['order_id'] ?>">

                                    <!-- Dropdown for status selection -->
                                    <select name="status" class="form-select form-select-sm" style="display:inline-block; width:auto;" required>
                                        <?php if ($order['status'] == 0): ?>
                                            <option value="0" selected>Pending</option>
                                            <option value="1">Confirmed</option>
                                            <option value="2">On-progress</option>
                                            <option value="3">Done</option>
                                            <option value="4">Cancelled</option>
                                        <?php elseif ($order['status'] == 1): ?>
                                            <option value="0">Pending</option>
                                            <option value="1" selected>Confirmed</option>
                                            <option value="2">On-progress</option>
                                            <option value="3">Done</option>
                                            <option value="4">Cancelled</option>
                                        <?php elseif ($order['status'] == 2): ?>
                                            <option value="0">Pending</option>
                                            <option value="1">Confirmed</option>
                                            <option value="2" selected>On-progress</option>
                                            <option value="3">Done</option>
                                            <option value="4">Cancelled</option>
                                        <?php elseif ($order['status'] == 3): ?>
                                            <option value="0">Pending</option>
                                            <option value="1">Confirmed</option>
                                            <option value="2">On-progress</option>
                                            <option value="3" selected>Done</option>
                                            <option value="4">Cancelled</option>
                                        <?php elseif ($order['status'] == 4): ?>
                                            <option value="0">Pending</option>
                                            <option value="1">Confirmed</option>
                                            <option value="2">On-progress</option>
                                            <option value="3">Done</option>
                                            <option value="4" selected>Cancelled</option>
                                        <?php endif; ?>
                                    </select>

                                    <!-- Update button to apply the selected status -->
                                    <button type="submit" name="update_status" class="btn btn-sm btn-primary mt-2">Update</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="text-center">No orders found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <a href="dashboard.php" class="btn btn-outline-primary">Back to Dashboard</a>
    </div>
</body>
</html>
