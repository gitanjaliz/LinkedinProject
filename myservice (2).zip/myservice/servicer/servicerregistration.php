
<?php
include('config.php'); // Ensure this file connects to your database

if (!file_exists('uploads')) {
    mkdir('uploads', 0777, true);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Encrypt password
    $contact = $_POST['contact'];
    $address = $_POST['address'];
    $experience = $_POST['experience'];
    $dob = $_POST['dob'];
    $service_type = $_POST['service_type'];
    $id_type = $_POST['id_type'];

    // Initialize file paths for uploads
    $profile_image = "";
    $id_proof_image = "";

    // File uploads handling (Profile Image)
    if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
        $profile_image = "uploads/" . uniqid() . "_" . basename($_FILES['profile_image']['name']);
        if (!move_uploaded_file($_FILES['profile_image']['tmp_name'], $profile_image)) {
            die("Failed to upload profile image.");
        }
    } else {
        $error_message = "Profile image is required.";
    }

    // File uploads handling (ID Proof)
    if (isset($_FILES['id_proof']) && $_FILES['id_proof']['error'] === UPLOAD_ERR_OK) {
        $id_proof_image = "uploads/" . uniqid() . "_" . basename($_FILES['id_proof']['name']);
        if (!move_uploaded_file($_FILES['id_proof']['tmp_name'], $id_proof_image)) {
            die("Failed to upload ID proof image.");
        }
    } else {
        $error_message = "ID proof image is required.";
    }

    // If no errors, insert into the database
    if (!isset($error_message)) {
        $sql = "INSERT INTO service_man (firstname, lastname, username, email, password, contact, address, work_experience, date_of_birth, service_type, type_of_id, profile_image, id_proof_image) 
                VALUES ('$firstname', '$lastname', '$username', '$email', '$password', '$contact', '$address', '$experience', '$dob', '$service_type', '$id_type', '$profile_image', '$id_proof_image')";


    if ($conn->query($sql) === TRUE) {
        $success_message = "Service provider registered successfully!";
        echo "<script>alert('$success_message');</script>";  // Success alert
    } else {
        $error_message = "Error: " . $sql . "<br>" . $conn->error;
        echo "<script>alert('$error_message');</script>";  // Error alert
    }
}
}
// Close the connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service Man Registration</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet"> <!-- FontAwesome for Icons -->
    <style>
        /* Form Container Styles */
        .form-container {
            background: url('service images/3.jpeg') no-repeat center center/cover;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
            border: 1px solid #ddd;
            position: relative;
            z-index: 1;
        }
        .form-container {
            background-color: #f8f9fa;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
            border: 1px solid #ddd;
        }

        /* Heading Style */
        .form-container h2 {
            color: #333;
            font-size: 28px;
            margin-bottom: 20px;
            text-align: center;
        }

        /* Input Fields Styling */
        .form-control {
            border-radius: 8px;
            box-shadow: none;
            border: 1px solid #ccc;
            margin-bottom: 1rem;
            padding-left: 2.5rem; /* Add space for icons */
        }

        .form-control:focus {
            border-color: #007bff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
        }

        /* Input Icons */
        .input-icon {
            position: absolute;
            left: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: #ccc;
        }

        /* File Upload Preview */
        .file-preview {
            margin-top: 10px;
        }

        /* Select Box Styling */
        .form-select {
            border-radius: 8px;
            box-shadow: none;
            border: 1px solid #ccc;
            margin-bottom: 1.5rem;
        }

        .form-select:focus {
            border-color: #007bff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
        }

        /* Button Styles */
        .btn-custom {
            background-color: #007bff;
            color: white;
            border-radius: 8px;
            padding: 10px 20px;
            width: 150px;
            transition: background-color 0.3s, transform 0.3s;
        }

        .btn-custom:hover {
            background-color: #0056b3;
            transform: scale(1.05);
        }

        .cancel-btn {
            background-color: #6c757d;
            color: white;
            border-radius: 8px;
            padding: 10px 20px;
            margin-left: 10px;
        }

        .cancel-btn:hover {
            background-color: #5a6268;
            color: white;
            transform: scale(1.05);
        }

        /* Column Layout */
        .col-md-6 {
            padding: 0 15px;
        }

        /* Label Styling */
        .form-label {
            font-weight: 500;
            font-size: 16px;
            margin-bottom: 5px;
        }

        .text-center {
            display: block;
            text-align: center;
            margin-top: 20px;
        }

        /* File Input Styling */
        .file-input-wrapper {
            position: relative;
            margin-bottom: 1.5rem;
        }

        /* File Input Preview */
        .file-input-wrapper img {
            max-width: 100%;
            border-radius: 8px;
        }

        /* Container Styling */
        .container {
            margin-top: 50px;
        }

        /* Animation */
        .form-control, .btn-custom, .cancel-btn {
            animation: fadeIn 0.8s ease-out;
        }

        @keyframes fadeIn {
            0% { opacity: 0; transform: translateY(20px); }
            100% { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
<div class="container">
    <div class="form-container">
        <h2>Service Man Registration</h2>
        <form method="POST" action="" enctype="multipart/form-data">
            <div class="row">
                <!-- Left Column -->
                <div class="col-md-7">
                    <div class="mb-3">
                        <label for="firstname" class="form-label">First Name</label>
                        <div class="position-relative">
                            <input type="text" class="form-control" id="firstname" name="firstname" required>
                            <i class="fas fa-user input-icon"></i>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="lastname" class="form-label">Last Name</label>
                        <div class="position-relative">
                            <input type="text" class="form-control" id="lastname" name="lastname" required>
                            <i class="fas fa-user input-icon"></i>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <div class="position-relative">
                            <input type="text" class="form-control" id="username" name="username" required>
                            <i class="fas fa-user-tag input-icon"></i>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <div class="position-relative">
                            <input type="email" class="form-control" id="email" name="email" required>
                            <i class="fas fa-envelope input-icon"></i>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <div class="position-relative">
                            <input type="password" class="form-control" id="password" name="password" required>
                            <i class="fas fa-lock input-icon"></i>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="contact" class="form-label">Contact</label>
                        <div class="position-relative">
                            <input type="text" class="form-control" id="contact" name="contact" required>
                            <i class="fas fa-phone-alt input-icon"></i>
                        </div>
                        <div class="mb-3">
                        <label for="address" class="form-label">Address</label>
                        <textarea class="form-control" id="address" name="address" required></textarea>
                    </div>
                    </div>
                </div>

                <!-- Right Column -->
                <div class="col-md-5">
                    
                    <div class="mb-3">
                        <label for="experience" class="form-label">Work Experience (Years)</label>
                        <input type="number" class="form-control" id="experience" name="experience" required>
                    </div>
                    <div class="mb-3">
                        <label for="dob" class="form-label">Date of Birth</label>
                        <input type="date" class="form-control" id="dob" name="dob" required>
                    </div>
                    <div class="mb-3">
                        <label for="service_type" class="form-label">Service Type</label>
                        <select class="form-select" id="service_type" name="service_type" required>
                            <option value="" disabled selected>Select Service</option>
                            <option value="Beauty Parlour">Beauty Parlour</option>
                            <option value="RO Water Purifier">RO Water Purifier</option>
                            <option value="Welder">Welder</option>
                            <option value="DJ, Music & Light">DJ, Music & Light</option>
                            <option value="2 Wheeler Servicing & Repairing">2 Wheeler Servicing & Repairing</option>
                            <option value="Art/Painting Classes">Art/Painting Classes</option>
                            <option value="Rail & Air Ticket">Rail & Air Ticket</option>
                            <option value="Catering Service">Catering Service</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="id_type" class="form-label">Type of ID</label>
                        <input type="text" class="form-control" id="id_type" name="id_type" required>
                    </div>
                    <div class="file-input-wrapper">
                        <label for="profile_image" class="form-label">Profile Image</label>
                        <input type="file" class="form-control" id="profile_image" name="profile_image" onchange="previewImage(event)">
                        <div id="profile-preview" class="file-preview"></div>
                    </div>
                    <div class="file-input-wrapper">
                        <label for="id_proof" class="form-label">ID Proof</label>
                        <input type="file" class="form-control" id="id_proof" name="id_proof" onchange="previewImage(event)">
                        <div id="id-proof-preview" class="file-preview"></div>
                    </div>
                </div>
            </div>

            <div class="text-center">
                <button type="submit" name="register" class="btn btn-custom">Register</button>
                <a href="login.php" class="btn btn-danger">Cancel</a>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function previewImage(event) {
        const previewId = event.target.id === "profile_image" ? "profile-preview" : "id-proof-preview";
        const file = event.target.files[0];
        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById(previewId).innerHTML = `<img src="${e.target.result}" alt="Image Preview">`;
        }
        reader.readAsDataURL(file);
    }
</script>
</body>
</html>
