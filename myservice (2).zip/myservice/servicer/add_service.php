<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['service_man_id'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $service_name = $_POST['service_name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $service_man_id = $_SESSION['service_man_id'];

    $qry = $conn->prepare("INSERT INTO services (service_name, description, price, service_man_id) VALUES (?, ?, ?, ?)");
    $qry->bind_param("ssdi", $service_name, $description, $price, $service_man_id);
    $qry->execute();

    header("Location: dashboard.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Service</title>
</head>
<body>
    <h1>Add New Service</h1>
    <form method="POST">
        <label for="service_name">Service Name:</label>
        <input type="text" name="service_name" required>
        <label for="description">Description:</label>
        <textarea name="description" required></textarea>
        <label for="price">Price:</label>
        <input type="number" step="0.01" name="price" required>
        <button type="submit">Add Service</button>
    </form>
</body>
</html>
