<?php
require_once('config/dbconfig.php');

class USER
{	

	private $conn;
	
	public function __construct()
	{
		$database = new Database();
		$db = $database->dbConnection();
		$this->conn = $db;
    }
	
	public function runQuery($sql)
	{
		$stmt = $this->conn->prepare($sql);
		return $stmt;
	}
	
	public function userfetch($csalt)
	{
		try
		{
			$stmt = $this->conn->prepare("SELECT * FROM user WHERE u_salt=:csalt");
			$stmt->execute(array(':csalt'=>$csalt));
			$userfetch=$stmt->fetch(PDO::FETCH_ASSOC);
			return $userfetch;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}
	}
	
	public function userchk($uname,$umail)
	{
		try
		{
			$stmt = $this->conn->prepare("SELECT u_id, u_name, u_email, u_pass FROM user WHERE u_cont=:uname OR u_email=:umail ");
			$stmt->execute(array(':uname'=>$uname, ':umail'=>$umail));
			$userchk=$stmt->fetch(PDO::FETCH_ASSOC);
			return $userchk;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}
	}
	
	public function register($u_name, $u_cont, $u_pass, $u_flag, $u_email, $u_addr, $pincode)
	{
		try
		{
			$new_password = md5($u_pass);
			$stmt = $this->conn->prepare("INSERT INTO user (u_name, u_cont, u_pass, u_flag, u_email,  u_addr, pincode) VALUES (:u_name, :u_cont, :u_pass, :u_flag, :u_email, :u_addr, :pincode)");
			$stmt->bindparam(":u_name", $u_name);							  
			$stmt->bindparam(":u_cont", $u_cont);
			$stmt->bindparam(":u_pass", $new_password);
			$stmt->bindparam(":u_flag", $u_flag);
			$stmt->bindparam(":u_email", $u_email);
			$stmt->bindparam(":u_addr", $u_addr);
			$stmt->bindparam(":pincode", $pincode);	
			$stmt->execute();	
			
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}
	
	public function validcont($u_cont)
	{
		try
		{
	      $stmt = $this->conn->prepare("SELECT * FROM user where u_cont=:u_cont");
			$stmt->execute(array(':u_cont'=>$u_cont));
			$validcont=$stmt->fetch(PDO::FETCH_ASSOC);
			$count=$stmt->rowCount();
			return $count;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
	}
	
	public function doLogin($uname,$umail,$upass)
	{
		try
		{
			$stmt = $this->conn->prepare("SELECT * FROM user WHERE u_cont=:uname OR u_email=:umail");
			$stmt->execute(array(':uname'=>$uname, ':umail'=>$umail));
			$userRow=$stmt->fetch(PDO::FETCH_ASSOC);
			if($stmt->rowCount() == 1)
			{
				if($upass==$userRow['u_pass'])
				{
				$myusername=$userRow['u_cont'];
				$myuser_id=$userRow['u_id'];
				$salt=hash("sha512", rand() . rand() . rand());
				setcookie("g_user", hash("sha512", $myusername), time() + 24 * 60 * 60, "/");
				setcookie("g_salt", $salt,  time() + 24 * 60 * 60, "/");
				//return $salt;
				return array('salt'=>$salt, 'userid'=>$myuser_id);
				}
				else
				{
					return false;
				}
			}
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}
	}
	
	public function updsalt($slt,$sluid)
	{
		try
		{
			$stmt = $this->conn->prepare("UPDATE user SET u_salt =:slt WHERE u_id =:sluid");
			$stmt->bindparam(":slt", $slt);
			$stmt->bindparam(":sluid", $sluid);	
			$stmt->execute();
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}
	
	public function is_loggedin()
	{
		if(isset($_COOKIE["g_user"])  && isset($_COOKIE["g_salt"]))
		{
			return true;
		}
	}
	
	public function redirect($url)
	{
		header("Location: $url");
	}
	
	public function doLogout()
	{
		$cuser=$_COOKIE["g_user"]; 
		$csalt=$_COOKIE["g_salt"];
		setcookie("g_user", $cuser, time() - 24 * 60 * 60, "/");
		setcookie("g_salt", $csalt,  time() - 24 * 60 * 60, "/");
		return true;
	}
	
	// fetch  service type
	public function shwser($user_id)
	{
		try
		{
	        $stmt = $this->conn->prepare("SELECT * FROM services where user_id= :user_id");
			$stmt->execute(array(':user_id'=>$user_id));
			$shwser=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $shwser;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
	}
	
	public function fetchvender($user_id)
	{
		try
		{
	        $stmt = $this->conn->prepare("SELECT v.*, s_head FROM vender v, services s where s.s_id=v.s_id AND v.user_id=:user_id");
			$stmt->execute(array('user_id'=>$user_id));
			$fetchvenders=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $fetchvenders;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
	}
	
		// fetch  Offers
	public function shwoffers($user_id)
	{
		try
		{
	        $stmt = $this->conn->prepare("SELECT * FROM offers where user_id= :user_id");
			$stmt->execute(array(':user_id'=>$user_id));
			$shwoffers=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $shwoffers;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
	}
	
	
	public function shwhotels()
	{
		try
		{
	        $stmt = $this->conn->prepare("SELECT * FROM hotels WHERE h_flag=1");
			$stmt->execute();
			$shwhotels=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $shwhotels;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
	}
	
	
	
	public function shwcat($hid,$user_id)
	{
		try
		{
	        $stmt = $this->conn->prepare("SELECT * FROM itemcat WHERE h_id=:hid AND user_id=:user_id");
			$stmt->execute(array(':hid'=>$hid,':user_id'=>$user_id));
			$shwcat=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $shwcat;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
	}
	
	
	public function shwhc($user_id)
	{
		try
		{
	        $stmt = $this->conn->prepare("SELECT * FROM h_cat WHERE hc_flag=1 AND user_id=:user_id");
			$stmt->execute(array(':user_id'=>$user_id));
			$shwhc=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $shwhc;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
	}
	public function fetchhotels($hc_id)
	{
		try
		{
	        $stmt = $this->conn->prepare("SELECT * FROM hotels WHERE h_flag=1 AND hc_id=:hc_id");
			$stmt->execute(array(':hc_id'=>$hc_id));
			$shwhc=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $shwhc;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
	}
	
	public function fetchhotel($hotel)
	{
		try
		{
	        $stmt = $this->conn->prepare("SELECT * FROM hotels WHERE h_flag=1 AND h_id=:hotel");
			$stmt->execute(array(':hotel'=>$hotel));
			$fetchhotel=$stmt->fetch(PDO::FETCH_ASSOC);
			return $fetchhotel;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
	}
	
	public function fetchtiemcat($hotel)
	{
		try
		{
	        $stmt = $this->conn->prepare("SELECT * FROM itemcat WHERE ic_flag=1 AND h_id=:hotel AND ic_parent=0");
			$stmt->execute(array(':hotel'=>$hotel));
			$fetchhotel=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $fetchhotel;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
	}
	
	public function fetchtiem($hotel,$ic_id)
	{
		try
		{
	        $stmt = $this->conn->prepare("SELECT * FROM itemcat WHERE ic_flag=1 AND h_id=:hotel AND ic_parent!= 0 AND ic_parent=:ic_parent");
			$stmt->execute(array(':hotel'=>$hotel,':ic_parent'=>$ic_id));
			$fetchhotel=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $fetchhotel;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
	}
	
	public function addcart($u_id, $i_id, $cr_flag, $ca_dt, $o_code, $cr_tot)
	{
		try
		{
			$stmt = $this->conn->prepare("INSERT INTO cart (u_id, i_id, cr_flag, ca_dt, o_code, cr_qty, cr_tot) VALUES (:u_id, :i_id, :cr_flag, :ca_dt, :o_code, 1,:cr_tot)");
												  
			$stmt->bindparam(":u_id", $u_id);
			$stmt->bindparam(":i_id", $i_id);
			$stmt->bindparam(":cr_flag", $cr_flag);										  
			$stmt->bindparam(":ca_dt", $ca_dt);
			$stmt->bindparam(":o_code", $o_code);
			$stmt->bindparam(":cr_tot", $cr_tot);
			$stmt->execute();	
			
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}
	
	public function fetchorder($u_id)
	{
		try
		{
	        $stmt = $this->conn->prepare("SELECT o_id, o_code FROM obill WHERE u_id=:u_id AND o_flag=1 ORDER BY o_id DESC limit 1");
			$stmt->execute(array(':u_id'=>$u_id));
			$fetchorder=$stmt->fetch(PDO::FETCH_ASSOC);
			return $fetchorder;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
	}
	
	public function removecart($u_id, $i_id, $o_code)
	{
		try
		{
			$stmt = $this->conn->prepare("DELETE FROM cart WHERE o_code =:o_code AND i_id=:i_id AND u_id=:u_id");
												  
			$stmt->bindparam(":u_id", $u_id);
			$stmt->bindparam(":i_id", $i_id);
			$stmt->bindparam(":o_code", $o_code);
			$stmt->execute();	
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}
	
	public function cntcart($uid,$ode)
	{
		try
		{
	        $stmt = $this->conn->prepare("SELECT c.*,h.h_name,h.h_id,ic.ic_name,ic.price 
FROM cart c, hotels h, itemcat ic
WHERE h.h_id=ic.h_id
AND c.i_id=ic.ic_id
AND c.o_code = :ode
AND c.u_id =:uid");
			$stmt->execute(array(':ode'=>$ode,':uid'=>$uid));
			$cntcart=$stmt->fetchAll(PDO::FETCH_ASSOC);
			//$cntcart=$stmt->rowCount();
			return $cntcart;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
	}
	
	public function editqty($u_id, $i_id, $qty, $cr_id, $cr_tot)
	{
		try
		{
			$stmt = $this->conn->prepare("UPDATE cart SET cr_qty=:qty, cr_tot=:cr_tot WHERE  cr_id = :cr_id");
			$stmt->bindparam(":qty", $qty);		
			$stmt->bindparam(":cr_id", $cr_id);
			$stmt->bindparam(":cr_tot", $cr_tot);
			$stmt->execute();	
			
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}
	
	public function addobill($o_code, $h_id, $u_id, $o_flag, $o_tot, $o_auth, $o_addr, $ob_dt)
	{
		try
		{
			$stmt = $this->conn->prepare("INSERT INTO obill (o_code, h_id, u_id, o_flag, o_tot, o_auth, o_addr,ob_dt) VALUES (:o_code, :h_id, :u_id, :o_flag, :o_tot, :o_auth, :o_addr, :ob_dt)");
			$stmt->bindparam(":o_code", $o_code);		
			$stmt->bindparam(":h_id", $h_id);
			$stmt->bindparam(":u_id", $u_id);
			$stmt->bindparam(":o_flag", $o_flag);		
			$stmt->bindparam(":o_tot", $o_tot);
			$stmt->bindparam(":o_auth", $o_auth);
			$stmt->bindparam(":o_addr", $o_addr);
			$stmt->bindparam(":ob_dt", $ob_dt);
			$stmt->execute();	
			$lasto = $this->conn->lastInsertId();
			return $lasto;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}
	
	public function fetchserv($type)
	{
		try
		{
	        $stmt = $this->conn->prepare("SELECT * FROM  services WHERE s_type=:type");
			$stmt->execute(array(':type'=>$type));
			$cntcart=$stmt->fetchAll(PDO::FETCH_ASSOC);
			//$cntcart=$stmt->rowCount();
			return $cntcart;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
	}
	
	public function fetchservi($sid)
	{
		try
		{
	        $stmt = $this->conn->prepare("SELECT * FROM  services WHERE s_id=:sid");
			$stmt->execute(array(':sid'=>$sid));
			$cntcart=$stmt->fetch(PDO::FETCH_ASSOC);
			//$cntcart=$stmt->rowCount();
			return $cntcart;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
	}
	
	public function fetchobill($user_id,$outh_url)
	{
		try
		{
	        $stmt = $this->conn->prepare("SELECT * FROM  obill WHERE u_id=:user_id AND o_auth=:outh_url");
			$stmt->execute(array(':user_id'=>$user_id,':outh_url'=>$outh_url));
			$cntcart=$stmt->fetch(PDO::FETCH_ASSOC);
			//$cntcart=$stmt->rowCount();
			return $cntcart;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
	}
	
	public function savesru($s_id, $sb_for, $u_id, $sb_dt, $sb_time,$sb_flag, $sb_addr)
	{
		try
		{
			$stmt = $this->conn->prepare("INSERT INTO sbook (s_id, sb_for, u_id, sb_dt, sb_time, sb_flag, sb_addr) VALUES (:s_id, :sb_for, :u_id, :sb_dt, :sb_time, :sb_flag, :sb_addr)");
			$stmt->bindparam(":s_id", $s_id);		
			$stmt->bindparam(":sb_for", $sb_for);
			$stmt->bindparam(":u_id", $u_id);
			$stmt->bindparam(":sb_dt", $sb_dt);		
			$stmt->bindparam(":sb_time", $sb_time);
			$stmt->bindparam(":sb_flag", $sb_flag);
			$stmt->bindparam(":sb_addr", $sb_addr);
			$stmt->execute();	
			
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}
	
	public function shoffer()
	{
		try
		{
	        $stmt = $this->conn->prepare("SELECT * FROM offers order by rand()");
			$stmt->execute();
			$shwoffers=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $shwoffers;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
	}
	
	public function fetchordli($u_id)
	{
		try
		{
	        $stmt = $this->conn->prepare("SELECT * FROM obill WHERE u_id=:u_id AND o_flag=1 ORDER BY o_id DESC");
			$stmt->execute(array(':u_id'=>$u_id));
			$fetchordli=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $fetchordli;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
	}
	
	public function searchsp($q)
	{
		try
		{
	      $stmt = $this->conn->prepare("SELECT *FROM services WHERE s_head LIKE :search ");
			$stmt->execute(array(':search' => '%'.$q.'%'));
		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $result;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
	}
	
	public function editocart($cocode,$cuid,$last)
	{
		try
		{
			$stmt = $this->conn->prepare("UPDATE  cart SET  on_id = :last, cr_flag=2 WHERE  o_code=:cocode AND u_id=:cuid");
			$stmt->bindparam(":last", $last);		
			$stmt->bindparam(":cocode", $cocode);
			$stmt->bindparam(":cuid", $cuid);
			$stmt->execute();	
			
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}
	
	public function editobil($last,$a_auth)
	{
		try
		{
			$stmt = $this->conn->prepare("UPDATE obill SET o_auth =:a_auth WHERE  o_id=:last");
			$stmt->bindparam(":a_auth", $a_auth);		
			$stmt->bindparam(":last", $last);
			$stmt->execute();	
			
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}
	

public function servicerfetch($csalt)
	{
		try
		{
			$stmt = $this->conn->prepare("SELECT * FROM service_man WHERE email=:csalt");
			$stmt->execute(array(':csalt'=>$csalt));
			$userfetch=$stmt->fetch(PDO::FETCH_ASSOC);
			return $userfetch;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}
	}
}
?>