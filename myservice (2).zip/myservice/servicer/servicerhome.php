<?php
include '../dbConnection.php';
session_start();

if (!isset($_SESSION['settings'])) {
    die("Settings are not available. Please log in.");
}

class Settings {
    private $user_data;

    public function __construct($user_data) {
        $this->user_data = $user_data;
    }

    public function userdata($key) {
        return $this->user_data[$key] ?? null;
    }
}

// Initialize $_settings with session data
$_settings = new Settings($_SESSION['settings']);

$servicer_id = $_settings->userdata('id'); // Retrieve the servicer ID
if (!$servicer_id) {
    die("Servicer ID is not available. Please log in.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service Man Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.5/css/dataTables.bootstrap5.min.css">
</head>
<body>
<div class="content py-5 mt-5">
    <div class="container">
        <div class="card card-outline card-purple shadow rounded-0">
            <div class="card-header">
                <h4 class="card-title">Assigned Services</h4>
            </div>
            <div class="card-body">
                <table class="table table-striped table-bordered table-hover">
                    <colgroup>
                        <col width="5%">
                        <col width="20%">
                        <col width="20%">
                        <col width="30%">
                        <col width="10%">
                        <col width="15%">
                    </colgroup>
                    <thead>
                        <tr class="bg-gradient-dark text-light">
                            <th class="text-center">#</th>
                            <th class="text-center">Date Assigned</th>
                            <th class="text-center">Service Name</th>
                            <th class="text-center">Details</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $i = 1;
                        $qry = $conn->query("SELECT * FROM `service_list` WHERE servicer_id = '$servicer_id' ORDER BY unix_timestamp(date_assigned) DESC");
                        if (!$qry) {
                            die("Query Failed: " . $conn->error);
                        }
                        while($row = $qry->fetch_assoc()):
                        ?>
                        <tr>
                            <td class="text-center"><?= $i++; ?></td>
                            <td><?= date("Y-m-d H:i", strtotime($row['date_assigned'])) ?></td>
                            <td><?= $row['service_name'] ?></td>
                            <td>
                                <p class="m-0 truncate-1"><b>Client:</b> <?= $row['client_name'] ?></p>
                                <p class="m-0 truncate-1"><b>Address:</b> <?= $row['service_address'] ?></p>
                            </td>
                            <td class="text-center">
                                <?php 
                                    switch($row['status']){
                                        case 0:
                                            echo "<span class='badge badge-secondary bg-gradient-secondary px-3 rounded-pill'>Pending</span>";
                                            break;
                                        case 1:
                                            echo "<span class='badge badge-primary bg-gradient-primary px-3 rounded-pill'>In Progress</span>";
                                            break;
                                        case 2:
                                            echo "<span class='badge badge-success bg-gradient-success px-3 rounded-pill'>Completed</span>";
                                            break;
                                        case 3:
                                            echo "<span class='badge badge-danger bg-gradient-danger px-3 rounded-pill'>Cancelled</span>";
                                            break;
                                    }
                                ?>
                            </td>
                            <td class="text-center">
                                <button type="button" class="btn btn-flat btn-info border btn-sm view_data" data-id="<?= $row['id'] ?>">View Details</button>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>  
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.5/js/dataTables.bootstrap5.min.js"></script>
<script>
    $(function(){
        $('table th, table td').addClass('px-2 py-1 align-middle');
        $('table').DataTable();

        $('.view_data').click(function(){
            uni_modal("Service Details", "view_service.php?id=" + $(this).attr('data-id'));
        });
    });
</script>
</body>
</html>
