<?php 
error_reporting(0);
include("lock.php");
$outh_url=$_GET['source_ref'];
if(empty($_GET['source_ref'])) {
  header("location: 404");
}
else{
	$user_id=$user['u_id'];
	$rowup = $auth_main->fetchobill($user_id,$outh_url);
	if($rowup<=0){
	header("location: 404");
	}else{
	$o_code =$rowup['o_code'];
	$o_id =$rowup['o_id'];
	$ob_dt=date("d/m/Y",$rowup['ob_dt']);
	$o_tot=$rowup['o_tot'];
	$o_addr=$rowup['o_addr'];
}
}
	?>
    <!DOCTYPE HTML>
    <html>
    <head>
	<?php include("load.php");?>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="user-scalable=no, initial-scale=1.0, maximum-scale=1.0 minimal-ui" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <link rel="icon" type="image/png" href="images/splash/android-chrome-192x192.png" sizes="192x192">
    <link rel="apple-touch-icon" sizes="196x196" href="images/splash/apple-touch-icon-196x196.png">
    <link rel="apple-touch-icon" sizes="180x180" href="images/splash/apple-touch-icon-180x180.png">
    <link rel="apple-touch-icon" sizes="152x152" href="images/splash/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="144x144" href="images/splash/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="120x120" href="images/splash/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="114x114" href="images/splash/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="76x76" href="images/splash/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="72x72" href="images/splash/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="60x60" href="images/splash/apple-touch-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="57x57" href="images/splash/apple-touch-icon-57x57.png">
    <link rel="icon" type="image/png" href="images/splash/favicon-96x96.png" sizes="96x96">
    <link rel="icon" type="image/png" href="images/splash/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="images/splash/favicon-16x16.png" sizes="16x16">
    <link rel="shortcut icon" href="images/splash/favicon.ico" type="image/x-icon" />
    <link href='https://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Raleway:900,800,700' rel='stylesheet' type='text/css'>
    <title>Genie</title>
    <link href="styles/style.css" rel="stylesheet" type="text/css">
    <link href="styles/framework.css" rel="stylesheet" type="text/css">
    <link href="styles/font-awesome.css" rel="stylesheet" type="text/css">
    <script type="text/javascript" src="scripts/jquery.js"></script>
    <script type="text/javascript" src="scripts/plugins.js"></script>
    <script type="text/javascript" src="scripts/custom.js"></script>
</head>
    <?php 
if(!isset($_GET['rel'])){
	echo "<body id='view'>";
}
?>
        <div class="gallery-fix"></div>
        <div class="sidebar-tap-close"></div>
        <?php require_once("header.php"); ?>
    <div id="page-content">
        <div id="page-content-scroll">
            <div class="header-clear"></div>
                <div class="decoration-lines container-fullscreen">
                    <div class="deco-0"></div>
                    <div class="deco-1"></div>
                    <div class="deco-2"></div>
                    <div class="deco-3"></div>
                    <div class="deco-4"></div>
                    <div class="deco-5"></div>
                    <div class="deco-6"></div>
                    <div class="deco-7"></div>
                    <div class="deco-8"></div>
                    <div class="deco-9"></div>
                </div>
           
            <div class="content">
                <div class="store-product-header">
                    <h3 class="center-text">Order Successfully Submitted</h3>
                   <div class="cart-costs">
<h5><strong>Order ID</strong><em class="color-red-dark"><?php echo date("Y")."ord-".$o_id ;?></em></h5>
<h5><strong>Order Date</strong><em class="color-green-dark"><?php echo $ob_dt ;?></em></h5>
<h5><strong>Delivery</strong><em> Rs.40.00/- </em></h5>
<h5><strong>Total</strong><em>Rs.<?php echo $o_tot-40 ;?> /-</em></h5>

 <h6><strong>Payable Amount</strong><em>Rs.<?php echo $o_tot ;?> /-</em></h6>
<div class="clear"></div>
</div>
                    
                    <div class="decoration"></div>
                    <div class="container heading-style">
                        <h4 class="heading-title">Be ready for next order!</h4>
                        <i class="fa fa-star-o heading-icon"></i>
                        <div class="line bg-black"></div>
                    </div>
                    <div class="store-thumbnails">
                        <?php
	$fetchhcat = $auth_main->shwhc(1);
	foreach ($fetchhcat as $fetchhcata){
	$hc_name=$fetchhcata['hc_name'];
	$hc_icons=$fetchhcata['hc_icons'];
	$hc_id=$fetchhcata['hc_id'];
	$hc_icon = str_replace("../icons/100_","",$hc_icons);
			?>
                            <a href="details?<?php echo $hc_id; ?>" rel="tab" >
             <u><?php echo $hc_name; ?></u>
            <u style="top: 26%;"><img src="icons/<?php echo $hc_icon; ?>" alt="img"></u>
                                <img src="images/pictures/1t.jpg" alt="img">
                                <em class="overlay "></em>
                            </a>
                            <?php } ?>
                    </div>
                </div>
            </div>
                    <div class="footer">
                        <div class="footer-content">
                            <h3 class="footer-logo">Genie Services</h3>
                            <p class="footer-text">
                              Wide Range Of professional Services at Affordable Prices anytime & anywhere in city.
                            </p>
                        </div>
                        <div class="footer-socials">
                            <a href="#" class="scale-hover facebook-color"><i class="fa fa-facebook"></i></a>
                            <a href="#" class="scale-hover twitter-color"><i class="fa fa-twitter"></i></a>
                            <a href="#" class="scale-hover google-color"><i class="fa fa-google-plus"></i></a>
                            <a href="#" class="scale-hover phone-color"><i class="fa fa-phone"></i></a>
                            <a href="#" class="scale-hover mail-color"><i class="fa fa-envelope-o"></i></a>
                            <a href="#" class="scale-hover bg-night-dark back-to-top"><i class="fa fa-angle-up"></i></a>
                            <div class="clear"></div>
                        </div>
                        <p class="footer-strip">Copyright <span id="copyright-year"></span> . All Rights Reserved</p>
                    </div>
                </div>
                <a href="#" class="back-to-top-badge"><i class="fa fa-caret-up"></i>Back to top</a>
            </div>
            <div class="share-bottom">
                <h3>Share Page</h3>
                <div class="share-socials-bottom">
                    <a href="#">
                        <i class="fa fa-facebook facebook-color"></i> Facebook
                    </a>
                    <a href="#">
                        <i class="fa fa-twitter twitter-color"></i> Twitter
                    </a>
                    <a href="#">
                        <i class="fa fa-google-plus google-color"></i> Google
                    </a>
                    <a href="#">
                        <i class="fa fa-pinterest-p pinterest-color"></i> Pinterest
                    </a>
                    <a href="sms:">
                        <i class="fa fa-comment-o sms-color"></i> Text
                    </a>
                    <a href="#">
                        <i class="fa fa-envelope-o mail-color"></i> Email
                    </a>
                    <div class="clear"></div>
                </div>
            </div>
            <?php 
if(!isset($_GET['rel'])){
	echo "</body>";
}?>

    </html>