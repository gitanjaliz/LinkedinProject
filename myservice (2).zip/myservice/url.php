<?php
/*
$request = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'].$_SERVER['QUERY_STRING'];
$query_str = parse_url($url, PHP_URL_QUERY);
parse_str($query_str, $query_params);
print_r($query_params);
*/
//Output: Array ( [email] => xyz4@test.com [testin] => 123 ) 

echo substr("20172134234223", -2);
?>