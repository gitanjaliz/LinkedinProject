<?php require_once("lock.php"); ?>
<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="user-scalable=no, initial-scale=1.0, maximum-scale=1.0 minimal-ui" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <link rel="icon" type="image/png" href="images/splash/android-chrome-192x192.png" sizes="192x192">
    <link rel="apple-touch-icon" sizes="196x196" href="images/splash/apple-touch-icon-196x196.png">
    <link rel="apple-touch-icon" sizes="180x180" href="images/splash/apple-touch-icon-180x180.png">
    <link rel="apple-touch-icon" sizes="152x152" href="images/splash/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="144x144" href="images/splash/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="120x120" href="images/splash/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="114x114" href="images/splash/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="76x76" href="images/splash/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="72x72" href="images/splash/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="60x60" href="images/splash/apple-touch-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="57x57" href="images/splash/apple-touch-icon-57x57.png">
    <link rel="icon" type="image/png" href="images/splash/favicon-96x96.png" sizes="96x96">
    <link rel="icon" type="image/png" href="images/splash/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="images/splash/favicon-16x16.png" sizes="16x16">
    <link rel="shortcut icon" href="images/splash/favicon.ico" type="image/x-icon" />
    <link href='https://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Raleway:900,800,700' rel='stylesheet' type='text/css'>
    <title>Genie</title>
    <link href="styles/style.css" rel="stylesheet" type="text/css">
    <link href="styles/framework.css" rel="stylesheet" type="text/css">
    <link href="styles/font-awesome.css" rel="stylesheet" type="text/css">
    <script type="text/javascript" src="scripts/jquery.js"></script>
    <script type="text/javascript" src="scripts/plugins.js"></script>
    <script type="text/javascript" src="scripts/custom.js"></script>
	<script type="text/javascript" >
	function rcart(i){
		//alert("rcart"+i);
		$("#it"+i).attr("onclick","cart("+i+")");
		$.ajax({
		 type	: "POST",
		 url	: "removecart.php",
		 data   : {i:i},
		 success: function(result){
			 $('#ccnt').load(document.URL +  ' #ccnt');
			  $('#ccntee').load(document.URL +  ' #ccntee');
			  $('#done').load(document.URL +  ' #done');
	        }	
        });
	}
	</script>
		<script type="text/javascript" >
	function quantityChange(i){
		//alert("aaa");
		var qty = $("#qty"+i).val();
		var qtty= parseInt(qty)+ parseInt("1");
			//alert(i+"xxx"+qtty);
		$.ajax({
		 type	: "POST",
		 url	: "editqty.php",
		 data   : {i:i,qtty:qtty},
		 success: function(result){
			 $('#ccnt').load(document.URL +  ' #ccnt');
			  $('#ccntee').load(document.URL +  ' #ccntee');
			  $('#done').load(document.URL +  ' #done');
	        }	
        });
	}
	</script>
	<script type="text/javascript" >
	function qtaddChange(i,cr_id,price){
		//alert("aaa");
		var qty = $("#qty"+i).val();
		var qtty= parseInt(qty)+ parseInt("1");
			//alert(i+"xxx"+qtty+"xxxx"+cr_id+"xxx"+price);
		$.ajax({
		 type	: "POST",
		 url	: "editqty.php",
		 data   : {i:i,qtty:qtty,cr_id:cr_id,price:price},
		 success: function(result){
			$('#done').load(document.URL +  ' #done');
	        }	
        });
	}
	</script>
	<script type="text/javascript" >
	function qtcutChange(i,cr_id,price){
		//alert("aaa");
		var qty = $("#qty"+i).val();
		var qtty= parseInt(qty) - parseInt("1");
		if(qtty > 0){
			//alert(i+"xxx"+qtty+"xxxx"+cr_id+"xxx"+price);
		$.ajax({
		 type	: "POST",
		 url	: "editqty.php",
		 data   : {i:i,qtty:qtty,cr_id:cr_id,price:price},
		 success: function(result){
			$('#done').load(document.URL +  ' #done');
	        }	
        });
		}
	}
	</script>
</head>
    <?php 
if(!isset($_GET['rel'])){
	echo "<body id='view'>";
}
?>
    <div class="gallery-fix"></div>
    <div class="sidebar-tap-close"></div>
      <?php require_once("header.php"); ?>    
    <div id="page-content">
        <div id="page-content-scroll">
            <div class="header-clear-large"></div>
            <div class="content">
                <div id="done" class="store-cart-1">
				<?php $grandtotal="0"; $hoid = array();
				$ccart=$auth_main->cntcart($uid,$ode);
						foreach($ccart as $cartdata){
						$i_id=$cartdata['i_id'];
						$cr_id=$cartdata['cr_id'];
						$ocode=$cartdata['o_code'];
						$o_auth=md5($ocode.$uid);
						$price=$cartdata['price'];
						$cr_tot=$cartdata['cr_tot'];
						$cr_qty=$cartdata['cr_qty'];
						$grandtotal += $cr_tot;
						$hoid[]=$cartdata['h_id'];
				if($ccart > 0){ ?>
                    <div class="cart-item">
                       
                        <h1><?php echo $cartdata['ic_name']; ?></h1>
                        <h2><?php echo $cr_tot; ?></h2>
                        <h3><?php echo $cartdata['h_name']; ?></h3>
                        <h4>
<a  class="add-qty" onclick="qtaddChange('<?php echo $i_id ;?>','<?php echo $cr_id ;?>','<?php echo $price ;?>')"><i class="fa fa-plus"></i></a>
<input id="qty<?php echo $i_id ;?>"  type="text" readonly="readonly" value="<?php echo $cr_qty; ?>" class="qty" name="qty<?php echo $i_id ;?>" >
<a  onclick="qtcutChange('<?php echo $i_id ;?>','<?php echo $cr_id ;?>','<?php echo $price ;?>')" class="substract-qty"><i class="fa fa-minus"></i></a>
</h4>
                        <h5><a class="remove-cart-item" id="it<?php echo $i_id ;?>" onclick="rcart('<?php echo $i_id ;?>')" href="#"><i class="fa fa-times"></i></a></h5>
                    </div>
						<?php }else{ ?>
						 <h4>Your cart is Empty </h4>
						<?php } } ?>
                    <h4><textarea id="addr" style="width: 100%;" placeholder="Enter Delivery Address" value="" name="addr"><?php echo $user['u_addr']; ?></textarea></h4>
                    <div class="clear"></div>
                    <div class="decoration"></div>
                    <div id="ccntee" class="cart-costs">
                        <h4>Estimated Costs</h4>
                        <h5><strong>Delivery</strong><em>Rs 40.00</em></h5>
                        <h6><strong>Grand Total</strong><em>Rs <?php echo $gtotal=$grandtotal+ 40; ?></em></h6>
                        <div class="clear"></div>
						<?php $huid=array_unique($hoid);
						$h_id=implode("-", $huid); ?>
                        <input type="button" style="cursor: pointer;" id="final" onclick="checkout('<?php echo $uid; ?>','<?php echo $ode; ?>','<?php echo $gtotal; ?>','<?php echo $h_id; ?>')" class="button button-green button-fullscreen half-top" value="Proceed to Checkout" />
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
            <div class="footer">
                <div class="footer-content">
                            <h3 class="footer-logo">Make a wish Services</h3>
                            <p class="footer-text">
                              Wide Range Of professional Services at Affordable Prices anytime & anywhere in city.
                            </p>
                        </div>
                <div class="footer-socials">
                    <a href="#" class="scale-hover facebook-color"><i class="fa fa-facebook"></i></a>
                    <a href="#" class="scale-hover twitter-color"><i class="fa fa-twitter"></i></a>
                    <a href="#" class="scale-hover google-color"><i class="fa fa-google-plus"></i></a>
                    <a href="#" class="scale-hover phone-color"><i class="fa fa-phone"></i></a>
                    <a href="#" class="scale-hover mail-color"><i class="fa fa-envelope-o"></i></a>
                    <a href="#" class="scale-hover bg-night-dark back-to-top"><i class="fa fa-angle-up"></i></a>
                    <div class="clear"></div>
                </div>
                <p class="footer-strip">Copyright <span id="copyright-year"></span> . All Rights Reserved</p>
            </div>
        </div>
        <a href="#" class="back-to-top-badge"><i class="fa fa-caret-up"></i>Back to top</a>
    </div>
    <div class="share-bottom">
        <h3>Share Page</h3>
        <div class="share-socials-bottom">
            <a href="#">
                <i class="fa fa-facebook facebook-color"></i> Facebook
            </a>
            <a href="#">
                <i class="fa fa-twitter twitter-color"></i> Twitter
            </a>
            <a href="#">
                <i class="fa fa-google-plus google-color"></i> Google
            </a>
            <a href="#">
                <i class="fa fa-pinterest-p pinterest-color"></i> Pinterest
            </a>
            <a href="#">
                <i class="fa fa-comment-o sms-color"></i> Text
            </a>
            <a href="#">
                <i class="fa fa-envelope-o mail-color"></i> Email
            </a>
            <div class="clear"></div>
        </div>
    </div>
	<script type="text/javascript" >
	function checkout(uid, ocode, gtot, hid){
			var addr = $("#addr").val();
			$("#final").attr("onclick","");
			$("#final").attr("value","please Wait");
			if(addr!="" && hid!="" && ocode!="" && gtot!=""){
			//alert(uid+"xxxxx"+ocode+"xxxxx"+gtot+"xxx"+addr+"xxxx"+hid);
		$.ajax({
		 type	: "POST",
		 url	: "addobill.php",
		 data   : {uid:uid, ocode:ocode, gtot:gtot, addr:addr, hid:hid},
		 success: function(result){
			$('#done').load(document.URL +  ' #done');
			$("#final").attr("onclick","");
			setTimeout(' window.location.href = "complete?source_ref=<?php echo $o_auth; ?>"; ',1000);
	        }	
        });
			}else{
				 $("#final").attr("onclick","");
			}
	}
	</script>
            <?php 
if(!isset($_GET['rel'])){
	echo "</body>";
}?>
</html>