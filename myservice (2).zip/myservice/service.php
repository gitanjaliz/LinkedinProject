<?php require_once("lock.php");
	 if(!isset($_GET)){
			header("location:404");
}else{
	foreach($_GET as $key=>$value);
	$sid=$key;
	$service= $auth_main->fetchservi($sid);
	
}
?>
<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="user-scalable=no, initial-scale=1.0, maximum-scale=1.0 minimal-ui" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <link rel="icon" type="image/png" href="images/splash/android-chrome-192x192.png" sizes="192x192">
    <link rel="apple-touch-icon" sizes="196x196" href="images/splash/apple-touch-icon-196x196.png">
    <link rel="apple-touch-icon" sizes="180x180" href="images/splash/apple-touch-icon-180x180.png">
    <link rel="apple-touch-icon" sizes="152x152" href="images/splash/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="144x144" href="images/splash/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="120x120" href="images/splash/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="114x114" href="images/splash/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="76x76" href="images/splash/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="72x72" href="images/splash/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="60x60" href="images/splash/apple-touch-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="57x57" href="images/splash/apple-touch-icon-57x57.png">
    <link rel="icon" type="image/png" href="images/splash/favicon-96x96.png" sizes="96x96">
    <link rel="icon" type="image/png" href="images/splash/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="images/splash/favicon-16x16.png" sizes="16x16">
    <link rel="shortcut icon" href="images/splash/favicon.ico" type="image/x-icon" />
    <link href='https://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Raleway:900' rel='stylesheet' type='text/css'>
    <title>Genie</title>
    <link href="styles/style.css" rel="stylesheet" type="text/css">
    <link href="styles/framework.css" rel="stylesheet" type="text/css">
    <link href="styles/font-awesome.css" rel="stylesheet" type="text/css">
    <script type="text/javascript" src="scripts/jquery.js"></script>
    <script type="text/javascript" src="scripts/plugins.js"></script>
    <script type="text/javascript" src="scripts/custom.js"></script>
	<script type="text/javascript">
function savesvu(){
	
    var pdate=$("#pdate").val();
	var sru_desc=$("#sru_desc").val();
    var sru_addr=$("#sru_addr").val();
	 var s_id=$("#s_id").val();
	 //alert(sru_desc+"xxxx"+pdate+"xxxx"+sru_addr+"xxxx"+s_id);
	if(pdate!="" && sru_desc!="" && sru_addr!="" && s_id!=""){
		var form = $("#fform");
	$.ajax({
            type: 'POST',
            url: 'savesru.php',
            data: form.serialize(),
            success: function(data){  
			//alert(data);
		  if(data == "Success")
		{ 
		  $('#fform')[0].reset();
			 $('#'+data).html("Please allow up to few minutes for a reply! Thanks!");
			  $('#'+data).show();	
			  $('#'+data).focus();
			$('#'+data).fadeOut(9000);
		}
		else
		{ 
		//alert(data);
		 $('#error').html(data);
		  $('#error').show();
		  $('#error').focus();
			$('#error').fadeOut(5000);
			//$('#fform')[0].reset();
		}
		}                                    	  
         }); 
	}else{
			 $('#error').text("please fill all mandatory fields");
		  $('#error').show();	
			$('#error').fadeOut(5000);
			//$('#fform')[0].reset();
	}
	}
</script>
</head>

    <?php 
if(!isset($_GET['rel'])){
	echo "<body id='view'>";
}
?>
        <div class="gallery-fix"></div>
        <div class="sidebar-tap-close"></div>
        <?php require_once("header.php"); ?>
    <div id="page-content">
        <div id="page-content-scroll">
            <div class="header-clear"></div>
            <div class="content-fullscreen">
                <div class="page-profile">
                    <div class="page-profile-header">
                        <h3><?php echo $service['s_head']; ?></h3>
                        <em><i class="fa fa-location-arrow"></i><?php echo $service['s_desc']; ?></em>
                        <div class="overlay bg-black"></div>
                        
                    </div>
                </div>
            </div>
			
            <div class="content">
			<div class="page-profile-followers">
                        <a href="#">
                            <i class="fa fa-user-plus"></i><strong> Book</strong>
							<p style="line-height: 11px; font-size:10px;padding: 2px;">Share your need and information with us.</p>
                        </a>
                        <a href="#">
                            <i class="fa fa-clock-o "></i> <strong>Schedule</strong>
							<p style="line-height: 11px; font-size:10px;padding: 2px;">Schedule a time for us to attend to you.</p>
                        </a>
                        <a href="#">
                            <i class="fa fa-thumbs-up "></i> <strong>Relax</strong>
							<p style="line-height: 11px; font-size:10px;padding: 2px;">Our expert team will do the assigned task.</p>
							</a>
                    </div>
			<div class="page-profile-followers">
                        <a href="#">
                            <i class="fa fa-certificate"></i><strong> Customize</strong>
							<p style="line-height: 11px; font-size:10px;padding: 2px;">Customize orders as per your need </p>
                        </a>
                        <a href="#">
                            <i class="fa fa-star"></i> <strong> Trusted</strong>
							<p style="line-height: 11px; font-size:10px;padding: 2px;">Trusted And Expert Service Providers</p>
                        </a>
                        <a href="#">
                            <i class="fa fa-money "></i> <strong>Easy Payment </strong>
							<p style="line-height: 11px; font-size:10px;padding: 2px;">Pay through paytm or online Services</p>
							</a>
                    </div>
		 <p class="center-text">Terms & Conditions are applied when you book a Service</p>
		 <h5 class="center-text"> visit charges Rs.<?php echo $service['s_fees']; ?>/- </h5>
<div class="contact-form no-bottom boxed-item">
<form id="fform" action='javascript:;' name="fform" onsubmit="savesvu()" Method="POST" >
<fieldset>
<div class="center-text uppercase small-text formSuccessMessageWrap color-white" id="Success">
</div>
<div class="center-text uppercase small-text formValidationError bg-red-dark color-white" id="error">
</div>
<div class="formFieldWrap">
<label class="field-title contactNameField" >Meeting Date :<span>(required)</span></label>
<input class="contactField requiredField"  type="text" name="pdate" placeholder="dd-mm-yyyy" readonly="readonly" id="pdate" value="" >
</div>
<div class="formTextareaWrap">
<label class="field-title contactMessageTextarea" >Your Requirements : <span>(required)</span></label>
<textarea name="sru_desc" class="contactTextarea requiredField" value="" id="sru_desc"></textarea>
</div>
<div class="formTextareaWrap">
<label class="field-title contactMessageTextarea" >Full Address & pincode: <span>(required)</span></label>
<textarea name="sru_addr" class="contactTextarea requiredField" value="" id="sru_addr"><?php echo $user['u_addr'] ;?></textarea>
</div>
<input   type="hidden" name="s_id" readonly="readonly" id="s_id" value="<?php echo $sid; ?>" >
<div class="formSubmitButtonErrorsWrap contactFormButton">
<input type="submit" class="buttonWrap button button-green contactSubmitButton" id="login" value="Book Service" />
</div>
</fieldset>
</form>
</div>
<div class="small-decoration bg-red-dark"></div>
<div class="container no-bottom">

</div>
</div>
                    <div class="footer">
                        <div class="footer-content">
                            <h3 class="footer-logo">Genie Services</h3>
                            <p class="footer-text">
                                We aim to simplify your life by creating a beautiful and simple product that's feature rich and easy to use!
                            </p>
                        </div>
                        <div class="footer-socials">
                            <a href="#" class="scale-hover facebook-color"><i class="fa fa-facebook"></i></a>
                            <a href="#" class="scale-hover twitter-color"><i class="fa fa-twitter"></i></a>
                            <a href="#" class="scale-hover google-color"><i class="fa fa-google-plus"></i></a>
                            <a href="#" class="scale-hover phone-color"><i class="fa fa-phone"></i></a>
                            <a href="#" class="scale-hover mail-color"><i class="fa fa-envelope-o"></i></a>
                            <a href="#" class="scale-hover bg-night-dark back-to-top"><i class="fa fa-angle-up"></i></a>
                            <div class="clear"></div>
                        </div>
                        <p class="footer-strip">Copyright <span id="copyright-year"></span> . All Rights Reserved</p>
                    </div>
                </div>
                <a href="#" class="back-to-top-badge"><i class="fa fa-caret-up"></i>Back to top</a>
            </div>
            <div class="share-bottom">
                <h3>Share Page</h3>
                <div class="share-socials-bottom">
                    <a href="#">
                        <i class="fa fa-facebook facebook-color"></i> Facebook
                    </a>
                    <a href="#">
                        <i class="fa fa-twitter twitter-color"></i> Twitter
                    </a>
                    <a href="#">
                        <i class="fa fa-google-plus google-color"></i> Google
                    </a>
                    <a href="#">
                        <i class="fa fa-pinterest-p pinterest-color"></i> Pinterest
                    </a>
                    <a href="sms:">
                        <i class="fa fa-comment-o sms-color"></i> Text
                    </a>
                    <a href="#">
                        <i class="fa fa-envelope-o mail-color"></i> Email
                    </a>
                    <div class="clear"></div>
                </div>
            </div>
<link href="date/jquery-ui.css" rel="Stylesheet" type="text/css" />
    <script type="text/javascript" src="date/jquery-1.7.2.min.js"></script>
    <script type="text/javascript" src="date/jquery-ui.js"></script>
   <script language="javascript">
        $(document).ready(function () {
            $("#pdate").datepicker({
                minDate: 0
            });
        });
    </script>
            <?php 
if(!isset($_GET['rel'])){
	echo "</body>";
}?>

</html>