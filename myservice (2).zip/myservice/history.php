<?php require_once("lock.php"); ?>
    <!DOCTYPE HTML>
    <html>
    <head>
        <?php include("load.php");?>
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
            <meta name="viewport" content="user-scalable=no, initial-scale=1.0, maximum-scale=1.0 minimal-ui" />
            <meta name="apple-mobile-web-app-capable" content="yes" />
            <meta name="apple-mobile-web-app-status-bar-style" content="black">
            <link rel="icon" type="image/png" href="images/splash/android-chrome-192x192.png" sizes="192x192">
            <link rel="apple-touch-icon" sizes="196x196" href="images/splash/apple-touch-icon-196x196.png">
            <link rel="apple-touch-icon" sizes="180x180" href="images/splash/apple-touch-icon-180x180.png">
            <link rel="apple-touch-icon" sizes="152x152" href="images/splash/apple-touch-icon-152x152.png">
            <link rel="apple-touch-icon" sizes="144x144" href="images/splash/apple-touch-icon-144x144.png">
            <link rel="apple-touch-icon" sizes="120x120" href="images/splash/apple-touch-icon-120x120.png">
            <link rel="apple-touch-icon" sizes="114x114" href="images/splash/apple-touch-icon-114x114.png">
            <link rel="apple-touch-icon" sizes="76x76" href="images/splash/apple-touch-icon-76x76.png">
            <link rel="apple-touch-icon" sizes="72x72" href="images/splash/apple-touch-icon-72x72.png">
            <link rel="apple-touch-icon" sizes="60x60" href="images/splash/apple-touch-icon-60x60.png">
            <link rel="apple-touch-icon" sizes="57x57" href="images/splash/apple-touch-icon-57x57.png">
            <link rel="icon" type="image/png" href="images/splash/favicon-96x96.png" sizes="96x96">
            <link rel="icon" type="image/png" href="images/splash/favicon-32x32.png" sizes="32x32">
            <link rel="icon" type="image/png" href="images/splash/favicon-16x16.png" sizes="16x16">
            <link rel="shortcut icon" href="images/splash/favicon.ico" type="image/x-icon" />
            <link href="https://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic" rel="stylesheet" type="text/css">
            <link href="https://fonts.googleapis.com/css?family=Raleway:900,800,700" rel="stylesheet" type="text/css">
            <title>Genie</title>
            <link href="styles/style.css" rel="stylesheet" type="text/css">
            <link href="styles/framework.css" rel="stylesheet" type="text/css">
            <link href="styles/font-awesome.css" rel="stylesheet" type="text/css">
            <script type="text/javascript" src="scripts/jquery.js"></script>
            <script type="text/javascript" src="scripts/plugins.js"></script>
            <script type="text/javascript" src="scripts/custom.js"></script>
    </head>
    <?php 
if(!isset($_GET['rel'])){
	echo "<body id='view'>";
}
?>
        <div class="gallery-fix"></div>
        <div class="sidebar-tap-close"></div>
        <?php require_once("header.php"); ?>
            <div id="page-content">
                <div id="page-content-scroll">
                    <div class="header-clear-large"></div>
                    <div class="content">
                    <div class="one-half-responsive">
                            <h4>Orders History</h4>
                            <p>
                                Orderes succesfully delivered to you!
                            </p>
							<?php $fetchordli=$auth_main->fetchordli($uid);
							foreach($fetchordli as $ordlist){
							?>
                            <div class="toggle store-history-toggle">
                                <a href="#" class="toggle-title"><strong class="bg-green-dark">Order ID: <?php echo $ordlist['o_id']; ?></strong><?php echo date("d M Y", $ordlist['ob_dt']); ?><i class="fa fa-plus"></i></a>
                                <div class="toggle-content">
								<?php $grandtotal="0"; $hoid = array();
				$ccart=$auth_main->cntcart($uid,$ordlist['o_code']);
						foreach($ccart as $cartdata){
						$i_id=$cartdata['i_id'];
						$cr_id=$cartdata['cr_id'];
						$ocode=$cartdata['o_code'];
						$o_auth=md5($ocode);
						$price=$cartdata['price'];
						$cr_tot=$cartdata['cr_tot'];
						$cr_qty=$cartdata['cr_qty'];
						$grandtotal += $cr_tot;
						$hoid[]=$cartdata['h_id'];
				?>
                                    <div class="store-history-item">
                                        <h1><?php echo $cartdata['ic_name']; ?></h1>
                                        <h2><?php echo $cartdata['h_name']; ?></h2>
                                        <h3 class="color-green-dark">Price: <?php echo $cr_tot; ?></h3>
                                        <h4>Quantity: <?php echo $cr_qty; ?></h4>
                                    </div>
						<?php } ?>
                                    <div class="cart-costs">
                                        <h4>Delivery Details</h4>
                                        <h5><strong>Unique ID</strong><em><?php echo $ordlist['o_id']; ?></em></h5>
                                        <h5><strong>Status</strong><em>Delivered</em></h5>
                                        <h5><strong>Delivery</strong><em>Rs. 40.00/-</em></h5>
                                        <h5><strong>Total</strong><em class="color-green-dark">Rs. <?php echo $grandtotal; ?> /- </em></h5>
                                        <h6><strong>Grand Total</strong><em>Rs. <?php echo $grandtotal+40; ?> /- </em></h6>
                                        <div class="clear"></div>
                                    </div>
                                </div>
                            </div>
							<?php } ?>
						<div class="clear"></div>	
                    </div>
					</div>                 
                </div>
                <a href="#" class="back-to-top-badge"><i class="fa fa-caret-up"></i>Back to top</a>
            </div>
            <?php 
if(!isset($_GET['rel'])){
	echo "</body>";
}?>

    </html>