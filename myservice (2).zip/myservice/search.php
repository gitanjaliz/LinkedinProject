<?php
require_once('lock.php');
if($_POST)
{
$q=$_POST['searchword'];
$searchsp=$auth_main->searchsp($q);  ?>
 <div id="page-content">
        <div id="page-content-scroll">
            <div class="header-clear"></div>
            <div class="decoration"></div>
            <div class="content">
                <div class="container heading-style">
                    <h4 class="heading-title">Service Provider Search</h4>
                    <i class="fa fa-star heading-icon"></i>
                    <div class="line bg-black"></div>
                </div>
                <div class="store-items">
				<?php foreach ($searchsp as $fetchcustdiv){
	$s_head=$fetchcustdiv['s_head'];
	$s_id=$fetchcustdiv['s_id'];
	$s_img=$fetchcustdiv['s_img'];
							$s_backimg = str_replace("../","",$s_img);
								?>
                    <div class="store-item">
                        <a href="service?<?php echo $s_id; ?>" rel="tab"><img src="<?php echo $s_backimg; ?>" alt="img"></a>
                        <strong><?php echo $s_head; ?></strong>
                    </div>
				<?php } ?>
                    <div class="clear"></div>
                </div>
            </div>
    </div>
    </div>
<?php } ?>