<?php
include('lock.php');
if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
{
	$i_id = $_POST['i'];
	$cr_tot = $_POST['tot'];
	$u_id = $user['u_id'];
	$ca_dt = time();
	$cr_flag = 1;
						$order=$auth_main->fetchorder($u_id);
										if($order == 0){
											$incode=$order + 1;
											$o_code=date("Y")."ord"."-".$incode;
											$auth=md5($o_code);
										}else{
										$icode=$order['o_code'];
										$parts = explode('-', "$icode");
										$icnt = $parts[1];
										$incode=$icnt + 1;
										$o_code=date("Y")."ord"."-".$incode;
											$auth=md5($o_code);
										}
									
				if($auth_main->addcart($u_id, $i_id, $cr_flag, $ca_dt, $o_code,$cr_tot))
				{	
				echo "Success" ;
				}
				else
				{
				echo "Fails upload";
				}
}
?>