<?php require_once("controller/class.user.php");
		$auth_main = new USER();
$error="";
if($_SERVER["REQUEST_METHOD"] == "POST")
{
	if($_POST['username'] && $_POST['password'])
	{
// username and password sent from Form
 $uname=$_POST['username']; 
 $umail=$_POST['username']; 
 $mypassword=$_POST['password']; 
 $upass=md5($mypassword); // Encrypted Password
if($salt=$auth_main->doLogin($uname,$umail,$upass))
	{
		
		 $slt=$salt['salt'];
		 $sluid=$salt['userid'];
		if($auth_main->updsalt($slt,$sluid)){
		echo"Success";
		}
	}
	else
	{
		echo "Wrong Details !";
	}
	}
}