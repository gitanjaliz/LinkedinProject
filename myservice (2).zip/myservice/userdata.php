<?php require_once("controller/class.user.php");
		$auth_main = new USER();
if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
{
			$u_name=$_POST['u_name'];						  
			$u_cont=$_POST['u_cont'];	
			$u_pass=$_POST['password'];
			$u_flag="1";
			$u_email=$_POST['u_email'];
			$u_addr=$_POST['u_addr'];
			$pincode=$_POST['pincode'];	
			$count=$auth_main->validcont($u_cont);
	if($count >= 1){
		echo "Contact No Already Registered";
	}else{	
				if($auth_main->register($u_name, $u_cont, $u_pass, $u_flag, $u_email, $u_addr, $pincode))
				{	
				echo "Success" ;
				}
				else
				{
				echo "registration Fails";
				}
	}
}
?>

