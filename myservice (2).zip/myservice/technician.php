<?php 
require_once("lock.php"); 
require_once("config/dbconfig.php");

$database = new Database();
$conn = $database->dbConnection();

// Check connection
if (!$conn) {
    echo "Database connection failed!";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

    <!-- Meta and title -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Mosaddek">
    <meta name="keyword" content="FlatLab, Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
    <link rel="shortcut icon" href="views/img/favicon.html">
    <title><?php echo defined('TITLE') ? TITLE : 'Technician List'; ?></title>

    <!-- Stylesheets -->
    <link href="views/css/bootstrap.min.css" rel="stylesheet">
    <link href="views/css/bootstrap-reset.css" rel="stylesheet">
    <link href="views/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="views/css/table-responsive.css" rel="stylesheet" />
    <link href="views/css/style.css" rel="stylesheet">
    <link href="views/css/style-responsive.css" rel="stylesheet">  
    <title>Genie</title>
        <link href="styles/style.css" rel="stylesheet" type="text/css">
        <link href="styles/framework.css" rel="stylesheet" type="text/css">
        <link href="styles/font-awesome.css" rel="stylesheet" type="text/css">
        <script type="text/javascript" src="scripts/jquery.js"></script>
        <script type="text/javascript" src="scripts/plugins.js"></script>
        <script type="text/javascript" src="scripts/custom.js"></script>

    <style>
        .wide-btn {
            width: 120px; /* Adjust width as needed */
            text-align: center; /* Center text and icons */
        }
        .technician-title {
        font-size: 18px;
        color: #ffffff;
        background-color: #343a40;
        padding: 10px;
        border-radius: 5px;
        text-align: center;
    }
    </style>
</head>
<body>
<section id="container" class="">
    <!-- Header -->
    <?php include "header.php"; ?>
    
    <!-- Main content -->
    <section id="main-content">
        <section class="wrapper">
            <div class="row">
                <div class="col-lg-12" id="edit_view">
                    <section class="panel">
                        <header class="panel-heading">
                            Servicer Details
                        </header>
                        <div class="panel-body">
                            <div class="col-sm-9 col-md-10 mt-5 text-center">
                                <!-- Table -->
                                <p class="technician-title">List of Technicians</p>
                                <?php
                                // Fetching technician records from the database
                                $sql = "SELECT * FROM service_man";
                                $stmt = $conn->prepare($sql);
                                $stmt->execute();
                                $technicians = $stmt->fetchAll(PDO::FETCH_ASSOC);

                                // Check if results are available
                                if ($technicians) {
                                    echo '<table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th scope="col">Emp ID</th>
                                            <th scope="col">Name</th>
                                            <th scope="col">City</th>
                                            <th scope="col">Mobile</th>
                                            <th scope="col">Email</th>
                                            <th scope="col">Experience</th>
                                            <th scope="col">Service Type</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>';

                                    foreach ($technicians as $row) {
                                        echo '<tr>';
                                        echo '<th scope="row">' . htmlspecialchars($row["m_id"]) . '</th>';
                                        echo '<td>' . htmlspecialchars($row["username"]) . '</td>';
                                        echo '<td>' . htmlspecialchars($row["address"]) . '</td>';
                                        echo '<td>' . htmlspecialchars($row["contact"]) . '</td>';
                                        echo '<td>' . htmlspecialchars($row["email"]) . '</td>';
                                        echo '<td>' . htmlspecialchars($row["work_experience"]) . ' years</td>';
                                        echo '<td>' . htmlspecialchars($row["service_type"]) . '</td>';

                                        echo '</tr>';
                                    }

                                    echo '</tbody></table>';
                                } else {
                                    echo "<p class='text-danger'>No Results Found</p>";
                                }

                                // Deletion Logic
                                if (isset($_POST['delete'])) {
                                    $delete_id = intval($_POST['delete_id']); // Sanitize input

                                    if ($delete_id > 0) {
                                        $sql = "DELETE FROM service_man WHERE m_id = :delete_id";
                                        $stmt = $conn->prepare($sql);
                                        $stmt->bindParam(':delete_id', $delete_id, PDO::PARAM_INT);

                                        if ($stmt->execute()) {
                                            echo '<script>
                                                    alert("Record Deleted Successfully");
                                                    window.location.href = "technician.php";
                                                  </script>';
                                        } else {
                                            echo '<p class="text-danger">Unable to Delete Data: ' . $conn->errorInfo() . '</p>';
                                        }
                                    } else {
                                        echo '<p class="text-danger">Invalid Technician ID.</p>';
                                    }
                                }
                                ?>
                            </div>
                        </div>
                    </section>
                </div>             
            </div>
        </section>
    </section>

  
</section>

<!-- Scripts -->
<script src="views/js/jquery.js"></script>
<script src="views/js/bootstrap.min.js"></script>
<script src="views/js/common-scripts.js"></script>
</body>
</html>
