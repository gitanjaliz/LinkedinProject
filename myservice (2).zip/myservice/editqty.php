<?php
require_once('lock.php');
if($_SERVER['REQUEST_METHOD'] == "POST")
{
	$i_id = $_POST['i'];
	$cr_id = $_POST['cr_id'];
	$qty = $_POST['qtty'];
	$price = $_POST['price'];
	$cr_tot=$price*$qty;
	$u_id = $user['u_id'];
	$ca_dt = time();		
				if($auth_main->editqty($u_id, $i_id, $qty, $cr_id, $cr_tot))
				{	
				echo "Success" ;
				}
				else
				{
				echo "Fails upload";
				}
}
?>