
<!DOCTYPE HTML>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="user-scalable=no, initial-scale=1.0, maximum-scale=1.0 minimal-ui" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<link rel="icon" type="image/png" href="images/splash/android-chrome-192x192.png" sizes="192x192">
<link rel="apple-touch-icon" sizes="196x196" href="images/splash/apple-touch-icon-196x196.png">
<link rel="apple-touch-icon" sizes="180x180" href="images/splash/apple-touch-icon-180x180.png">
<link rel="apple-touch-icon" sizes="152x152" href="images/splash/apple-touch-icon-152x152.png">
<link rel="apple-touch-icon" sizes="144x144" href="images/splash/apple-touch-icon-144x144.png">
<link rel="apple-touch-icon" sizes="120x120" href="images/splash/apple-touch-icon-120x120.png">
<link rel="apple-touch-icon" sizes="114x114" href="images/splash/apple-touch-icon-114x114.png">
<link rel="apple-touch-icon" sizes="76x76" href="images/splash/apple-touch-icon-76x76.png">
<link rel="apple-touch-icon" sizes="72x72" href="images/splash/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon" sizes="60x60" href="images/splash/apple-touch-icon-60x60.png">
<link rel="apple-touch-icon" sizes="57x57" href="images/splash/apple-touch-icon-57x57.png">
<link rel="icon" type="image/png" href="images/splash/favicon-96x96.png" sizes="96x96">
<link rel="icon" type="image/png" href="images/splash/favicon-32x32.png" sizes="32x32">
<link rel="icon" type="image/png" href="images/splash/favicon-16x16.png" sizes="16x16">
<link rel="shortcut icon" href="images/splash/favicon.ico" type="image/x-icon" />
<link href='https://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Raleway:900,800,700' rel='stylesheet' type='text/css'>
<title>Epsilon 5.0</title>
<link href="styles/style.css" rel="stylesheet" type="text/css">
<link href="styles/framework.css" rel="stylesheet" type="text/css">
<link href="styles/font-awesome.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="scripts/jquery.js"></script>
<script type="text/javascript" src="scripts/plugins.js"></script>
<script type="text/javascript" src="scripts/custom.js"></script>
</head>
<body>
<div class="gallery-fix"></div> 
<div class="sidebar-tap-close"></div> 
<div class="header-fixed">
<a href="#" class="header-icon-1 open-left-sidebar"><i class="fa fa-navicon"></i></a>
<a href="index.html" class="header-logo">STORE</a>
<a href="#" class="header-icon-3 open-right-sidebar"><i class="fa fa-shopping-bag"></i></a>
<a href="#" class="header-icon-2 open-search-bar"><i class="fa fa-search"></i></a>
</div>
<div class="header-search">
<input type="text" value="Looking for something?">
<a class="close-search-bar" href="#"><i class="fa fa-times"></i></a>
</div>
<div class="sidebar-left">
<div class="sidebar-scroll">
<div class="sidebar-header left-sidebar-header">
<h3>Store</h3>
<a class="close-sidebar" href="#"><i class="fa fa-times"></i></a>
<a href="#"><i class="fa fa-facebook"></i></a>
<a href="#"><i class="fa fa-twitter"></i></a>
<div class="clear"></div>
</div>
<div class="sidebar-divider">
Navigation
</div>
<div class="sidebar-menu">
<a class="menu-item" href="index.html">
<i class="fa fa-home"></i>
Home
<i class="fa fa-circle"></i>
</a>
<a class="menu-item" href="store-home2.html">
<i class="fa fa-home"></i>
Home 2
<i class="fa fa-circle"></i>
</a>
<a class="menu-item " href="store-cover.html">
<i class="fa fa-picture-o"></i>
Cover
<i class="fa fa-circle"></i>
</a>
<a class="menu-item" href="store-product.html">
<i class="fa fa-bookmark-o"></i>
Product
<i class="fa fa-circle"></i>
</a>
<a class="menu-item" href="store-cart-1.html">
<i class="fa fa-shopping-cart"></i>
Cart
<i class="fa fa-circle"></i>
</a>
<a class="menu-item" href="store-cart-2.html">
<i class="fa fa-shopping-cart"></i>
Cart 2
<i class="fa fa-circle"></i>
</a>
<a class="menu-item" href="store-checkout.html">
<i class="fa fa-credit-card"></i>
Checkout
<i class="fa fa-circle"></i>
</a>
<a class="menu-item active-item" href="store-about.html">
<i class="fa fa-support"></i>
About Us
<i class="fa fa-circle"></i>
</a>
<a class="menu-item" href="store-history.html">
<i class="fa fa-archive"></i>
History
<i class="fa fa-circle"></i>
</a>
<a class="menu-item" href="store-faq.html">
<i class="fa fa-question"></i>
FAQ's
<i class="fa fa-circle"></i>
</a>
<a class="menu-item" href="pageapp-login.html">
<i class="fa fa-user"></i>
Login
<i class="fa fa-circle"></i>
</a>
<a class="menu-item" href="pageapp-signup.html">
<i class="fa fa-code"></i>
Register
<i class="fa fa-circle"></i>
</a>
<a class="menu-item" href="contact.html">
<i class="fa fa-envelope-o"></i>
Contact
<i class="fa fa-circle"></i>
</a>
<a class="close-sidebar menu-item" href="#">
<i class="fa fa-times"></i>
Close
<i class="fa fa-circle"></i>
</a>
<div class="sidebar-divider">
BONUS! 50 extra pages included
</div>
<a class="menu-item" href="page-sitemap.html">
<i class="fa fa-gift"></i>
Extra Pages
<i class="fa fa-circle"></i>
</a>
</div>
<em class="sidebar-copyright">Copyright 2016. All Rights Reserved</em>
</div>
</div>
<div class="sidebar-right">
<div class="sidebar-scroll">
<div class="sidebar-header right-sidebar-header">
<h3>STORE</h3>
<a class="close-sidebar" href="#"><i class="fa fa-times"></i></a>
<a href="#"><i class="fa fa-facebook"></i></a>
<a href="#"><i class="fa fa-twitter"></i></a>
<div class="clear"></div>
</div>
<div class="sidebar-divider full-bottom">
In your cart
</div>
<div class="sidebar-cart">
<a href="#">
<img data-original="images/pictures/1t.jpg" class="preload-image" alt="img">
<strong>$11.00</strong>
<h4>BeMobile</h4>
<em>Mobile and Tablet Site Responsive Template</em>
</a>
<a href="#">
<img data-original="images/pictures/2t.jpg" class="preload-image" alt="img">
<strong>$11.00</strong>
<h4>ProMobile</h4>
<em>Mobile and Tablet Site Responsive Template</em>
</a>
<a href="#">
<img data-original="images/pictures/3t.jpg" class="preload-image" alt="img">
<strong>$11.00</strong>
<h4>CleanMobile</h4>
<em>Mobile and Tablet Site Responsive Template</em>
</a>
</div>
<div class="sidebar-menu">
<a class="menu-item" href="#">
<i class="fa fa-shopping-cart"></i>
See all cart items
<i class="fa fa-circle"></i>
</a>
</div>
<div class="sidebar-divider">
Recommended categories
</div>
<div class="sidebar-recommend">
<a href="#">Tech & Devices<em class="bg-red-dark">1</em></a>
<a href="#">Mobile & Tablets<em class="bg-green-dark">5</em></a>
<a href="#">Design & Graphics<em class="bg-blue-dark">8</em></a>
<a href="#">Coding & Development<em class="bg-magenta-dark">15</em></a>
</div>
<div class="sidebar-divider">
Let's get social
</div>
<div class="sidebar-menu">
<a class="menu-item" href="#">
<i class="fa fa-facebook"></i>
Facebook
<i class="fa fa-circle"></i>
</a>
<a class="menu-item" href="#">
<i class="fa fa-twitter"></i>
Twitter
<i class="fa fa-circle"></i>
</a>
<a class="menu-item" href="#">
<i class="fa fa-google-plus"></i>
Google
<i class="fa fa-circle"></i>
</a>
<div class="sidebar-divider">
GET IN TOUCH
</div>
<a class="menu-item" href="#">
<i class="fa fa-phone"></i>
Call Us
<i class="fa fa-circle"></i>
</a>
<a class="menu-item" href="#">
<i class="fa fa-fax"></i>
Fax Us
<i class="fa fa-circle"></i>
</a>
<a class="menu-item" href="#">
<i class="fa fa-envelope-o"></i>
Mail Us
<i class="fa fa-circle"></i>
</a>
<div class="sidebar-divider">
BONUS! 50 extra pages included
</div>
<a class="menu-item" href="page-sitemap.html">
<i class="fa fa-gift"></i>
Extra Pages
<i class="fa fa-circle"></i>
</a>
</div>
<em class="sidebar-copyright">Copyright 2016. All Rights Reserved</em>
</div>
</div>
<div id="page-content">
<div id="page-content-scroll">
<div class="header-clear"></div>
<div class="content-fullscreen">
<img data-original="images/pictures/9.jpg" alt="img" class="preload-image responsive-image">
<div class="decoration-lines">
<div class="deco-0"></div>
<div class="deco-1"></div>
<div class="deco-2"></div>
<div class="deco-3"></div>
<div class="deco-4"></div>
<div class="deco-5"></div>
<div class="deco-6"></div>
<div class="deco-7"></div>
<div class="deco-8"></div>
<div class="deco-9"></div>
</div>
<div class="store-about-image">
<img src="images/pictures/8t.jpg" alt="img">
</div>
<div class="content">
<div class="container no-bottom">
<h3 class="center-text no-bottom">Enabled Store</h3>
<p class="center-text">Envato, ThemeForest</p>
<div class="small-decoration bg-red-dark"></div>
<p class="center-text boxed-text">
We're the lead developers of mobile and tablet templates on Envato's ThemeForest Marketplace, with over
7 years experience and thousands of satisfied customers. We've built thousands of custom files and
hundreds of stock templates tested on various platforms to make sure you get the best quality possible!
</p>
</div>
<div class="container no-bottom">
<div class="small-decoration bg-red-dark"></div>
<h3 class="center-text">Happy customers</h3>
<p class="center-text half-bottom">Always leave great ratings!</p>
</div>
<div class="container single-item no-bottom">
<div class="review-6">
<h4>
Worth 5 stars for code quality, design, and documentation.
Keep your hard work and produce more quality themes! I'm so
happy with my purchase!
</h4>
<div class="review-stars">
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
</div>
<strong>ThemeForest Buyer</strong>
</div>
<div class="review-6">
<h4>
This is an extremely well documented theme, works right out
of the box and the developer has a great attitude. Very thankful
he shares his skills so we can look good!
</h4>
<div class="review-stars">
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
</div>
<strong>ThemeForest Buyer</strong>
</div>
<div class="review-6">
<h4>
Actually five stars for Customer support, design and code quality.
Very happy with this template, saved me a heap of time, and customer
support to a question was exceptional.
</h4>
<div class="review-stars">
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
</div>
<strong>ThemeForest Buyer</strong>
</div>
</div>
<div class="small-decoration bg-red-dark"></div>
<div class="container no-bottom">
<h3 class="center-text no-bottom">Get in Touch</h3>
<p class="center-text">We're connected!</p>
<p class="center-text boxed-text">
We're the lead developers of mobile and tablet templates on Envato's ThemeForest Marketplace, with over
7 years experience and thousands of satisfied customers. We've built thousands of custom files and
hundreds of stock templates tested on various platforms to make sure you get the best quality possible!
</p>
</div>
</div>
</div>
<div class="content">
<div class="contact-form no-bottom boxed-item">
<div class="formSuccessMessageWrap" id="formSuccessMessageWrap">
<div class="container">
<div class="decoration"></div>
<h4 class="center-text">Message Sent </h4>
<p class="center-text">Your message has been successfuly sent. Please allow up to 48 hours for a reply! Thanks!</p>
</div>
</div>
<form action="php/contact.php" method="post" class="contactForm" id="contactForm">
<fieldset>
<div class="formValidationError bg-red-dark color-white" id="contactNameFieldError">
<p class="center-text uppercase small-text">Name is required!</p>
</div>
<div class="formValidationError bg-red-dark color-white" id="contactEmailFieldError">
<p class="center-text uppercase small-text">Mail address required!</p>
</div>
<div class="formValidationError bg-red-dark color-white" id="contactEmailFieldError2">
<p class="center-text uppercase small-text">Mail address must be valid!</p>
</div>
<div class="formValidationError bg-red-dark color-white" id="contactMessageTextareaError">
<p class="center-text uppercase small-text">Message field is empty!</p>
</div>
<div class="formFieldWrap">
<label class="field-title contactNameField" for="contactNameField">Name:<span>(required)</span></label>
<input type="text" name="contactNameField" value="" class="contactField requiredField" id="contactNameField" />
</div>
<div class="formFieldWrap">
<label class="field-title contactEmailField" for="contactEmailField">Email: <span>(required)</span></label>
<input type="text" name="contactEmailField" value="" class="contactField requiredField requiredEmailField" id="contactEmailField" />
</div>
<div class="formTextareaWrap">
<label class="field-title contactMessageTextarea" for="contactMessageTextarea">Message: <span>(required)</span></label>
<textarea name="contactMessageTextarea" class="contactTextarea requiredField" id="contactMessageTextarea"></textarea>
</div>
<div class="formSubmitButtonErrorsWrap contactFormButton">
<input type="submit" class="buttonWrap button button-green contactSubmitButton" id="contactSubmitButton" value="Send Message" data-formId="contactForm" />
</div>
</fieldset>
</form>
</div>
</div>
<div class="footer">
<div class="footer-content">
<h3 class="footer-logo">STORE MOBILE</h3>
<p class="footer-text">
We aim to simplify your life by creating a beautiful and simple product that's feature rich and easy to use!
</p>
</div>
<div class="footer-socials">
<a href="#" class="scale-hover facebook-color"><i class="fa fa-facebook"></i></a>
<a href="#" class="scale-hover twitter-color"><i class="fa fa-twitter"></i></a>
<a href="#" class="scale-hover google-color"><i class="fa fa-google-plus"></i></a>
<a href="#" class="scale-hover phone-color"><i class="fa fa-phone"></i></a>
<a href="#" class="scale-hover mail-color"><i class="fa fa-envelope-o"></i></a>
<a href="#" class="scale-hover bg-night-dark back-to-top"><i class="fa fa-angle-up"></i></a>
<div class="clear"></div>
</div>
<p class="footer-strip">Copyright <span id="copyright-year"></span> Enabled. All Rights Reserved</p>
</div>
</div>
<a href="#" class="back-to-top-badge"><i class="fa fa-caret-up"></i>Back to top</a>
</div>
<div class="share-bottom">
<h3>Share Page</h3>
<div class="share-socials-bottom">
<a href="https://www.facebook.com/sharer/sharer.php?u=http://www.themeforest.net/">
<i class="fa fa-facebook facebook-color"></i>
Facebook
</a>
<a href="https://twitter.com/home?status=Check%20out%20ThemeForest%20http://www.themeforest.net">
<i class="fa fa-twitter twitter-color"></i>
Twitter
</a>
<a href="https://plus.google.com/share?url=http://www.themeforest.net">
<i class="fa fa-google-plus google-color"></i>
Google
</a>
<a href="https://pinterest.com/pin/create/button/?url=http://www.themeforest.net/&media=https://0.s3.envato.com/files/63790821/profile-image.jpg&description=Themes%20and%20Templates">
<i class="fa fa-pinterest-p pinterest-color"></i>
Pinterest
</a>
<a href="sms:">
<i class="fa fa-comment-o sms-color"></i>
Text
</a>
<a href="mailto:?&subject=Check this page out!&body=http://www.themeforest.net">
<i class="fa fa-envelope-o mail-color"></i>
Email
</a>
<div class="clear"></div>
</div>
</div>
</body>